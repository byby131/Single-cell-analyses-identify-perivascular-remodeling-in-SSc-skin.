suppressPackageStartupMessages({
  library(Seurat)
  library(CellChat)
  library(dplyr)
  library(readr)
})

set.seed(20260802)

input_file <- "/Users/baoying/Desktop/巨噬细胞/GSE195452_UMAP_PDF/GSE195452_SSc_Ctrl_skin_combined_raw.rds"
out_dir <- "outputs/cellchat_discovery"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

obj <- readRDS(input_file)
stopifnot(inherits(obj, "Seurat"), all(c("annotation", "condition", "patient_id") %in% colnames(obj@meta.data)))

# A priori biologically interpretable state map. The two inflammatory myeloid
# states are combined because the control arm contains only 5 and 18 cells,
# respectively; keeping them separate would make between-condition inference
# unstable. RGS5+ and TGFBI+ pericytes remain separate receivers.
map_state <- function(x) {
  case_when(
    x %in% c("M_IL1B", "M_CD16_IL1B") ~ "Inflammatory myeloid",
    x %in% c("Mf", "Mf_TREM2") ~ "Macrophage",
    x %in% c("Mo", "Mo_CD16") ~ "Monocyte",
    grepl("^DC", x) | grepl("^pDC", x) | x == "LC" ~ "Dendritic cell",
    x == "Peri_RGS5" ~ "RGS5+ pericyte",
    x == "Peri_TGFBI" ~ "TGFBI+ pericyte",
    grepl("^Vascular_", x) | grepl("^Lymphatic_", x) ~ "Endothelial",
    grepl("^Fibro_", x) ~ "Fibroblast",
    grepl("^KRT", x) ~ "Keratinocyte",
    grepl("^T", x) | grepl("^sT", x) | x == "T_GD" ~ "T cell",
    grepl("^NK", x) ~ "NK cell",
    x %in% c("B", "B_CXCR4", "Plasma") ~ "B / Plasma cell",
    grepl("^Mast", x) ~ "Mast cell",
    TRUE ~ NA_character_
  )
}

obj$cellchat_state <- map_state(as.character(obj$annotation))
meta_all <- obj@meta.data %>%
  transmute(cell = rownames(obj@meta.data), patient_id, condition,
            original_annotation = annotation, cellchat_state)
write_csv(meta_all, file.path(out_dir, "cell_state_mapping_all_cells.csv"))

keep <- !is.na(obj$cellchat_state) & obj$condition %in% c("Ctrl", "SSc")
obj <- subset(obj, cells = colnames(obj)[keep])
obj$cellchat_state <- droplevels(factor(obj$cellchat_state))
counts_by_group <- obj@meta.data %>% count(condition, cellchat_state, name = "n_cells")
write_csv(counts_by_group, file.path(out_dir, "cell_counts_by_condition_and_state.csv"))

# Patient-balanced network input: cap each patient-by-state contribution at five
# cells. This prevents a few cell-rich participants from dominating pooled
# CellChat probabilities while retaining every eligible participant and state.
balanced_cells <- obj@meta.data %>%
  mutate(cell = rownames(obj@meta.data)) %>%
  group_by(condition, cellchat_state, patient_id) %>%
  slice_sample(prop = 1) %>%
  slice_head(n = 5) %>%
  ungroup()
write_csv(balanced_cells %>% count(condition, cellchat_state, name = "n_cells"),
          file.path(out_dir, "cell_counts_patient_balanced_input.csv"))
obj <- subset(obj, cells = balanced_cells$cell)

run_cellchat <- function(seu, condition_label) {
  rds_file <- file.path(out_dir, paste0("CellChat_", condition_label, ".rds"))
  csv_file <- file.path(out_dir, paste0("CellChat_", condition_label, "_all_interactions.csv"))
  if (file.exists(rds_file) && file.exists(csv_file)) {
    message("Reusing completed CellChat result for ", condition_label)
    return(read_csv(csv_file, show_col_types = FALSE))
  }
  cells <- colnames(seu)[seu$condition == condition_label]
  x <- subset(seu, cells = cells)
  DefaultAssay(x) <- "RNA"
  x <- JoinLayers(x, assay = "RNA")
  # The combined public object preserves raw counts but has an empty data layer.
  # CellChat requires normalized expression, so normalize independently within
  # each condition using Seurat's standard library-size/log transformation.
  x <- NormalizeData(x, normalization.method = "LogNormalize",
                     scale.factor = 10000, verbose = FALSE)
  data_input <- GetAssayData(x, assay = "RNA", layer = "data")
  if (nrow(data_input) == 0 || ncol(data_input) == 0) stop("RNA data layer is empty")
  meta <- x@meta.data[, c("cellchat_state", "patient_id", "condition"), drop = FALSE]
  cc <- createCellChat(object = data_input, meta = meta, group.by = "cellchat_state")
  cc@DB <- CellChatDB.human
  cc <- subsetData(cc)
  cc <- identifyOverExpressedGenes(cc)
  cc <- identifyOverExpressedInteractions(cc)
  cc <- computeCommunProb(cc, type = "triMean", population.size = FALSE,
                          raw.use = TRUE, nboot = 100, seed.use = 20260802)
  cc <- filterCommunication(cc, min.cells = 10)
  cc <- computeCommunProbPathway(cc)
  cc <- aggregateNet(cc)
  saveRDS(cc, rds_file)
  comm <- subsetCommunication(cc)
  write_csv(comm, csv_file)
  comm
}

comm_ctrl <- run_cellchat(obj, "Ctrl")
comm_ssc <- run_cellchat(obj, "SSc")

combined <- bind_rows(Ctrl = comm_ctrl, SSc = comm_ssc, .id = "condition")
write_csv(combined, file.path(out_dir, "CellChat_all_interactions_combined.csv"))

focus <- combined %>%
  filter(source %in% c("Inflammatory myeloid", "Macrophage", "Monocyte", "Dendritic cell"),
         target %in% c("RGS5+ pericyte", "TGFBI+ pericyte", "Endothelial", "Fibroblast")) %>%
  arrange(condition, desc(prob))
write_csv(focus, file.path(out_dir, "CellChat_myeloid_to_stromal_interactions.csv"))

sema4d <- combined %>%
  filter(grepl("SEMA4D", interaction_name, ignore.case = TRUE) |
         grepl("SEMA4D", ligand, ignore.case = TRUE)) %>%
  arrange(condition, source, target, desc(prob))
write_csv(sema4d, file.path(out_dir, "CellChat_SEMA4D_interactions.csv"))

qa <- c(
  paste0("Input cells: ", ncol(readRDS(input_file)), ". Included mapped cells: ", ncol(obj), "."),
  "CellChat groups were defined before inference; M_IL1B and M_CD16_IL1B were combined because Ctrl contained 5 and 18 cells.",
  "Patient-balanced input retained at most five cells per patient per state before network estimation.",
  "Communication probability used triMean, population.size=FALSE, 100 bootstraps, and min.cells=10.",
  "Condition-level CellChat pools cells for network estimation and is exploratory; formal disease inference remains participant-level.",
  "SEMA4D-PLXNB2 is present in CellChatDB.human."
)
writeLines(qa, file.path(out_dir, "CellChat_QA_notes.txt"))
