suppressPackageStartupMessages({
  library(Seurat)
  library(CellChat)
  library(dplyr)
  library(readr)
})

set.seed(20260802)
input_file <- "/Users/baoying/Desktop/巨噬细胞/GSE195452_UMAP_PDF/GSE195452_SSc_Ctrl_skin_combined_raw.rds"
out_dir <- "outputs/cellchat_discovery"
obj <- readRDS(input_file)

obj$focused_state <- case_when(
  obj$annotation %in% c("M_IL1B", "M_CD16_IL1B") ~ "Inflammatory myeloid",
  obj$annotation %in% c("Mf", "Mf_TREM2") ~ "Macrophage",
  obj$annotation %in% c("Mo", "Mo_CD16") ~ "Monocyte",
  grepl("^DC", obj$annotation) | grepl("^pDC", obj$annotation) | obj$annotation == "LC" ~ "Dendritic cell",
  obj$annotation == "Peri_RGS5" ~ "RGS5+ pericyte",
  obj$annotation == "Peri_TGFBI" ~ "TGFBI+ pericyte",
  TRUE ~ NA_character_
)
obj <- subset(obj, cells = colnames(obj)[!is.na(obj$focused_state)])

# Same patient-balanced rule as the global analysis.
balanced <- obj@meta.data %>%
  mutate(cell = rownames(obj@meta.data)) %>%
  group_by(condition, focused_state, patient_id) %>%
  slice_sample(prop = 1) %>%
  slice_head(n = 5) %>%
  ungroup()
obj <- subset(obj, cells = balanced$cell)

run_focused <- function(condition_label) {
  rds_file <- file.path(out_dir, paste0("CellChat_", condition_label, "_focused_truncatedMean.rds"))
  csv_file <- file.path(out_dir, paste0("CellChat_", condition_label, "_focused_truncatedMean.csv"))
  if (file.exists(rds_file) && file.exists(csv_file)) return(read_csv(csv_file, show_col_types = FALSE))
  x <- subset(obj, cells = colnames(obj)[obj$condition == condition_label])
  x <- JoinLayers(x, assay = "RNA")
  x <- NormalizeData(x, normalization.method = "LogNormalize", scale.factor = 10000, verbose = FALSE)
  mat <- GetAssayData(x, assay = "RNA", layer = "data")
  meta <- x@meta.data[, c("focused_state", "patient_id", "condition"), drop = FALSE]
  cc <- createCellChat(mat, meta = meta, group.by = "focused_state")
  cc@DB <- CellChatDB.human
  cc <- subsetData(cc)
  cc <- identifyOverExpressedGenes(cc)
  cc <- identifyOverExpressedInteractions(cc)
  cc <- computeCommunProb(cc, type = "truncatedMean", trim = 0.1,
                          population.size = FALSE, raw.use = TRUE,
                          nboot = 100, seed.use = 20260802)
  cc <- filterCommunication(cc, min.cells = 10)
  cc <- computeCommunProbPathway(cc)
  cc <- aggregateNet(cc)
  saveRDS(cc, rds_file)
  ans <- subsetCommunication(cc)
  write_csv(ans, csv_file)
  ans
}

ctrl <- run_focused("Ctrl")
ssc <- run_focused("SSc")
combined <- bind_rows(Ctrl = ctrl, SSc = ssc, .id = "condition")
write_csv(combined, file.path(out_dir, "CellChat_focused_truncatedMean_combined.csv"))

sema <- combined %>%
  filter(grepl("SEMA4D", ligand, ignore.case = TRUE) |
           grepl("SEMA4D", interaction_name, ignore.case = TRUE)) %>%
  arrange(condition, source, target, desc(prob))
write_csv(sema, file.path(out_dir, "CellChat_SEMA4D_sensitivity_interactions.csv"))

writeLines(c(
  "Sensitivity analysis only: focused myeloid-to-pericyte network used truncatedMean with trim=0.1.",
  "The primary global CellChat analysis used triMean and did not detect SEMA4D interactions.",
  "Both primary and sensitivity results must be reported together; sensitivity detection does not establish disease enhancement.",
  "Input was patient-balanced at a maximum of five cells per patient per state."
), file.path(out_dir, "CellChat_SEMA4D_sensitivity_QA_notes.txt"))
