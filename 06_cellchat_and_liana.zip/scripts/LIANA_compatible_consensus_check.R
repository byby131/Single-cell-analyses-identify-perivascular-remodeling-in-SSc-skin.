suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(dplyr)
  library(tidyr)
  library(readr)
})

set.seed(20260802)
input_file <- "/Users/baoying/Desktop/巨噬细胞/GSE195452_UMAP_PDF/GSE195452_SSc_Ctrl_skin_combined_raw.rds"
resource_file <- "work/liana_source/liana-master/inst/omni_resources.rds"
out_dir <- "outputs/liana_compatible_check"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

obj <- readRDS(input_file)
obj$state <- case_when(
  obj$annotation %in% c("M_IL1B", "M_CD16_IL1B") ~ "Inflammatory myeloid",
  obj$annotation %in% c("Mf", "Mf_TREM2") ~ "Macrophage",
  obj$annotation %in% c("Mo", "Mo_CD16") ~ "Monocyte",
  grepl("^DC", obj$annotation) | grepl("^pDC", obj$annotation) | obj$annotation == "LC" ~ "Dendritic cell",
  obj$annotation == "Peri_RGS5" ~ "RGS5+ pericyte",
  obj$annotation == "Peri_TGFBI" ~ "TGFBI+ pericyte",
  grepl("^Vascular_", obj$annotation) | grepl("^Lymphatic_", obj$annotation) ~ "Endothelial",
  grepl("^Fibro_", obj$annotation) ~ "Fibroblast",
  grepl("^KRT", obj$annotation) ~ "Keratinocyte",
  grepl("^T", obj$annotation) | grepl("^sT", obj$annotation) | obj$annotation == "T_GD" ~ "T cell",
  grepl("^NK", obj$annotation) ~ "NK cell",
  obj$annotation %in% c("B", "B_CXCR4", "Plasma") ~ "B / Plasma cell",
  grepl("^Mast", obj$annotation) ~ "Mast cell",
  TRUE ~ NA_character_
)
obj <- subset(obj, cells = colnames(obj)[!is.na(obj$state)])

# Same patient-balanced rule used for CellChat: no participant contributes more
# than five cells to a given state/condition summary.
balanced <- obj@meta.data %>%
  mutate(cell = rownames(obj@meta.data)) %>%
  group_by(condition, state, patient_id) %>%
  slice_sample(prop = 1) %>%
  slice_head(n = 5) %>%
  ungroup()
obj <- subset(obj, cells = balanced$cell)
obj <- JoinLayers(obj, assay = "RNA")
obj <- NormalizeData(obj, normalization.method = "LogNormalize",
                     scale.factor = 10000, verbose = FALSE)

resource <- readRDS(resource_file)$Consensus %>%
  transmute(ligand = source_genesymbol, receptor = target_genesymbol,
            resource_support = sources, references) %>%
  distinct(ligand, receptor, .keep_all = TRUE)

myeloid <- c("Inflammatory myeloid", "Macrophage", "Monocyte", "Dendritic cell")
receivers <- c("RGS5+ pericyte", "TGFBI+ pericyte")

score_condition <- function(condition_label, prop_cutoff) {
  x <- subset(obj, cells = colnames(obj)[obj$condition == condition_label])
  mat <- GetAssayData(x, assay = "RNA", layer = "data")
  cnt <- GetAssayData(x, assay = "RNA", layer = "counts")
  states <- as.character(x$state)
  lev <- sort(unique(states))
  onehot <- sparse.model.matrix(~ 0 + factor(states, levels = lev))
  colnames(onehot) <- lev
  n_state <- Matrix::colSums(onehot)
  means <- as.matrix(mat %*% onehot)
  means <- sweep(means, 2, n_state, "/")
  props <- as.matrix((cnt > 0) %*% onehot)
  props <- sweep(props, 2, n_state, "/")
  scaled <- t(scale(t(means)))
  scaled[!is.finite(scaled)] <- 0
  global_mean <- mean(mat)

  build_pair <- function(sender, receiver) {
    z <- resource %>%
      filter(ligand %in% rownames(means), receptor %in% rownames(means)) %>%
      mutate(
        condition = condition_label,
        source = sender,
        target = receiver,
        ligand_expr = means[ligand, sender],
        receptor_expr = means[receptor, receiver],
        ligand_prop = props[ligand, sender],
        receptor_prop = props[receptor, receiver],
        ligand_scaled = scaled[ligand, sender],
        receptor_scaled = scaled[receptor, receiver]
      ) %>%
      filter(ligand_prop >= prop_cutoff, receptor_prop >= prop_cutoff)
    if (!nrow(z)) return(z)

    # Exact score formulae from LIANA R source:
    # SCA LRscore, NATMI product/specificity, and Connectome weight_sc.
    ligand_sums <- rowSums(means[z$ligand, , drop = FALSE])
    receptor_sums <- rowSums(means[z$receptor, , drop = FALSE])
    z %>% mutate(
      sca_lrscore = sqrt(ligand_expr * receptor_expr) /
        (global_mean + sqrt(ligand_expr * receptor_expr)),
      natmi_product = ligand_expr * receptor_expr,
      natmi_specificity = (ligand_expr / ligand_sums) *
        (receptor_expr / receptor_sums),
      connectome_weight = (ligand_scaled + receptor_scaled) / 2
    )
  }

  all <- bind_rows(lapply(myeloid, function(s) {
    bind_rows(lapply(receivers, function(r) build_pair(s, r)))
  }))
  if (!nrow(all)) return(all)
  all %>%
    group_by(condition, source, target) %>%
    mutate(
      rank_sca = rank(-sca_lrscore, ties.method = "average") / n(),
      rank_natmi_product = rank(-natmi_product, ties.method = "average") / n(),
      rank_natmi_specificity = rank(-natmi_specificity, ties.method = "average") / n(),
      rank_connectome = rank(-connectome_weight, ties.method = "average") / n(),
      consensus_mean_rank = rowMeans(cbind(rank_sca, rank_natmi_product,
                                           rank_natmi_specificity, rank_connectome))
    ) %>%
    ungroup() %>%
    mutate(expression_cutoff = prop_cutoff) %>%
    arrange(condition, source, target, consensus_mean_rank)
}

results <- bind_rows(
  score_condition("Ctrl", 0.10), score_condition("SSc", 0.10),
  score_condition("Ctrl", 0.05), score_condition("SSc", 0.05)
)
write_csv(results, file.path(out_dir, "LIANA_compatible_all_myeloid_pericyte_scores.csv"))

axis <- results %>%
  filter(ligand == "SEMA4D", receptor == "PLXNB2") %>%
  arrange(expression_cutoff, condition, source, target)
write_csv(axis, file.path(out_dir, "LIANA_compatible_SEMA4D_PLXNB2.csv"))

# Patient-level feasibility/support table (not a LIANA score). This records why
# participant-specific CCC inference is sparse for the prespecified sender.
full_obj <- readRDS(input_file)
full_obj <- JoinLayers(full_obj, assay = "RNA")
full_obj <- NormalizeData(full_obj, verbose = FALSE)
md <- full_obj@meta.data
md$sender <- md$annotation %in% c("M_IL1B", "M_CD16_IL1B")
md$receiver <- md$annotation == "Peri_RGS5"
expr <- GetAssayData(full_obj, assay = "RNA", layer = "data")
patient_support <- bind_rows(lapply(unique(md$patient_id), function(pid) {
  si <- which(md$patient_id == pid & md$sender)
  ri <- which(md$patient_id == pid & md$receiver)
  tibble(
    patient_id = pid,
    condition = unique(md$condition[md$patient_id == pid])[1],
    n_sender = length(si), n_receiver = length(ri),
    sender_SEMA4D_pct = if(length(si)) mean(expr["SEMA4D", si] > 0) else NA_real_,
    receiver_PLXNB2_pct = if(length(ri)) mean(expr["PLXNB2", ri] > 0) else NA_real_,
    expression_product = sender_SEMA4D_pct * receiver_PLXNB2_pct
  )
}))
write_csv(patient_support, file.path(out_dir, "patient_level_axis_feasibility.csv"))

writeLines(c(
  "This is a LIANA-compatible audit, not a successful installation/run of the full LIANA R package.",
  "It uses the official bundled LIANA Consensus resource and exact SCA, NATMI, and Connectome score formulae from the downloaded official source.",
  "The full LIANA package could not be installed in the isolated runtime because six Bioconductor dependencies were absent.",
  "Primary expression cutoff is 10%; 5% is a prespecified sensitivity analysis. Both outputs are retained.",
  "Input is patient-balanced at a maximum of five cells per patient per state.",
  "Consensus mean rank is descriptive and must not be called a LIANA RobustRankAggregate P value."
), file.path(out_dir, "LIANA_compatible_QA_notes.txt"))
