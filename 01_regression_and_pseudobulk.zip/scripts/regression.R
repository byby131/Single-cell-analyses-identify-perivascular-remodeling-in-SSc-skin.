suppressPackageStartupMessages({library(dplyr); library(readr); library(tidyr); library(ggplot2); library(patchwork)})
out <- 'results'
dir.create(out,recursive=TRUE,showWarnings=FALSE)
d <- read_csv('inputs/participant_level_variables.csv',show_col_types=FALSE) |> arrange(gsm)
d$disease_group <- factor(d$disease_group,levels=c('Ctrl','SSc'))
d$chemistry <- factor(d$chemistry,levels=c('V1','V2'))
d$id <- sprintf('P%02d',seq_len(nrow(d)))
f <- score_unweighted_z ~ myeloid_SEMA4D_pct + disease_group + chemistry + log_perivascular_n + log_myeloid_n
fq <- update(f,.~.+perivascular_median_features+myeloid_median_features)
term <- 'myeloid_SEMA4D_pct'
m <- lm(f,d); n <- nrow(d); p <- m$rank
stopifnot(n==22,abs(coef(m)[term]-0.0351321)<1e-6,!anyNA(model.frame(m)))
hc3 <- function(m) {
 X<-model.matrix(m); bread<-solve(crossprod(X)); u<-resid(m)/(1-hatvalues(m))
 bread %*% crossprod(X*u) %*% bread
}
fitrow <- function(z,label,formula=f) {
 tryCatch({
 mm<-lm(formula,z); stopifnot(mm$rank==ncol(model.matrix(mm)),df.residual(mm)>2)
 b<-coef(mm)[term]; cs<-coef(summary(mm))[term,]; ci<-confint(mm,term)
 se3<-sqrt(diag(hc3(mm)))[term]; crit<-qt(.975,df.residual(mm))
 tibble(analysis=label,n=nobs(mm),n_Ctrl=sum(z$disease_group=='Ctrl'),n_SSc=sum(z$disease_group=='SSc'),
        beta=b,se=cs[2],ci_low=ci[1],ci_high=ci[2],p=cs[4],hc3_se=se3,hc3_ci_low=b-crit*se3,hc3_ci_high=b+crit*se3,
        hc3_p=2*pt(-abs(b/se3),df.residual(mm)),residual_df=df.residual(mm),status='estimated',
        excluded_ids=paste(setdiff(d$id,z$id),collapse=';'),excluded_gsm=paste(setdiff(d$gsm,z$gsm),collapse=';'))
 },error=function(e)tibble(analysis=label,n=nrow(z),status=paste('not estimable',conditionMessage(e))))
}
dg <- d |> mutate(fitted=fitted(m),residual=resid(m),standardized_residual=rstandard(m),studentized_residual=rstudent(m),
                  cooks_distance=cooks.distance(m),leverage=hatvalues(m),target_dfbetas=dfbetas(m)[,term],
                  flag_cook=cooks_distance>4/n,flag_dfbetas=abs(target_dfbetas)>2/sqrt(n),
                  flag_leverage=leverage>2*p/n,flag_student=abs(studentized_residual)>3,
                  component_partial_residual=residual+coef(m)[term]*myeloid_SEMA4D_pct)
xc <- lm(myeloid_SEMA4D_pct~disease_group+chemistry+log_perivascular_n+log_myeloid_n,d)
yc <- lm(score_unweighted_z~disease_group+chemistry+log_perivascular_n+log_myeloid_n,d)
dg$adjusted_x <- resid(xc); dg$adjusted_y <- resid(yc)
stopifnot(abs(coef(lm(adjusted_y~0+adjusted_x,dg))[1]-coef(m)[term])<1e-12)
write_csv(dg,file.path(out,'participant_diagnostics.csv'))
write_csv(as.data.frame(dfbetas(m)) |> mutate(id=d$id,gsm=d$gsm,.before=1),file.path(out,'all_coefficient_dfbetas.csv'))
cook <- dg$id[dg$flag_cook]; unionflag <- dg$id[dg$flag_cook|dg$flag_dfbetas]
top3 <- d |> filter(disease_group=='SSc') |> arrange(desc(myeloid_SEMA4D_pct),gsm) |> slice_head(n=3) |> pull(id)
scenarios <- list(Original_all22=d,Extended_QC=d,Exclude_max_Cook=d[d$id!=dg$id[which.max(dg$cooks_distance)],],
 Exclude_Cook_joint=d[!d$id%in%cook,],Exclude_Cook_or_DFBETAS_joint=d[!d$id%in%unionflag,],
 Exclude_top3_SSc_positivity=d[!d$id%in%top3,])
for(t in c(10,20,30,50)) scenarios[[paste0('Myeloid_ge',t,'_Perivascular_ge5')]] <- d[d$myeloid_n_cells>=t & d$perivascular_n_cells>=5,]
for(id in unique(c(cook,unionflag))) scenarios[[paste0('Exclude_',id)]] <- d[d$id!=id,]
res <- bind_rows(lapply(names(scenarios),function(k)fitrow(scenarios[[k]],k,if(k=='Extended_QC')fq else f)))
for(ch in levels(d$chemistry)) res <- bind_rows(res,fitrow(d[d$chemistry==ch,],paste0('Within_',ch),update(f,.~.-chemistry)))
write_csv(res,file.path(out,'regression_sensitivity.csv'))
loo <- bind_rows(lapply(seq_len(n),function(i) fitrow(d[-i,],paste0('Omit_',d$id[i]))))
write_csv(loo,file.path(out,'leave_one_out_full_intervals.csv'))
vifs <- bind_rows(lapply(list(primary=m,extended=lm(fq,d)),function(mm){
 X<-model.matrix(mm)[,-1,drop=FALSE]
 bind_rows(lapply(seq_len(ncol(X)),function(j)tibble(term=colnames(X)[j],vif=1/(1-summary(lm(X[,j]~X[,-j,drop=FALSE]))$r.squared))))
}),.id='model')
write_csv(vifs,file.path(out,'collinearity_vif.csv'))
checks<-tibble(metric=c('n','parameters_including_intercept','residual_df','Cook_screen','DFBETAS_screen','leverage_screen','scaled_predictor_condition_number','Shapiro_residual_p','studentized_BP_p'),
 value=c(n,p,df.residual(m),4/n,2/sqrt(n),2*p/n,kappa(scale(model.matrix(m)[,-1]),exact=TRUE),shapiro.test(resid(m))$p.value,lmtest::bptest(m,studentize=TRUE)$p.value))
write_csv(checks,file.path(out,'model_diagnostic_summary.csv'))
write_csv(d |> count(disease_group,chemistry),file.path(out,'disease_chemistry_counts.csv'))
# Original predictor-permutation procedure, conditional on disease-by-chemistry strata.
# Matrix residualization preserves the exact OLS target coefficient for fixed nuisance design.
permute_fit <- function(z,label,seed) {
 set.seed(seed); X<-model.matrix(~disease_group+chemistry+log_perivascular_n+log_myeloid_n,z)
 q<-qr(X); yr<-qr.resid(q,z$score_unweighted_z); x<-z$myeloid_SEMA4D_pct; xr<-qr.resid(q,x)
 obs<-sum(xr*yr)/sum(xr*xr); strata<-split(seq_len(nrow(z)),interaction(z$disease_group,z$chemistry,drop=TRUE))
 vals<-replicate(10000,{xp<-x; for(ii in strata) xp[ii]<-x[ii][sample.int(length(ii))]; xx<-qr.resid(q,xp); sum(xx*yr)/sum(xx*xx)})
 tibble(analysis=label,n=nrow(z),seed=seed,n_permutations=length(vals),beta=obs,p_permutation=(1+sum(abs(vals)>=abs(obs)))/(1+sum(is.finite(vals))))
}
permkeys<-c('Original_all22','Myeloid_ge10_Perivascular_ge5','Exclude_Cook_joint','Exclude_top3_SSc_positivity')
perm<-bind_rows(lapply(seq_along(permkeys),function(i)permute_fit(scenarios[[permkeys[i]]],permkeys[i],20261012+i)))
write_csv(perm,file.path(out,'permutation_sensitivity.csv'))
writeLines(capture.output(sessionInfo()),file.path(out,'regression_sessionInfo.txt'))
# R-only quantitative diagnostic grid; each point is one independent participant.
theme_set(theme_classic(base_size=8,base_family='sans')+theme(plot.title=element_text(size=9,face='bold'),axis.text=element_text(colour='black'),plot.tag=element_text(face='bold',size=14),legend.position='bottom'))
cols<-c(Ctrl='#2787A0',SSc='#C34F4B')
common<-list(scale_colour_manual(values=cols),scale_shape_manual(values=c(V1=16,V2=17)))
a<-ggplot(dg,aes(myeloid_SEMA4D_pct,component_partial_residual,colour=disease_group,shape=chemistry))+geom_point(size=2)+
 geom_abline(intercept=0,slope=coef(m)[term],colour='black',linewidth=.5)+common+
 labs(title='Adjusted component-plus-residual plot',x='Myeloid SEMA4D-positive cells (%)',y='Partial residual for target score',colour=NULL,shape=NULL,
 subtitle=sprintf('Full model: beta = %.4f; 95%% CI %.4f to %.4f',coef(m)[term],confint(m,term)[1],confint(m,term)[2]))
b<-ggplot(dg,aes(leverage,cooks_distance,colour=disease_group,shape=chemistry))+geom_point(size=2)+
 geom_hline(yintercept=4/n,linetype=2,colour='grey45')+geom_vline(xintercept=2*p/n,linetype=2,colour='grey45')+
 geom_text(data=dg[dg$flag_cook|dg$flag_dfbetas|dg$flag_leverage,],aes(label=id),vjust=-.7,size=2.4,show.legend=FALSE)+common+
 labs(title='Influence diagnostics',x='Leverage',y="Cook's distance",colour=NULL,shape=NULL)+scale_y_continuous(expand=expansion(mult=c(.05,.14)))
c<-ggplot(dg,aes(fitted,standardized_residual,colour=disease_group,shape=chemistry))+geom_point(size=2)+geom_hline(yintercept=0,linetype=2)+common+
 labs(title='Residuals versus fitted values',x='Fitted target score',y='Standardized residual',colour=NULL,shape=NULL)
qq<-data.frame(observed=sort(rstandard(m)),expected=qnorm(ppoints(n)))
e<-ggplot(qq,aes(expected,observed))+geom_point(size=1.8,colour='#475D74')+geom_abline(intercept=0,slope=1,linetype=2)+
 labs(title='Normal Q-Q diagnostic',x='Theoretical normal quantile',y='Standardized residual')
keep<-c('Original_all22','Myeloid_ge10_Perivascular_ge5','Exclude_max_Cook','Exclude_Cook_joint','Exclude_Cook_or_DFBETAS_joint','Exclude_top3_SSc_positivity')
ff<-res[match(keep,res$analysis),]; ff$label<-factor(paste(c('All participants','Myeloid >=10','Exclude highest Cook','Exclude Cook flags','Exclude Cook/DFBETAS flags','Exclude 3 highest SSc'),paste0('(n=',ff$n,')')),levels=rev(paste(c('All participants','Myeloid >=10','Exclude highest Cook','Exclude Cook flags','Exclude Cook/DFBETAS flags','Exclude 3 highest SSc'),paste0('(n=',ff$n,')'))))
g<-ggplot(ff,aes(beta,label))+geom_vline(xintercept=0,linetype=2,colour='grey45')+geom_errorbar(aes(xmin=ci_low,xmax=ci_high),orientation='y',width=.2)+geom_point(size=2,colour='#475D74')+
 labs(title='Deletion and eligibility sensitivity',x='Adjusted coefficient (ordinary 95% CI)',y=NULL)
h<-ggplot(vifs[vifs$model=='primary',],aes(vif,reorder(term,vif)))+geom_point(size=2,colour='#475D74')+labs(title='Primary-model collinearity',x='Variance inflation factor',y=NULL)+scale_y_discrete(labels=c(myeloid_SEMA4D_pct='Myeloid positivity',disease_groupSSc='Disease group',chemistryV2='Chemistry',log_perivascular_n='Log perivascular cells',log_myeloid_n='Log myeloid cells'))
fig<-((a|b)/(c|e)/(g|h))+plot_annotation(tag_levels='A')+plot_layout(guides='collect')
base<-file.path(out,'Regression_diagnostics')
save_pdf<-function(plot,path,width_mm,height_mm){
 if(file.exists('/opt/X11/lib/libXrender.1.dylib')) grDevices::cairo_pdf(path,width=width_mm/25.4,height=height_mm/25.4,family='sans')
 else grDevices::pdf(path,width=width_mm/25.4,height=height_mm/25.4,family='Helvetica',useDingbats=FALSE)
 print(plot);dev.off()
}
save_pdf(fig,paste0(base,'.pdf'),183,235)
svglite::svglite(paste0(base,'.svg'),width=183/25.4,height=235/25.4);print(fig);dev.off()
ggsave(paste0(base,'.png'),fig,width=183,height=235,units='mm',dpi=300,device=ragg::agg_png)
save_pdf(a,file.path(out,'Adjusted_partial_residual.pdf'),115,85)
print(res |> select(analysis,n,beta,ci_low,ci_high,p,hc3_p)); print(perm); print(vifs)
