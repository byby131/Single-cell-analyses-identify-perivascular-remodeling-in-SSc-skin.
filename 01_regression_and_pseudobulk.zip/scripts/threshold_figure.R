suppressPackageStartupMessages({library(dplyr);library(readr);library(tidyr);library(ggplot2);library(patchwork)})
out<-'results';pbdir<-file.path(out,'verified_pseudobulk')
s<-read_csv(file.path(pbdir,'pseudobulk_sample_retention.csv'),show_col_types=FALSE)
g<-read_csv(file.path(pbdir,'ECM_integrin_threshold_results.csv'),show_col_types=FALSE)
r<-read_csv(file.path(out,'regression_sensitivity.csv'),show_col_types=FALSE)
defs<-c('full_dedicated','cd90_exact','strict_atlas_overlap')
labsdef<-c(full_dedicated='Primary',cd90_exact='CD90-positive',strict_atlas_overlap='Strict atlas')
theme_set(theme_classic(base_size=8,base_family='sans')+theme(plot.title=element_text(size=9,face='bold'),axis.text=element_text(colour='black'),strip.background=element_blank(),strip.text=element_text(size=8,face='bold'),plot.tag=element_text(size=14,face='bold'),legend.position='bottom'))
ret<-s |> filter(definition%in%defs,model=='disease_only') |> pivot_longer(c(n_Ctrl,n_SSc),names_to='disease',values_to='n') |> mutate(disease=ifelse(disease=='n_Ctrl','Ctrl','SSc'),definition=factor(definition,levels=defs))
a<-ggplot(ret,aes(min_cells,n,colour=disease,shape=disease))+geom_line(linewidth=.5)+geom_point(size=2)+
 facet_wrap(~definition,nrow=1,labeller=as_labeller(labsdef))+scale_x_continuous(breaks=c(5,10,20,30))+scale_colour_manual(values=c(Ctrl='#2787A0',SSc='#C34F4B'))+scale_shape_manual(values=c(Ctrl=16,SSc=17))+
 labs(title='Participant retention as the ECM-high cell threshold increases',x='Minimum ECM-high cells per participant',y='Participants',colour=NULL,shape=NULL)
gg<-g |> filter(collection=='global',model=='disease_only',definition%in%defs) |>
 mutate(pathway=ifelse(grepl('EXTRACELLULAR',pathway),'ECM organization','Integrin interactions'),significance=ifelse(padj<.05,'FDR < 0.05','FDR >= 0.05'),definition=factor(definition,levels=defs))
b<-ggplot(gg,aes(min_cells,NES,colour=pathway,group=pathway))+geom_line(linewidth=.5)+geom_point(aes(shape=significance),size=2.3)+
 facet_wrap(~definition,nrow=1,labeller=as_labeller(labsdef))+scale_x_continuous(breaks=c(5,10,20,30))+scale_colour_manual(values=c('ECM organization'='#475D74','Integrin interactions'='#AA7845'))+scale_shape_manual(values=c('FDR < 0.05'=16,'FDR >= 0.05'=1))+
 labs(title='Global Hallmark/Reactome enrichment',subtitle='Strict atlas: thresholds 20 and 30 not estimable (no controls retained)',x='Minimum ECM-high cells per participant',y='Normalized enrichment score',colour=NULL,shape=NULL)
rr<-r |> filter(grepl('^Myeloid_ge',analysis)) |> mutate(threshold=as.numeric(sub('Myeloid_ge([0-9]+).*','\\1',analysis)),label=paste0('>=',threshold,' (n=',n,')'))
rr$label<-factor(rr$label,levels=rev(rr$label))
rr<-bind_rows(rr |> transmute(label,method='Ordinary',beta,low=ci_low,high=ci_high),rr |> transmute(label,method='HC3',beta,low=hc3_ci_low,high=hc3_ci_high))
c<-ggplot(rr,aes(beta,label,colour=method,shape=method))+geom_vline(xintercept=0,linetype=2,colour='grey50')+
 geom_errorbar(aes(xmin=low,xmax=high),orientation='y',width=.15,position=position_dodge(width=.45))+geom_point(size=2,position=position_dodge(width=.45))+
 scale_colour_manual(values=c(Ordinary='#475D74',HC3='#AA7845'))+labs(title='Myeloid-cell eligibility sensitivity',subtitle='Perivascular eligibility held at >=5 cells',x='Adjusted coefficient (95% CI)',y='Minimum myeloid cells',colour=NULL,shape=NULL)
ext<-g |> filter(collection=='global',definition=='external',min_cells%in%c(5,100)) |> mutate(pathway=ifelse(grepl('EXTRACELLULAR',pathway),'ECM organization','Integrin interactions'),threshold=ifelse(min_cells==5,'>=5 to >=50 (n=22)','>=100 (n=21)'))
e<-ggplot(ext,aes(NES,pathway,colour=threshold,shape=threshold))+geom_point(size=2.5,position=position_dodge(width=.4))+
 scale_colour_manual(values=c('>=5 to >=50 (n=22)'='#475D74','>=100 (n=21)'='#AA7845'))+
 labs(title='Independent perivascular cohort',subtitle='All shown pathways: global FDR < 0.05',x='Normalized enrichment score',y=NULL,colour=NULL,shape=NULL)+guides(colour=guide_legend(ncol=1),shape=guide_legend(ncol=1))
fig<-a/b/(c|e)+plot_layout(heights=c(1,1.2,1.2))+plot_annotation(tag_levels='A')
save_pdf<-function(plot,path,width_mm,height_mm){
 if(file.exists('/opt/X11/lib/libXrender.1.dylib')) grDevices::cairo_pdf(path,width=width_mm/25.4,height=height_mm/25.4,family='sans')
 else grDevices::pdf(path,width=width_mm/25.4,height=height_mm/25.4,family='Helvetica',useDingbats=FALSE)
 print(plot);dev.off()
}
save_pdf(fig,file.path(out,'Cell_threshold_sensitivity.pdf'),183,225)
svglite::svglite(file.path(out,'Cell_threshold_sensitivity.svg'),width=183/25.4,height=225/25.4);print(fig);dev.off()
ggsave(file.path(out,'Cell_threshold_sensitivity.png'),fig,width=183,height=225,units='mm',dpi=300,device=ragg::agg_png)
write_csv(gg,file.path(out,'threshold_figure_enrichment_source.csv'))
