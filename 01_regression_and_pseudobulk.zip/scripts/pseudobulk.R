suppressPackageStartupMessages({library(Matrix);library(edgeR);library(dplyr);library(tidyr);library(readr);library(tibble);library(fgsea)})
out<-'results/verified_pseudobulk'
dir.create(file.path(out,'pseudobulk'),recursive=TRUE,showWarnings=FALSE)
dir.create(file.path(out,'gene_sets'),recursive=TRUE,showWarnings=FALSE)
pb_list<-readRDS('inputs/aggregated_counts_and_metadata.rds')
definitions<-setNames(vector('list',3),c('full_dedicated','cd90_exact','strict_atlas_overlap'))
glob<-read_csv('inputs/global_Hallmark_Reactome.csv',show_col_types=FALSE)
focused<-read_csv('inputs/focused_collection.csv',show_col_types=FALSE)
sets<-list(global=split(glob$gene_symbol,glob$gs_name),focused=split(focused$gene_symbol,focused$gs_name))
sets<-lapply(sets,function(s)lapply(s,unique))
orig<-read_csv('inputs/original_discovery_edgeR.csv',show_col_types=FALSE) |> filter(model=='disease_only')
origshared<-data.frame() # No genuine shared-batch comparisons exist in these data.
origext<-read_csv('inputs/original_external_edgeR.csv',show_col_types=FALSE)
grid<-expand_grid(definition=names(definitions),min_cells=c(5,10,20,30),model=c('disease_only','shared_batch'))
grid<-bind_rows(grid,tibble(definition='external',min_cells=c(5,10,20,30,50,100),model='chemistry_adjusted'))
summaries<-list(); concordances<-list(); membership<-list(); gsall<-list(); targets<-list(); memo<-list()
frozen<-read_csv('inputs/frozen_targets.csv',show_col_types=FALSE)$target
runfit<-function(pbobj,sm,external=FALSE,shared=FALSE){
 sm$disease_group<-factor(sm$disease_group,levels=c('Ctrl','SSc'))
 if(external){sm$chemistry<-factor(sm$chemistry,levels=c('V1','V2')); design<-model.matrix(~chemistry+disease_group,sm)}
 else if(shared){sm$amp_batch<-factor(sm$amp_batch);design<-model.matrix(~amp_batch+disease_group,sm)}
 else design<-model.matrix(~disease_group,sm)
 if(min(table(sm$disease_group))<3)stop('fewer than 3 participants in one disease group')
 if(qr(design)$rank<ncol(design))stop('rank-deficient design')
 if(nrow(design)-ncol(design)<3)stop('fewer than 3 residual degrees of freedom')
 y<-DGEList(pbobj$counts[,sm$patient_id,drop=FALSE]); keep<-filterByExpr(y,design=design)
 y<-calcNormFactors(y[keep,,keep.lib.sizes=FALSE]);y<-estimateDisp(y,design,robust=!external)
 fit<-glmQLFit(y,design,robust=TRUE)
 z<-topTags(glmQLFTest(fit,coef='disease_groupSSc'),n=Inf,sort.by='none')$table |> rownames_to_column('gene') |> as_tibble()
 list(de=z,df=nrow(design)-ncol(design))
}
for(i in seq_len(nrow(grid))){
 cfg<-grid[i,];def<-cfg$definition;t<-cfg$min_cells;mod<-cfg$model
 key<-paste(def,mod,t,sep='_');message('RUN ',i,'/',nrow(grid),' ',key)
 o<-pb_list[[def]];sm<-o$meta |> filter(n_cells>=t)
 if(mod=='shared_batch') {
  # Only unambiguous single-batch participant profiles can use a participant-level fixed batch factor.
  shared<-sm |> filter(n_batches==1) |> distinct(amp_batch,disease_group) |> count(amp_batch) |> filter(n==2) |> pull(amp_batch)
  sm<-sm |> filter(n_batches==1,amp_batch%in%shared)
 }
 membership[[key]]<-o$meta |> mutate(definition=def,min_cells=t,model=mod,included=patient_id%in%sm$patient_id,.before=1)
 sumrow<-cfg |> mutate(n_Ctrl=sum(sm$disease_group=='Ctrl'),n_SSc=sum(sm$disease_group=='SSc'),n_cells_retained=sum(sm$n_cells),n_shared_batches=if(mod=='shared_batch')n_distinct(sm$amp_batch) else NA_integer_)
 cachekey<-paste(def,mod,paste(sm$patient_id,collapse=';'),sep='|')
 if(cachekey%in%names(memo)) {ans<-memo[[cachekey]]; sumrow$identical_sample_set<-TRUE} else {
  ans<-tryCatch(runfit(o,sm,def=='external',mod=='shared_batch'),error=function(e)list(error=conditionMessage(e)))
  memo[[cachekey]]<-ans;sumrow$identical_sample_set<-FALSE
 }
 if(!is.null(ans$error)){summaries[[key]]<-sumrow |> mutate(status=if(nrow(sm)==0 && mod=='shared_batch')'not estimable: no genuine shared batch' else ans$error);next}
 z<-ans$de;write_csv(z,file.path(out,'pseudobulk',paste0(key,'_genes.csv.gz')))
 sumrow<-sumrow |> mutate(status='estimated',residual_df=ans$df,n_genes=nrow(z),n_FDR05=sum(z$FDR<.05))
 ref<-if(def=='external')origext else if(mod=='shared_batch')filter(origshared,definition==def) else filter(orig,definition==def)
 compare<-inner_join(select(ref,gene,baseline_logFC=logFC,baseline_FDR=FDR),select(z,gene,logFC,FDR),by='gene')
 cc<-cfg |> mutate(common_genes=nrow(compare),rho_logFC=cor(compare$baseline_logFC,compare$logFC,method='spearman'),sign_concordance=mean(sign(compare$logFC)==sign(compare$baseline_logFC)),
                  max_abs_logFC_change=max(abs(compare$logFC-compare$baseline_logFC)),n_baseline_significant_common=sum(compare$baseline_FDR<.05),
                  baseline_sig_direction_retention=mean(sign(compare$logFC[compare$baseline_FDR<.05])==sign(compare$baseline_logFC[compare$baseline_FDR<.05])))
 concordances[[key]]<-cc
 if(t==5 && cc$max_abs_logFC_change>1e-6)stop('Baseline failed exact gene-effect reproduction: ',key)
 targets[[key]]<-z |> filter(gene%in%frozen) |> mutate(definition=def,min_cells=t,model=mod,.before=1)
 ranks<-sign(z$logFC)*sqrt(z$F);names(ranks)<-z$gene;ranks<-sort(ranks[is.finite(ranks)],decreasing=TRUE)
 for(family in c('global','focused')){
  gkey<-paste(cachekey,family,sep='|'); seed<-20261012+i*10+match(family,c('global','focused'))
  if(gkey%in%names(memo)) gg<-memo[[gkey]] else {
   set.seed(seed);gg<-fgseaMultilevel(sets[[family]],ranks,minSize=10,maxSize=500,eps=0,nproc=1) |> as_tibble()
   gg$leadingEdge<-vapply(gg$leadingEdge,paste,collapse=';',FUN.VALUE=character(1));memo[[gkey]]<-gg
  }
  gsall[[paste(key,family)]]<-gg |> mutate(definition=def,min_cells=t,model=mod,collection=family,.before=1)
 }
 summaries[[key]]<-sumrow
 write_csv(bind_rows(summaries),file.path(out,'pseudobulk_sample_retention.csv'))
 write_csv(bind_rows(gsall),file.path(out,'all_threshold_GSEA.csv.gz'))
 write_csv(bind_rows(concordances),file.path(out,'pseudobulk_effect_concordance.csv'))
}
write_csv(bind_rows(summaries),file.path(out,'pseudobulk_sample_retention.csv'))
write_csv(bind_rows(membership),file.path(out,'pseudobulk_participant_inclusion.csv'))
write_csv(bind_rows(concordances),file.path(out,'pseudobulk_effect_concordance.csv'))
write_csv(bind_rows(targets),file.path(out,'frozen_target_threshold_results.csv'))
gg<-bind_rows(gsall);write_csv(gg,file.path(out,'all_threshold_GSEA.csv.gz'))
write_csv(gg |> filter(pathway%in%c('REACTOME_EXTRACELLULAR_MATRIX_ORGANIZATION','REACTOME_INTEGRIN_CELL_SURFACE_INTERACTIONS')),file.path(out,'ECM_integrin_threshold_results.csv'))
writeLines(capture.output(sessionInfo()),file.path(out,'pseudobulk_sessionInfo.txt'))
message('PSEUDOBULK COMPLETE');print(bind_rows(summaries),n=40)
