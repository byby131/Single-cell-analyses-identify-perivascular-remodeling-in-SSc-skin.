suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(patchwork)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(scales)
  library(Matrix)
})

# Figure contract
# Claim: an independent SSc skin cohort reproduces perivascular ECM activation
# and supports the cellular localization/association of the SEMA4D-PLXNB2 axis.
# Unit of inference for disease comparisons: participant (Ctrl n=10; SSc n=12).
# Archetype: asymmetric quantitative validation composite.

dir.create("outputs", showWarnings = FALSE, recursive = TRUE)
obj <- readRDS("work/GSE138669_annotated_focus.rds")
patient <- read_csv("outputs/Figure5_GSE138669_patient_level_variables.csv", show_col_types = FALSE)
stats <- read_csv("outputs/Figure5_GSE138669_patient_level_statistics.csv", show_col_types = FALSE)

pal <- c(Ctrl = "#1A8FB4", SSc = "#CB282A")
cell_pal <- c(Other = "#D5D5D5", Perivascular = "#F47E21", Myeloid = "#9067AC")
base_family <- "Helvetica"
theme_pub <- theme_classic(base_size = 7.2, base_family = base_family) +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "black"),
    axis.ticks = element_line(linewidth = 0.35, colour = "black"),
    axis.text = element_text(size = 6.3, colour = "black"),
    axis.title = element_text(size = 7),
    legend.title = element_text(size = 6.5),
    legend.text = element_text(size = 6.2),
    plot.title = element_text(size = 7.5, face = "bold", hjust = 0),
    plot.tag = element_text(size = 11, face = "bold"),
    panel.grid = element_blank(),
    plot.margin = margin(3, 4, 3, 3)
  )
theme_set(theme_pub)

emb <- as.data.frame(Embeddings(obj, "umap"))
names(emb)[1:2] <- c("UMAP_1", "UMAP_2")
emb$compartment <- factor(obj$focus_compartment,
                          levels = c("Other", "Perivascular", "Myeloid"))
set.seed(20260802)
emb <- emb[sample(seq_len(nrow(emb))), ]

pA <- ggplot(emb, aes(UMAP_1, UMAP_2, colour = compartment)) +
  geom_point(size = 0.12, alpha = 0.65, stroke = 0) +
  scale_colour_manual(values = cell_pal, breaks = c("Perivascular", "Myeloid", "Other")) +
  guides(colour = guide_legend(override.aes = list(size = 2.1, alpha = 1))) +
  coord_equal() +
  labs(x = "UMAP 1", y = "UMAP 2", colour = NULL,
       title = "Independent SSc skin cohort") +
  theme(axis.ticks = element_blank(), axis.text = element_blank(), axis.line = element_blank(),
        legend.position = c(0.78, 0.16), legend.background = element_rect(fill = alpha("white", .82), colour = NA),
        legend.key.height = unit(2.5, "mm"))

expr <- GetAssayData(obj, assay = "RNA", layer = "data")
md <- obj@meta.data
marker_genes <- intersect(c("LST1", "TYROBP", "FCER1G", "CTSS", "RGS5", "MCAM", "CSPG4", "PDGFRB"), rownames(expr))
focus_cells <- rownames(md)[md$focus_compartment %in% c("Myeloid", "Perivascular")]
dot <- lapply(c("Myeloid", "Perivascular"), function(ct) {
  cells <- rownames(md)[md$focus_compartment == ct]
  mat <- expr[marker_genes, cells, drop = FALSE]
  tibble(compartment = ct, gene = marker_genes,
         avg = Matrix::rowMeans(mat), pct = Matrix::rowMeans(mat > 0) * 100)
}) |> bind_rows() |>
  group_by(gene) |>
  mutate(avg_scaled = if (sd(avg) > 0) as.numeric(scale(avg)) else rep(0, n())) |>
  ungroup()
dot$gene <- factor(dot$gene, levels = marker_genes)
dot$compartment <- factor(dot$compartment, levels = c("Perivascular", "Myeloid"))
pB <- ggplot(dot, aes(gene, compartment, size = pct, colour = avg_scaled)) +
  geom_point() +
  scale_size(range = c(1.2, 6), limits = c(0, 100), name = "% expressed") +
  scale_colour_gradient2(low = "#D9E7EC", mid = "#F4D6B2", high = "#CB282A", midpoint = 0,
                         name = NULL) +
  labs(x = NULL, y = NULL, title = "Compartment identity") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, face = "italic"),
        legend.position = "right", legend.box = "vertical",
        legend.margin = margin(0, 0, 0, 0)) +
  guides(size = guide_legend(order = 2),
         colour = guide_colourbar(order = 1, barwidth = unit(2.4, "mm"), barheight = unit(16, "mm")))

feature_df <- emb
feature_df$SEMA4D <- as.numeric(expr["SEMA4D", rownames(emb)])
feature_df$PLXNB2 <- as.numeric(expr["PLXNB2", rownames(emb)])
feature_plot <- function(gene) {
  z <- feature_df[[gene]]
  cap <- unname(quantile(z[z > 0], 0.99, na.rm = TRUE))
  if (!is.finite(cap) || cap <= 0) cap <- max(z, na.rm = TRUE)
  ggplot(feature_df[order(z), ], aes(UMAP_1, UMAP_2, colour = .data[[gene]])) +
    geom_point(size = 0.12, alpha = 0.72, stroke = 0) +
    scale_colour_gradientn(colours = c("#E5E5E5", "#F6C5A5", "#CB282A"),
                           limits = c(0, cap), oob = squish, name = "Expression") +
    coord_equal() + labs(x = NULL, y = NULL, title = gene) +
    theme(axis.ticks = element_blank(), axis.text = element_blank(), axis.line = element_blank(),
          legend.position = "right", legend.key.height = unit(8, "mm"))
}
pC <- feature_plot("SEMA4D") + feature_plot("PLXNB2") +
  plot_layout(guides = "collect") & theme(legend.position = "right")

stat_d <- stats |> filter(metric == "peri_ECM_mean")
pD <- ggplot(patient, aes(disease_group, peri_ECM_mean, colour = disease_group)) +
  geom_boxplot(width = 0.48, outlier.shape = NA, colour = "black", fill = "white", linewidth = 0.38) +
  geom_jitter(width = 0.11, size = 2, alpha = 0.9) +
  scale_colour_manual(values = pal, guide = "none") +
  labs(x = NULL, y = "Perivascular ECM score", title = "ECM activation") +
  annotate("text", x = 1.5, y = max(patient$peri_ECM_mean) * 1.12,
           label = sprintf("Adjusted P = %.3g", stat_d$adjusted_p_SSc), size = 2.4, family = base_family) +
  coord_cartesian(ylim = c(min(patient$peri_ECM_mean) * 1.08, max(patient$peri_ECM_mean) * 1.22), clip = "off")

gene_long <- patient |>
  select(disease_group, peri_PLXNB2_mean, myeloid_SEMA4D_mean) |>
  pivot_longer(-disease_group, names_to = "measure", values_to = "value") |>
  mutate(measure = recode(measure,
                          peri_PLXNB2_mean = "PLXNB2 in perivascular cells",
                          myeloid_SEMA4D_mean = "SEMA4D in myeloid cells"))
pE <- ggplot(gene_long, aes(disease_group, value, colour = disease_group)) +
  geom_boxplot(width = 0.5, outlier.shape = NA, colour = "black", fill = "white", linewidth = 0.38) +
  geom_jitter(width = 0.11, size = 1.65, alpha = 0.9) +
  facet_wrap(~measure, scales = "free_y", nrow = 1) +
  scale_colour_manual(values = pal, guide = "none") +
  labs(x = NULL, y = "Mean normalized expression", title = "Ligand-receptor expression") +
  theme(strip.background = element_blank(), strip.text = element_text(size = 6.2, face = "italic")) +
  geom_text(data = tibble(measure = c("PLXNB2 in perivascular cells", "SEMA4D in myeloid cells"),
                          disease_group = 1.5, value = c(Inf, Inf), label = "ns"),
            aes(x = disease_group, y = value, label = label), colour = "black",
            vjust = 1.4, hjust = 0.5, size = 2.4, inherit.aes = FALSE)

rho <- cor.test(patient$myeloid_SEMA4D_pct, patient$peri_ECM_mean,
                method = "spearman", exact = FALSE)
fit_f <- lm(peri_ECM_mean ~ myeloid_SEMA4D_pct + disease_group + chemistry, data = patient)
adj_p <- coef(summary(fit_f))["myeloid_SEMA4D_pct", "Pr(>|t|)"]
pF <- ggplot(patient, aes(myeloid_SEMA4D_pct, peri_ECM_mean, colour = disease_group)) +
  geom_smooth(aes(group = 1), method = "lm", se = TRUE, colour = "#565656", fill = "#D9D9D9", linewidth = 0.55) +
  geom_point(size = 2.1, alpha = 0.92) +
  scale_colour_manual(values = pal, name = NULL) +
  labs(x = "SEMA4D+ myeloid cells (%)", y = "Perivascular ECM score",
       title = "Cross-compartment association") +
  annotate("text", x = Inf, y = -Inf, hjust = 1.05, vjust = -0.45, family = base_family, size = 2.35,
           label = sprintf("Spearman rho = %.2f\nAdjusted P = %.3g", unname(rho$estimate), adj_p)) +
  theme(legend.position = c(0.2, 0.84), legend.direction = "horizontal")

assembled <- ((pA + pB) + plot_layout(widths = c(1.08, 0.92))) /
  ((wrap_elements(full = pC) + pD) + plot_layout(widths = c(1.28, 0.72))) /
  ((pE + pF) + plot_layout(widths = c(1.10, 0.90))) +
  plot_layout(heights = c(1.00, 1.05, 0.92)) +
  plot_annotation(tag_levels = "A")

save_plot <- function(plot, stem, width_mm, height_mm, dpi = 600) {
  w <- width_mm / 25.4; h <- height_mm / 25.4
  ggsave(paste0(stem, ".png"), plot, width = w, height = h, units = "in", dpi = 300, bg = "white")
  ggsave(paste0(stem, ".tiff"), plot, width = w, height = h, units = "in", dpi = dpi,
         compression = "lzw", bg = "white", device = ragg::agg_tiff)
  ggsave(paste0(stem, ".pdf"), plot, width = w, height = h, units = "in", device = grDevices::pdf,
         family = "Helvetica", bg = "white", useDingbats = FALSE)
  ggsave(paste0(stem, ".svg"), plot, width = w, height = h, units = "in", device = svglite::svglite, bg = "white")
}

save_plot(pA, "outputs/Figure5A_GSE138669_UMAP", 88, 72)
save_plot(pB, "outputs/Figure5B_marker_dotplot", 88, 72)
save_plot(pC, "outputs/Figure5C_SEMA4D_PLXNB2_featureplots", 116, 72)
save_plot(pD, "outputs/Figure5D_perivascular_ECM", 66, 72)
save_plot(pE, "outputs/Figure5E_ligand_receptor_expression", 104, 68)
save_plot(pF, "outputs/Figure5F_SEMA4D_ECM_association", 80, 68)
save_plot(assembled, "outputs/Figure5_external_validation_assembly_v1", 183, 205)

write_lines(c(
  "Figure 5 source-data and statistics notes",
  "Cohort: GSE138669; Ctrl n=10 participants, SSc n=12 participants.",
  "Disease comparisons use participants, not cells, as independent observations.",
  sprintf("Panel D: chemistry-adjusted linear-model P = %.6g; BH-adjusted FDR across prespecified patient-level endpoints = %.6g.", stat_d$adjusted_p_SSc, stat_d$adjusted_FDR),
  sprintf("Panel F: Spearman rho = %.4f; association adjusted for disease group and chemistry P = %.6g.", unname(rho$estimate), adj_p),
  "Panel E: both disease comparisons are non-significant after chemistry adjustment; shown for localization/context, not evidence of upregulation.",
  "Association does not establish causality."
), "outputs/Figure5_external_validation_QA_notes.txt")

message("Figure 5 exports complete.")
