suppressPackageStartupMessages({
  library(Seurat)
  library(dplyr)
  library(readr)
})

in_dir <- "work/GSE138669_raw"
out_rds <- "work/GSE138669_QC_merged.rds"
out_qc <- "outputs/Figure5_GSE138669_sample_QC.csv"
files <- sort(list.files(in_dir, pattern = "\\.h5$", full.names = TRUE))
stopifnot(length(files) == 22)

read_one <- function(path) {
  sample_id <- sub("raw_feature_bc_matrix\\.h5$", "",
                   sub("^GSM[0-9]+_", "", basename(path)))
  gsm <- sub("_.*$", "", basename(path))
  counts <- Read10X_h5(path, use.names = TRUE, unique.features = TRUE)
  obj <- CreateSeuratObject(counts, project = sample_id, min.cells = 3,
                            min.features = 200)
  obj$sample_id <- sample_id
  obj$gsm <- gsm
  obj[["percent.mt"]] <- PercentageFeatureSet(obj, pattern = "^MT-")
  before <- ncol(obj)
  obj <- subset(obj, subset = nFeature_RNA >= 200 & nFeature_RNA <= 6500 &
                  nCount_RNA <= 50000 & percent.mt < 20)
  qc <- tibble(
    sample_id = sample_id, gsm = gsm, cells_before_qc = before,
    cells_after_qc = ncol(obj), median_genes = median(obj$nFeature_RNA),
    median_UMI = median(obj$nCount_RNA), median_percent_mt = median(obj$percent.mt)
  )
  list(obj = obj, qc = qc)
}

res <- lapply(files, read_one)
qc <- bind_rows(lapply(res, `[[`, "qc"))
write_csv(qc, out_qc)

objs <- lapply(res, `[[`, "obj")
names(objs) <- qc$sample_id
merged <- merge(objs[[1]], y = objs[-1], add.cell.ids = names(objs),
                project = "GSE138669")
merged <- NormalizeData(merged, verbose = FALSE)
merged <- FindVariableFeatures(merged, nfeatures = 3000, verbose = FALSE)
merged <- ScaleData(merged, features = VariableFeatures(merged), verbose = FALSE)
merged <- RunPCA(merged, npcs = 40, verbose = FALSE)
merged <- FindNeighbors(merged, dims = 1:30, verbose = FALSE)
merged <- FindClusters(merged, resolution = 0.6, verbose = FALSE)
merged <- RunUMAP(merged, dims = 1:30, seed.use = 20260802, verbose = FALSE)

saveRDS(merged, out_rds, compress = FALSE)
cat("Saved", ncol(merged), "QC-passing cells across", length(unique(merged$sample_id)),
    "samples\n")
print(qc)
