suppressPackageStartupMessages(library(magick))

out_dir <- "outputs"
files <- c(
  A=file.path(out_dir,"Figure3A_expression_gated_NicheNet_ranking.png"),
  B=file.path(out_dir,"Figure3B_candidate_evidence_matrix.png"),
  C=file.path(out_dir,"Figure3C_SEMA4D_PLXNB2_expression_gate.png"),
  D=file.path(out_dir,"Figure3D_SEMA4D_predicted_targets.png"),
  E=file.path(out_dir,"Figure3E_SEMA4D_PLXNB2_state_aligned_maps.png")
)
stopifnot(all(file.exists(files)))

panel <- function(path, width, height, label) {
  im <- image_read(path) |>
    image_resize(paste0(width,"x",height)) |>
    image_extent(paste0(width,"x",height), gravity="center", color="white")
  image_annotate(im, label, gravity="northwest", location="+8+5",
                 size=28, font="Helvetica", weight=700, color="black")
}
spacer_h <- function(width, height=18) image_blank(width,height,"white")
spacer_v <- function(width=18, height) image_blank(width,height,"white")

A <- panel(files[["A"]], 720, 650, "A")
B <- panel(files[["B"]], 1060, 650, "B")
row1 <- image_append(c(A,spacer_v(20,650),B), stack=FALSE)

C <- panel(files[["C"]], 960, 650, "C")
D <- panel(files[["D"]], 820, 650, "D")
row2 <- image_append(c(C,spacer_v(20,650),D), stack=FALSE)

E <- panel(files[["E"]], 1800, 1375, "E")
assembled <- image_append(c(row1,spacer_h(1800),row2,spacer_h(1800),E), stack=TRUE)
assembled <- image_border(assembled, "white", "15x15")
image_write(assembled, file.path(out_dir,"Figure3_assembly_preview_current_v1.png"), format="png")
