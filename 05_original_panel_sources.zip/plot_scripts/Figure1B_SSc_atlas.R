suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(ggrepel)
  library(svglite)
  library(ragg)
})

input_rds <- "/Users/baoying/Desktop/巨噬细胞/Candidate_axis_competition_Peri_RGS5/sce_skin_with_candidate_axis_scores.rds"
out_base <- "outputs/Figure1B_SSc_skin_cell_atlas"
width_mm <- 89
height_mm <- 82

obj <- readRDS(input_rds)
stopifnot("umap" %in% names(obj@reductions), "annotation" %in% colnames(obj[[]]))

um <- as.data.frame(Embeddings(obj, "umap"))
colnames(um)[1:2] <- c("UMAP_1", "UMAP_2")
um$annotation <- as.character(obj[[]][rownames(um), "annotation"])

lineage_from_annotation <- function(x) {
  out <- rep("Other", length(x))
  out[grepl("^Fibro_", x)] <- "Fibroblasts"
  out[grepl("^Peri_", x)] <- "Pericytes"
  out[grepl("^(Vascular_|Lymphatic_)", x)] <- "Endothelial"
  out[grepl("^(M_|Mf|Mo|DC|pDC|LC$)", x)] <- "Myeloid / DC"
  out[grepl("^(T_|sT|Treg|sTreg|NK)", x)] <- "T / NK cells"
  out[grepl("^(KRT|GBP1$)", x)] <- "Keratinocytes"
  out[grepl("^Mast", x)] <- "Mast cells"
  out[grepl("^(B$|B_|Plasma$)", x)] <- "B / Plasma cells"
  out[grepl("^Melanocytes", x)] <- "Melanocytes"
  out
}

um$lineage <- lineage_from_annotation(um$annotation)
lineage_levels <- c("Fibroblasts", "Pericytes", "Endothelial", "Myeloid / DC",
                    "T / NK cells", "B / Plasma cells", "Mast cells",
                    "Keratinocytes", "Melanocytes", "Other")
um$lineage <- factor(um$lineage, levels = lineage_levels)

palette <- c(
  "Fibroblasts"="#D9A46F", "Pericytes"="#6A9F93", "Endothelial"="#77A9C8",
  "Myeloid / DC"="#C65B67", "T / NK cells"="#7D6AAF", "B / Plasma cells"="#A98BC2",
  "Mast cells"="#D89A45", "Keratinocytes"="#E6B5AA", "Melanocytes"="#8B6A58",
  "Other"="#BDBDBD"
)

# Median coordinates provide stable direct labels without changing or sampling cells.
cent <- aggregate(cbind(UMAP_1, UMAP_2) ~ lineage, data=um, FUN=median)
cent$n <- as.integer(table(um$lineage)[as.character(cent$lineage)])
cent <- cent[cent$n >= 50 & cent$lineage != "Other", ]

p <- ggplot(um, aes(UMAP_1, UMAP_2, colour=lineage)) +
  geom_point(size=0.22, alpha=0.72, stroke=0) +
  geom_label_repel(
    data=cent, aes(label=lineage), colour="#222222", fill=scales::alpha("white",0.86),
    size=2.15, family="Helvetica", fontface="bold", label.size=0,
    box.padding=0.18, point.padding=0.12, min.segment.length=0,
    segment.colour="#6C6C6C", segment.size=0.25, seed=11,
    show.legend=FALSE, max.overlaps=Inf
  ) +
  scale_colour_manual(values=palette, drop=FALSE) +
  coord_equal() +
  labs(title="SSc skin cell atlas", subtitle="GSE195452 | 24,988 cells", x="UMAP 1", y="UMAP 2") +
  theme_classic(base_size=7, base_family="Helvetica") +
  theme(
    plot.title=element_text(size=9, face="bold", margin=margin(b=1.5)),
    plot.subtitle=element_text(size=6.4, colour="#626262", margin=margin(b=4)),
    axis.title=element_text(size=6.5), axis.text=element_blank(), axis.ticks=element_blank(),
    axis.line=element_line(linewidth=0.35, colour="#222222"),
    legend.position="none", plot.margin=margin(5,5,4,5)
  )

svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                 system_fonts=list(sans="Arial"), pointsize=7)
print(p); dev.off()

pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
    family="Helvetica", pointsize=7, useDingbats=FALSE)
print(p); dev.off()

ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
               units="in", res=600, compression="lzw", background="white")
print(p); dev.off()

ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
              units="in", res=300, background="white")
print(p); dev.off()

write.csv(as.data.frame(table(um$lineage)), paste0(out_base,"_cell_counts.csv"), row.names=FALSE)
