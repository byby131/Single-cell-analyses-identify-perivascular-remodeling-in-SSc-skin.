suppressPackageStartupMessages({
  library(ggplot2)
  library(svglite)
  library(ragg)
})

data_file <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_Ctrl_SSc_ECM_figures/Table_patient_level_ECM_state_fraction_long.csv"
stat_file <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_Ctrl_SSc_ECM_figures/Table_stat_Ctrl_vs_SSc_patient_level_ECM_high_fraction.csv"
out_base <- "outputs/Figure2F_patient_ECM_high_fraction_Cell_palette_v1"
width_mm <- 58
height_mm <- 68

dat <- read.csv(data_file, check.names=FALSE)
st_original <- read.csv(stat_file, check.names=FALSE)
min_cells_cutoff <- 5
dat <- dat[dat$ECM_state == "ECM-high" & dat$total_peri_rgs5_cells >= min_cells_cutoff, ]
dat$disease_group <- factor(dat$disease_group, levels=c("Ctrl","SSc"))
dat$fraction_percent <- dat$fraction * 100
ctrl <- dat$fraction[dat$disease_group == "Ctrl"]
ssc <- dat$fraction[dat$disease_group == "SSc"]
wt <- wilcox.test(ctrl, ssc, exact=FALSE)
st <- data.frame(
  comparison="Ctrl_vs_SSc", level="patient-level",
  min_cells_cutoff=min_cells_cutoff,
  n_Ctrl=length(ctrl), n_SSc=length(ssc),
  median_Ctrl=median(ctrl), median_SSc=median(ssc),
  mean_Ctrl=mean(ctrl), mean_SSc=mean(ssc),
  p_value=unname(wt$p.value), test="Wilcoxon rank-sum (two-sided)",
  original_table_n_Ctrl=st_original$n_Ctrl[1],
  original_table_n_SSc=st_original$n_SSc[1],
  original_table_p_value=st_original$p_value[1]
)

cols <- c("Ctrl"="#1A8FB4", "SSc"="#CB282A")
p_label <- paste0("P = ", formatC(st$p_value, format="f", digits=3),
                  "\nn = ", st$n_Ctrl, " / ", st$n_SSc)

p <- ggplot(dat, aes(disease_group, fraction_percent,
                     colour=disease_group, fill=disease_group)) +
  geom_boxplot(width=0.52, outlier.shape=NA, linewidth=0.55, alpha=0.18) +
  geom_jitter(width=0.13, height=0, size=1.28, alpha=0.86, stroke=0) +
  stat_summary(fun=median, geom="crossbar", width=0.50, linewidth=0.65,
               colour="#222222") +
  annotate("segment", x=1, xend=2, y=106, yend=106, linewidth=0.38) +
  annotate("segment", x=1, xend=1, y=103, yend=106, linewidth=0.38) +
  annotate("segment", x=2, xend=2, y=103, yend=106, linewidth=0.38) +
  annotate("text", x=1.5, y=113, label=p_label, family="Helvetica",
           size=2.25, lineheight=0.94, colour="#222222") +
  scale_colour_manual(values=cols) + scale_fill_manual(values=cols) +
  scale_y_continuous(limits=c(0,118), breaks=c(0,25,50,75,100),
                     expand=expansion(mult=c(0,0))) +
  labs(x=NULL, y="ECM-high cells (%)") +
  theme_classic(base_size=7, base_family="Helvetica") +
  theme(
    axis.title.y=element_text(size=7, margin=margin(r=3)),
    axis.text.x=element_text(size=7, face="bold"), axis.text.y=element_text(size=6.3),
    axis.line=element_line(linewidth=0.35), axis.ticks=element_line(linewidth=0.35),
    legend.position="none", plot.margin=margin(4,3,3,4)
  )

svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                 system_fonts=list(sans="Arial"), pointsize=7)
print(p); dev.off()
pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
    family="Helvetica", pointsize=7, useDingbats=FALSE)
print(p); dev.off()
ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
               units="in", res=600, compression="lzw", background="white")
print(p); dev.off()
ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
              units="in", res=300, background="white")
print(p); dev.off()
write.csv(dat, paste0(out_base,"_source_data.csv"), row.names=FALSE)
write.csv(st, paste0(out_base,"_statistics.csv"), row.names=FALSE)
