suppressPackageStartupMessages(library(magick))

out <- "outputs"
files <- c(
  A=file.path(out,"Figure3A_expression_gated_NicheNet_ranking.png"),
  B=file.path(out,"Figure3B_candidate_evidence_matrix.png"),
  C=file.path(out,"SEMA4D_cross_lineage_audit/Figure3C_SEMA4D_immune_lineages.png"),
  D=file.path(out,"SEMA4D_cross_lineage_audit/Figure3D_patient_paired_T_vs_myeloid.png"),
  E=file.path(out,"Figure3D_SEMA4D_predicted_targets.png"),
  F=file.path(out,"Figure3E_SEMA4D_PLXNB2_state_aligned_maps.png")
)
stopifnot(all(file.exists(files)))

panel <- function(path, width, height, label) {
  im <- image_read(path) |>
    image_trim(fuzz=3) |>
    image_resize(paste0(width,"x",height)) |>
    image_extent(paste0(width,"x",height), gravity="center", color="white")
  image_annotate(im,label,gravity="northwest",location="+8+4",
                 size=30,font="Helvetica",weight=700,color="black")
}
gap_v <- function(width=22,height) image_blank(width,height,"white")
gap_h <- function(width,height=22) image_blank(width,height,"white")

A <- panel(files[["A"]],700,610,"A")
B <- panel(files[["B"]],1080,610,"B")
row1 <- image_append(c(A,gap_v(20,610),B),stack=FALSE)
C <- panel(files[["C"]],700,590,"C")
D <- panel(files[["D"]],1080,590,"D")
row2 <- image_append(c(C,gap_v(20,590),D),stack=FALSE)
E <- panel(files[["E"]],610,760,"E")
F <- panel(files[["F"]],1170,760,"F")
row3 <- image_append(c(E,gap_v(20,760),F),stack=FALSE)

fig <- image_append(c(row1,gap_h(1800),row2,gap_h(1800),row3),stack=TRUE) |>
  image_border("white","15x15")
image_write(fig,file.path(out,"Figure3_revised_assembly_v4.png"),format="png")
ragg::agg_tiff(file.path(out,"Figure3_revised_assembly_v4.tiff"),width=183/25.4,height=198/25.4,
               units="in",res=600,background="white",compression="lzw")
grid::grid.raster(as.raster(fig),width=grid::unit(1,"npc"),height=grid::unit(1,"npc"))
dev.off()

pdf(file.path(out,"Figure3_revised_assembly_v4.pdf"),width=183/25.4,height=198/25.4,
    family="Helvetica",useDingbats=FALSE)
plot.new(); rasterImage(as.raster(fig),0,0,1,1)
dev.off()
if (FALSE && capabilities("cairo")) {
  cairo_pdf(file.path(out,"Figure3_revised_assembly_v4_cairo.pdf"),width=183/25.4,height=198/25.4,family="Helvetica")
  grid::grid.raster(as.raster(fig)); dev.off()
}
svglite::svglite(file.path(out,"Figure3_revised_assembly_v4.svg"),width=183/25.4,height=198/25.4,bg="white")
grid::grid.raster(as.raster(fig),width=grid::unit(1,"npc"),height=grid::unit(1,"npc"))
dev.off()

# A4 portrait global preview: exact 210 x 297 mm (sqrt(2) paper ratio).
# Content is unchanged; additional white space is distributed symmetrically.
a4_canvas <- image_extent(fig,"1830x2588",gravity="center",color="white")
a4_preview <- image_resize(a4_canvas,"2480x3508!") # exact A4 at 300 dpi
image_write(a4_preview,file.path(out,"Figure3_revised_assembly_v4_A4.png"),format="png",density="300x300")

ragg::agg_tiff(file.path(out,"Figure3_revised_assembly_v4_A4.tiff"),width=210/25.4,height=297/25.4,
               units="in",res=600,background="white",compression="lzw")
grid::grid.raster(as.raster(a4_canvas),width=grid::unit(1,"npc"),height=grid::unit(1,"npc"))
dev.off()

pdf(file.path(out,"Figure3_revised_assembly_v4_A4.pdf"),width=210/25.4,height=297/25.4,
    family="Helvetica",useDingbats=FALSE)
plot.new(); rasterImage(as.raster(a4_canvas),0,0,1,1)
dev.off()
svglite::svglite(file.path(out,"Figure3_revised_assembly_v4_A4.svg"),width=210/25.4,height=297/25.4,bg="white")
grid::grid.raster(as.raster(a4_canvas),width=grid::unit(1,"npc"),height=grid::unit(1,"npc"))
dev.off()

writeLines(c(
  "Figure 3 revised six-panel assembly v4",
  "A4 global preview exports are exactly 210 x 297 mm; PNG is 2480 x 3508 px at 300 dpi and TIFF is 600 dpi.",
  "Core conclusion: SEMA4D-PLXNB2 is a prioritised low-frequency candidate axis; SEMA4D is not myeloid-exclusive.",
  "Panel C is a recovered-cell descriptive summary and must not be used for patient-level inference.",
  "Panel D uses paired participants with at least 10 recovered cells in both T-cell and myeloid lineages.",
  "In SSc, T-cell SEMA4D detection exceeds myeloid detection within participants (n=39; paired Wilcoxon P=0.000633).",
  "The Ctrl paired comparison is underpowered (n=5; P=0.1).",
  "NicheNet target links and separate UMAPs do not establish direct signalling or spatial contact."
),file.path(out,"Figure3_revised_assembly_v4_QA_notes.txt"))
