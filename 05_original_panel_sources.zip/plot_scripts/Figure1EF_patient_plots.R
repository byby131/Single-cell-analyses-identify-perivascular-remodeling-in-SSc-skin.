suppressPackageStartupMessages({
  library(ggplot2)
  library(svglite)
  library(ragg)
})

data_file <- "/Users/baoying/Desktop/巨噬细胞/Within_lineage_publication_analysis/Patient_level_within_lineage_zero_filled_FULL.csv"
stat_file <- "/Users/baoying/Desktop/巨噬细胞/Within_lineage_publication_analysis/Table_within_lineage_fraction_Wilcoxon_effect_size_min20.csv"
dat_all <- read.csv(data_file, check.names=FALSE)
st_all <- read.csv(stat_file, check.names=FALSE)
cols <- c("Ctrl"="#718EA5", "SSc"="#C85E62")

fmt_prob <- function(x, prefix) {
  if (x < 0.001) paste0(prefix, " < 0.001")
  else paste0(prefix, " = ", formatC(x, format="f", digits=3))
}

make_panel <- function(annotation, title, out_base) {
  dat <- dat_all[dat_all$annotation == annotation, ]
  st <- st_all[st_all$annotation == annotation, ]
  stopifnot(nrow(dat) > 0, nrow(st) == 1)
  dat$disease_group <- factor(dat$disease_group, levels=c("Ctrl", "SSc"))
  label <- paste0(fmt_prob(st$p_value, "P"), "; ", fmt_prob(st$FDR, "FDR"),
                  "\nCliff's delta = ", sprintf("%.2f", st$cliffs_delta),
                  " (", st$effect_size, ")",
                  "\nn = ", st$n_Ctrl, " / ", st$n_SSc)
  ymax <- max(dat$fraction_within_lineage, na.rm=TRUE)
  ann_y <- max(ymax * 1.08, st$median_SSc * 1.16 + 1)

  p <- ggplot(dat, aes(disease_group, fraction_within_lineage,
                       colour=disease_group, fill=disease_group)) +
    geom_boxplot(width=0.52, outlier.shape=NA, linewidth=0.45, alpha=0.20) +
    geom_jitter(width=0.13, height=0, size=1.15, alpha=0.78, stroke=0) +
    stat_summary(fun=median, geom="crossbar", width=0.50, linewidth=0.55,
                 colour="#222222") +
    annotate("text", x=1.5, y=ann_y, label=label, family="Helvetica",
             size=2.15, lineheight=0.94, colour="#303030") +
    scale_colour_manual(values=cols) + scale_fill_manual(values=cols) +
    scale_y_continuous(expand=expansion(mult=c(0.03,0.25))) +
    labs(x=NULL, y="Fraction within lineage (%)", title=title) +
    theme_classic(base_size=7, base_family="Helvetica") +
    theme(
      plot.title=element_text(size=7.4, face="bold", hjust=0.5,
                              margin=margin(b=4), lineheight=0.95),
      axis.title.y=element_text(size=6.6, margin=margin(r=3)),
      axis.text.x=element_text(size=6.7, face="bold"),
      axis.text.y=element_text(size=6),
      axis.line=element_line(linewidth=0.35), axis.ticks=element_line(linewidth=0.35),
      legend.position="none", plot.margin=margin(4,3,3,4)
    )

  width_mm <- 44; height_mm <- 66
  svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                   system_fonts=list(sans="Arial"), pointsize=7)
  print(p); dev.off()
  pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
      family="Helvetica", pointsize=7, useDingbats=FALSE)
  print(p); dev.off()
  ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
                 units="in", res=600, compression="lzw", background="white")
  print(p); dev.off()
  ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
                units="in", res=300, background="white")
  print(p); dev.off()
  write.csv(dat, paste0(out_base,"_source_data.csv"), row.names=FALSE)
  write.csv(st, paste0(out_base,"_statistics.csv"), row.names=FALSE)
}

make_panel("M_IL1B", "Inflammatory myeloid\n(M_IL1B)",
           "outputs/Figure1E_M_IL1B_patient_fraction")
make_panel("Peri_RGS5", "RGS5+ pericytes\n(Peri_RGS5)",
           "outputs/Figure1F_Peri_RGS5_patient_fraction")
