suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(svglite)
  library(ragg)
})

input_rds <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_Ctrl_SSc_ECM_figures/peri_all_Ctrl_SSc_ECM_state_processed.rds"
out_base <- "outputs/Figure2C_Peri_RGS5_marker_featureplots"
width_mm <- 142
height_mm <- 44
genes <- c("MYH11", "COL1A1", "COL3A1", "POSTN")

obj <- readRDS(input_rds)
missing_genes <- setdiff(genes, rownames(obj))
if (length(missing_genes) > 0) stop("Missing genes: ", paste(missing_genes, collapse=", "))

um <- as.data.frame(Embeddings(obj, "umap"))
colnames(um)[1:2] <- c("UMAP_1", "UMAP_2")
expr <- FetchData(obj, vars=genes, layer="data")[rownames(um), , drop=FALSE]

# Scale each gene only for visualization so spatial patterns remain visible despite
# different absolute expression ranges; raw normalized expression is retained below.
long <- do.call(rbind, lapply(genes, function(g) {
  x <- as.numeric(expr[[g]])
  cap <- as.numeric(quantile(x, 0.99, na.rm=TRUE))
  if (!is.finite(cap) || cap <= 0) cap <- max(x, na.rm=TRUE)
  rel <- if (cap > 0) pmin(x / cap, 1) else rep(0, length(x))
  data.frame(cell_id=rownames(um), UMAP_1=um$UMAP_1, UMAP_2=um$UMAP_2,
             gene=g, expression=x, relative_expression=rel)
}))
long$gene <- factor(long$gene, levels=genes)
long <- long[order(long$gene, long$relative_expression), ]

p <- ggplot(long, aes(UMAP_1, UMAP_2, colour=relative_expression)) +
  geom_point(size=0.18, alpha=0.90, stroke=0) +
  facet_wrap(~gene, nrow=1) +
  scale_colour_gradientn(colours=c("#E9E9E9", "#F29979", "#E25543", "#CB282A"),
                         limits=c(0,1), breaks=c(0,0.5,1),
                         name="Relative\nexpression") +
  coord_equal() +
  labs(x="UMAP 1", y="UMAP 2") +
  theme_classic(base_size=7, base_family="Helvetica") +
  theme(
    strip.background=element_blank(),
    strip.text=element_text(size=7.3, face="bold", margin=margin(b=3)),
    axis.title=element_text(size=6.4), axis.text=element_blank(),
    axis.ticks=element_blank(), axis.line=element_line(linewidth=0.35),
    panel.spacing=grid::unit(3.5,"mm"),
    legend.title=element_text(size=6.1), legend.text=element_text(size=5.8),
    legend.key.height=grid::unit(14,"mm"),
    plot.margin=margin(4,3,3,3)
  ) +
  guides(colour=guide_colourbar(barwidth=grid::unit(2.8,"mm"),
                                barheight=grid::unit(17,"mm")))

svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                 system_fonts=list(sans="Arial"), pointsize=7)
print(p); dev.off()
pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
    family="Helvetica", pointsize=7, useDingbats=FALSE)
print(p); dev.off()
ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
               units="in", res=600, compression="lzw", background="white")
print(p); dev.off()
ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
              units="in", res=300, background="white")
print(p); dev.off()
write.csv(long, paste0(out_base,"_source_data.csv"), row.names=FALSE)
