suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(svglite)
  library(ragg)
})

input_rds <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_Ctrl_SSc_ECM_figures/peri_all_Ctrl_SSc_ECM_state_processed.rds"
out_base <- "outputs/Figure2B_Peri_RGS5_ECM_state_UMAP_Cell_palette_v3"
width_mm <- 78
height_mm <- 67

obj <- readRDS(input_rds)
stopifnot("umap" %in% names(obj@reductions), "ECM_state" %in% colnames(obj[[]]))
um <- as.data.frame(Embeddings(obj, "umap"))
colnames(um)[1:2] <- c("UMAP_1", "UMAP_2")
um$cell_id <- rownames(um)
um$ECM_state <- factor(obj[[]][rownames(um), "ECM_state"],
                       levels=c("ECM-low", "ECM-high"))
um$disease_group <- obj[[]][rownames(um), "disease_group"]
um$patient_id <- obj[[]][rownames(um), "patient_id"]
stopifnot(!anyNA(um$ECM_state))

counts <- table(um$ECM_state)
legend_labels <- c(
  "ECM-low"=paste0("ECM-low (", format(counts[["ECM-low"]], big.mark=","), ")"),
  "ECM-high"=paste0("ECM-high (", format(counts[["ECM-high"]], big.mark=","), ")")
)
cols <- c("ECM-low"="#1A8FB4", "ECM-high"="#CB282A")

# Plot the quieter state first so the ECM-high state remains visible in mixed regions.
um <- um[order(um$ECM_state), ]
p <- ggplot(um, aes(UMAP_1, UMAP_2, colour=ECM_state)) +
  geom_point(size=0.38, alpha=1, stroke=0) +
  scale_colour_manual(values=cols, labels=legend_labels, drop=FALSE) +
  coord_equal() +
  labs(x="UMAP 1", y="UMAP 2", colour=NULL) +
  theme_classic(base_size=7, base_family="Helvetica") +
  theme(
    axis.title=element_text(size=6.6), axis.text=element_blank(),
    axis.ticks=element_blank(), axis.line=element_line(linewidth=0.35),
    legend.position="bottom", legend.direction="horizontal",
    legend.text=element_text(size=6.4), legend.key.width=grid::unit(4.5,"mm"),
    legend.margin=margin(t=1), plot.margin=margin(4,3,2,3)
  ) +
  guides(colour=guide_legend(override.aes=list(size=2.1, alpha=1), nrow=1))

svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                 system_fonts=list(sans="Arial"), pointsize=7)
print(p); dev.off()
pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
    family="Helvetica", pointsize=7, useDingbats=FALSE)
print(p); dev.off()
ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
               units="in", res=600, compression="lzw", background="white")
print(p); dev.off()
ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
              units="in", res=300, background="white")
print(p); dev.off()
write.csv(um, paste0(out_base,"_source_data.csv"), row.names=FALSE)
