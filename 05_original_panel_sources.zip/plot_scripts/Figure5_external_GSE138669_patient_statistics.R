suppressPackageStartupMessages({
  library(Seurat)
  library(dplyr)
  library(tidyr)
  library(readr)
})

obj <- readRDS("work/GSE138669_QC_merged.rds")
# Seurat v5 preserves one RNA layer per imported sample after merge. Join them
# before module scoring and expression extraction so every cell is evaluated
# from one common normalized matrix.
obj[["RNA"]] <- JoinLayers(obj[["RNA"]])
sample_meta <- read_csv("work/GSE138669_sample_metadata.csv", show_col_types = FALSE)
map_group <- setNames(sample_meta$disease_group, sample_meta$gsm)
map_name <- setNames(sample_meta$sample_name, sample_meta$gsm)
obj$disease_group <- unname(map_group[obj$gsm])
obj$sample_name <- unname(map_name[obj$gsm])
stopifnot(!anyNA(obj$disease_group), table(obj$disease_group)[["Ctrl"]] > 0)

obj$focus_compartment <- "Other"
obj$focus_compartment[obj$seurat_clusters %in% c("5", "6")] <- "Perivascular"
obj$focus_compartment[obj$seurat_clusters %in% c("12")] <- "Myeloid"

ecm_genes <- intersect(c("COL1A1", "COL1A2", "COL3A1", "POSTN", "SPARC", "FN1", "THY1"),
                       rownames(obj))
obj <- AddModuleScore(obj, features = list(ecm_genes), name = "external_ECM", seed = 20260802)

expr <- GetAssayData(obj, assay = "RNA", layer = "data")
md <- obj@meta.data
peri_cells <- rownames(md)[md$focus_compartment == "Perivascular"]
myeloid_cells <- rownames(md)[md$focus_compartment == "Myeloid"]

summ_gene <- function(cells, gene, prefix) {
  tibble(
    gsm = md[cells, "gsm"],
    value = as.numeric(expr[gene, cells])
  ) |>
    group_by(gsm) |>
    summarise(
      "{prefix}_n_cells" := n(),
      "{prefix}_mean" := mean(value),
      "{prefix}_pct" := mean(value > 0) * 100,
      .groups = "drop"
    )
}

peri <- summ_gene(peri_cells, "PLXNB2", "peri_PLXNB2")
myeloid <- summ_gene(myeloid_cells, "SEMA4D", "myeloid_SEMA4D")
ecm <- tibble(gsm = md[peri_cells, "gsm"], score = md[peri_cells, "external_ECM1"]) |>
  group_by(gsm) |>
  summarise(peri_ECM_mean = mean(score), .groups = "drop")
fractions <- md |>
  count(gsm, focus_compartment, name = "n") |>
  group_by(gsm) |>
  mutate(fraction = n / sum(n) * 100) |>
  ungroup() |>
  filter(focus_compartment %in% c("Perivascular", "Myeloid")) |>
  select(gsm, focus_compartment, fraction) |>
  pivot_wider(names_from = focus_compartment, values_from = fraction,
              names_prefix = "fraction_", values_fill = 0)

patient <- sample_meta |>
  left_join(peri, by = "gsm") |>
  left_join(myeloid, by = "gsm") |>
  left_join(ecm, by = "gsm") |>
  left_join(fractions, by = "gsm")

metrics <- c("fraction_Perivascular", "fraction_Myeloid", "peri_ECM_mean",
             "peri_PLXNB2_mean", "peri_PLXNB2_pct",
             "myeloid_SEMA4D_mean", "myeloid_SEMA4D_pct")

stats <- lapply(metrics, function(metric) {
  d <- patient |>
    filter(!is.na(.data[[metric]]))
  ctrl <- d[[metric]][d$disease_group == "Ctrl"]
  ssc <- d[[metric]][d$disease_group == "SSc"]
  wt <- wilcox.test(ctrl, ssc, exact = FALSE)
  d$disease_group <- factor(d$disease_group, levels = c("Ctrl", "SSc"))
  d$chemistry <- factor(d$chemistry, levels = c("V1", "V2"))
  fit <- lm(reformulate(c("disease_group", "chemistry"), response = metric), data = d)
  fit_coef <- summary(fit)$coefficients
  # Cliff's delta: probability(SSc > Ctrl) - probability(SSc < Ctrl).
  delta <- mean(outer(ssc, ctrl, ">")) - mean(outer(ssc, ctrl, "<"))
  tibble(
    metric = metric, n_Ctrl = length(ctrl), n_SSc = length(ssc),
    median_Ctrl = median(ctrl), median_SSc = median(ssc),
    cliffs_delta_SSc_vs_Ctrl = delta, p = wt$p.value,
    adjusted_beta_SSc = unname(coef(fit)[["disease_groupSSc"]]),
    adjusted_p_SSc = fit_coef["disease_groupSSc", "Pr(>|t|)"]
  )
}) |>
  bind_rows() |>
  mutate(FDR = p.adjust(p, method = "BH"),
         adjusted_FDR = p.adjust(adjusted_p_SSc, method = "BH"))

write_csv(patient, "outputs/Figure5_GSE138669_patient_level_variables.csv")
write_csv(stats, "outputs/Figure5_GSE138669_patient_level_statistics.csv")
saveRDS(obj, "work/GSE138669_annotated_focus.rds", compress = FALSE)
print(stats)
