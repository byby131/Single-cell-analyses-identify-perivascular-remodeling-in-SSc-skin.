suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(patchwork)
  library(svglite)
})

atlas_file <- "/Users/baoying/Documents/Codex/2026-07-31/wos/work/sce_skin_candidate_axes.rds"
peri_file <- "/Users/baoying/Documents/Codex/2026-07-31/wos/work/peri_all_processed.rds"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"
atlas <- readRDS(atlas_file)
peri <- readRDS(peri_file)

rescale_umap <- function(dat) {
  xr <- unname(quantile(dat$umap_1, c(0.01, 0.99), na.rm = TRUE))
  yr <- unname(quantile(dat$umap_2, c(0.01, 0.99), na.rm = TRUE))
  dat %>% mutate(
    map_x = pmax(0, pmin(1, (umap_1 - xr[1]) / diff(xr))),
    map_y = pmax(0, pmin(1, (umap_2 - yr[1]) / diff(yr)))
  )
}

myeloid_types <- c("M_CD16_IL1B", "M_IL1B", "Mf", "Mf_TREM2", "Mo", "Mo_CD16")
am <- atlas@meta.data
keep_a <- rownames(am)[am$annotation %in% myeloid_types]
ua <- as.data.frame(Embeddings(atlas, "umap")[keep_a, , drop = FALSE])
ua$expression <- as.numeric(GetAssayData(atlas, assay = "RNA", layer = "data")["SEMA4D", keep_a])
ua$annotation <- am[keep_a, "annotation"]
ua$state_group <- ifelse(ua$annotation == "M_IL1B", "M_IL1B",
                         ifelse(ua$annotation == "M_CD16_IL1B", "M_CD16_IL1B", "Other"))
ua$cell <- rownames(ua)
ua <- rescale_umap(ua)

pm <- peri@meta.data
keep_p <- rownames(pm)
up <- as.data.frame(Embeddings(peri, "umap")[keep_p, , drop = FALSE])
up$expression <- as.numeric(GetAssayData(peri, assay = "RNA", layer = "data")["PLXNB2", keep_p])
up$ECM_state <- pm[keep_p, "ECM_state"]
up$disease_group <- pm[keep_p, "disease_group"]
up$cell <- rownames(up)
up <- rescale_umap(up)

cap_a <- unname(quantile(ua$expression[ua$expression > 0], 0.98, na.rm = TRUE))
cap_p <- unname(quantile(up$expression[up$expression > 0], 0.98, na.rm = TRUE))
ua$relative_expression <- pmin(ua$expression, cap_a) / cap_a
up$relative_expression <- pmin(up$expression, cap_p) / cap_p

write_csv(ua, file.path(out_dir, "Figure3E_SEMA4D_myeloid_UMAP_source_data.csv"))
write_csv(up, file.path(out_dir, "Figure3E_PLXNB2_Peri_RGS5_UMAP_source_data.csv"))

base_umap_theme <- theme_classic(base_size = 9, base_family = "sans") +
  theme(
    axis.text = element_blank(), axis.ticks = element_blank(),
    axis.title = element_text(size = 7.8),
    plot.title = element_text(size = 9.8, face = "bold", hjust = 0),
    plot.subtitle = element_text(size = 7.6, colour = "#555555", margin = margin(b = 4)),
    legend.title = element_text(size = 7.2), legend.text = element_text(size = 7),
    legend.key.height = grid::unit(0.32, "cm"),
    plot.margin = margin(4, 4, 4, 4)
  )

annotation_panel <- function(dat, group_col, cols, title, subtitle, point_size) {
  ggplot(dat, aes(map_x, map_y, colour = .data[[group_col]])) +
    geom_point(size = point_size, alpha = 0.78, stroke = 0) +
    scale_colour_manual(values = cols, name = NULL) +
    coord_equal(xlim = c(0, 1), ylim = c(0, 1), expand = FALSE) +
    labs(title = title, subtitle = subtitle, x = "UMAP 1", y = "UMAP 2") +
    base_umap_theme +
    theme(legend.position = "bottom", legend.justification = "left") +
    guides(colour = guide_legend(nrow = 1, override.aes = list(size = 2.5, alpha = 1)))
}

feature_panel <- function(dat, gene, subtitle, point_size) {
  dat <- dat %>% arrange(relative_expression)
  ggplot(dat, aes(map_x, map_y)) +
    geom_point(colour = "#C5CDD1", size = point_size * 1.08, alpha = 0.68, stroke = 0) +
    geom_point(data = filter(dat, relative_expression > 0), aes(fill = relative_expression),
               shape = 21, colour = "white", size = point_size * 1.9,
               alpha = 1, stroke = 0.16) +
    scale_fill_gradientn(colours = c("#F4D35E", "#F47E21", "#CB282A", "#781C2A"),
                         limits = c(0, 1), breaks = c(0, 0.5, 1),
                         labels = c("Low", "", "High"),
                         name = "Within-gene\nrelative expression") +
    coord_equal(xlim = c(0, 1), ylim = c(0, 1), expand = FALSE) +
    labs(title = gene, subtitle = subtitle, x = "UMAP 1", y = "UMAP 2") +
    base_umap_theme +
    theme(plot.title = element_text(size = 10.8, face = "italic"),
          legend.position = "right")
}

p_anno_a <- annotation_panel(
  ua, "state_group",
  c("M_IL1B" = "#CB282A", "M_CD16_IL1B" = "#9067AC", "Other" = "#C5CDD1"),
  "Myeloid states", "Candidate source compartment in SSc", 0.65
) + guides(colour = guide_legend(nrow = 2, byrow = TRUE,
                                  override.aes = list(size = 2.5, alpha = 1)))
p_anno_p <- annotation_panel(
  up, "ECM_state",
  c("ECM-low" = "#1A8FB4", "ECM-high" = "#CB282A"),
  "Perivascular states", "Peri_RGS5 compartment", 0.42
)
p_expr_a <- feature_panel(ua, "SEMA4D", "Myeloid cells; not an exclusive source", 0.65)
p_expr_p <- feature_panel(up, "PLXNB2", "Peri_RGS5 cells", 0.42)

bottom <- (p_expr_a | p_expr_p) + plot_layout(guides = "collect") &
  theme(legend.position = "right")
p <- (p_anno_a | p_anno_p) / bottom +
  plot_layout(heights = c(1, 1.07))

svglite::svglite(
  file.path(out_dir, "Figure3E_SEMA4D_PLXNB2_state_aligned_maps_IF_aligned.svg"),
  width = 7.2, height = 5.5, bg = "white"
)
print(p)
dev.off()

grDevices::cairo_pdf(
  file.path(out_dir, "Figure3E_SEMA4D_PLXNB2_state_aligned_maps_IF_aligned.pdf"),
  width = 7.2, height = 5.5, family = "Arial", bg = "white"
)
print(p)
dev.off()

ggsave(file.path(out_dir, "Figure3E_SEMA4D_PLXNB2_state_aligned_maps_IF_aligned.png"), p,
       width = 7.2, height = 5.5, units = "in", dpi = 320, bg = "white")
ggsave(file.path(out_dir, "Figure3E_SEMA4D_PLXNB2_state_aligned_maps_IF_aligned.tiff"), p,
       width = 7.2, height = 5.5, units = "in", dpi = 600,
       compression = "lzw", bg = "white")
