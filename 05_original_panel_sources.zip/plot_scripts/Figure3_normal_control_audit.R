suppressPackageStartupMessages({
  library(Seurat); library(Matrix); library(dplyr); library(tidyr)
  library(readr); library(ggplot2); library(patchwork); library(scales)
})
set.seed(20260811)

# Contract: determine whether immune SEMA4D, perivascular PLXNB2, and the
# predicted receiver-target program differ between normal and SSc skin when
# the participant, not the cell, is the inferential unit.
immune_rds <- "/Users/baoying/Desktop/巨噬细胞/GSE195452_UMAP_PDF/GSE195452_SSc_Ctrl_skin_combined_raw.rds"
peri_rds <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_Ctrl_SSc_ECM_figures/peri_all_Ctrl_SSc_raw.rds"
out <- "outputs/Figure3_normal_control_audit"
dir.create(out,recursive=TRUE,showWarnings=FALSE)

x_immune <- readRDS(immune_rds)
x_immune <- JoinLayers(x_immune,assay="RNA",layers="counts",new="counts")
counts_immune <- LayerData(x_immune,assay="RNA",layer="counts")
md_immune <- x_immune@meta.data |> tibble::rownames_to_column("cell_id")
x_peri <- readRDS(peri_rds)
x_peri <- JoinLayers(x_peri,assay="RNA",layers="counts",new="counts")
counts_peri <- LayerData(x_peri,assay="RNA",layer="counts")
md_peri <- x_peri@meta.data |> tibble::rownames_to_column("cell_id_internal") |>
  transmute(cell_id=cell_id_internal,condition=disease_group,patient_id,celltype_anno)

immune_annotations <- c("sT","T_Naive","sT_Effector","T_Effector","sTreg","sTreg_CXCR4","T_GD","Treg",
                        "NK","NK_XCL1","NK_XCL1_CXCR4","M_CD16_IL1B","M_IL1B","Mf","Mf_TREM2","Mo","Mo_CD16",
                        "DC","DC_XCR1","DC_CCL22","DC_CXCL10","pDC","pDC_CXCR4","LC","B","B_CXCR4","Plasma")
target_genes <- read_csv("outputs/Figure3D_source_data.csv",show_col_types=FALSE)$target |> unique()
required <- unique(c("SEMA4D","PLXNB2",target_genes))
stopifnot(all(required %in% rownames(counts_immune)),all(required %in% rownames(counts_peri)))

make_pb <- function(cells,compartment,min_cells=10,meta_source,count_source) {
  meta <- meta_source |> filter(cell_id %in% cells) |> select(cell_id,condition,patient_id)
  cell_split <- split(meta$cell_id,interaction(meta$condition,meta$patient_id,drop=TRUE))
  bind_rows(lapply(cell_split,function(ids){
    mm <- count_source[required,ids,drop=FALSE]
    info <- meta[match(ids,meta$cell_id),] |> slice(1)
    libs <- Matrix::colSums(count_source[,ids,drop=FALSE])
    sums <- Matrix::rowSums(mm)
    tibble(condition=info$condition,patient_id=info$patient_id,compartment=compartment,
           n_cells=length(ids),gene=required,count=as.numeric(sums),
           logCPM=log2((as.numeric(sums)+0.5)/(sum(libs)+1)*1e6),
           pct_positive=as.numeric(Matrix::rowMeans(mm>0))*100)
  })) |> mutate(eligible=n_cells>=min_cells)
}

immune_cells <- md_immune |> filter(annotation %in% immune_annotations) |> pull(cell_id)
peri_cells <- md_peri |> filter(celltype_anno=="Peri_RGS5") |> pull(cell_id)
pb_immune <- make_pb(immune_cells,"All immune cells",min_cells=10,
                     meta_source=md_immune,count_source=counts_immune)
# Match the prespecified Figure 2 perivascular pseudobulk eligibility rule.
pb_peri <- make_pb(peri_cells,"Peri_RGS5",min_cells=5,
                   meta_source=md_peri,count_source=counts_peri)
pb <- bind_rows(pb_immune,pb_peri)
write_csv(pb,file.path(out,"patient_pseudobulk_all_endpoints.csv"))

target_patient <- pb_peri |> filter(eligible,gene %in% target_genes) |>
  group_by(gene) |> mutate(gene_z=as.numeric(scale(logCPM))) |> ungroup() |>
  group_by(condition,patient_id,n_cells) |>
  summarise(target_program=mean(gene_z,na.rm=TRUE),n_target_genes=sum(is.finite(gene_z)),.groups="drop")
write_csv(target_patient,file.path(out,"patient_perivascular_target_program.csv"))

endpoint <- bind_rows(
  pb_immune |> filter(eligible,gene=="SEMA4D") |> transmute(condition,patient_id,endpoint="Immune SEMA4D detection",value=pct_positive,n_cells),
  pb_immune |> filter(eligible,gene=="SEMA4D") |> transmute(condition,patient_id,endpoint="Immune SEMA4D logCPM",value=logCPM,n_cells),
  pb_peri |> filter(eligible,gene=="PLXNB2") |> transmute(condition,patient_id,endpoint="Peri_RGS5 PLXNB2 detection",value=pct_positive,n_cells),
  pb_peri |> filter(eligible,gene=="PLXNB2") |> transmute(condition,patient_id,endpoint="Peri_RGS5 PLXNB2 logCPM",value=logCPM,n_cells),
  target_patient |> transmute(condition,patient_id,endpoint="Perivascular target program",value=target_program,n_cells)
)
write_csv(endpoint,file.path(out,"patient_endpoint_values.csv"))

cliff_delta <- function(x,y){
  # x=SSc, y=Ctrl; positive means higher in SSc.
  mean(outer(x,y,"-")>0)-mean(outer(x,y,"-")<0)
}
stats <- endpoint |> group_by(endpoint) |>
  summarise(n_Ctrl=sum(condition=="Ctrl"),n_SSc=sum(condition=="SSc"),
            median_Ctrl=median(value[condition=="Ctrl"]),median_SSc=median(value[condition=="SSc"]),
            median_difference=median_SSc-median_Ctrl,
            cliff_delta=cliff_delta(value[condition=="SSc"],value[condition=="Ctrl"]),
            p=wilcox.test(value~condition,exact=FALSE)$p.value,.groups="drop") |>
  mutate(FDR=p.adjust(p,"BH"))
write_csv(stats,file.path(out,"patient_endpoint_statistics.csv"))

# Per-target disease effects provide a transparent alternative to relying on a
# single averaged target score.
target_stats <- pb_peri |> filter(eligible,gene %in% target_genes) |> group_by(gene) |>
  summarise(n_Ctrl=sum(condition=="Ctrl"),n_SSc=sum(condition=="SSc"),
            median_Ctrl=median(logCPM[condition=="Ctrl"]),median_SSc=median(logCPM[condition=="SSc"]),
            delta=median_SSc-median_Ctrl,
            cliff_delta=cliff_delta(logCPM[condition=="SSc"],logCPM[condition=="Ctrl"]),
            p=wilcox.test(logCPM~condition,exact=FALSE)$p.value,.groups="drop") |>
  mutate(FDR=p.adjust(p,"BH")) |> arrange(desc(cliff_delta))
write_csv(target_stats,file.path(out,"perivascular_target_gene_disease_statistics.csv"))

red <- "#CB282A"; blue <- "#1A8FB4"; purple <- "#7B61A8"; orange <- "#F28E2B"
teal <- "#2A9D8F"; navy <- "#26384A"; grey <- "#D5DCE1"; gold <- "#E9C46A"
pal <- c(Ctrl=blue,SSc=red)
theme_set(theme_classic(base_size=7.2,base_family="Helvetica")+
            theme(axis.line=element_line(linewidth=.35,colour=navy),axis.ticks=element_line(linewidth=.32,colour=navy),
                  axis.text=element_text(size=6.2,colour=navy),axis.title=element_text(size=6.9,colour=navy),
                  plot.title=element_text(size=8.3,face="bold",colour="#17212B"),
                  plot.subtitle=element_text(size=6.1,colour="#65717C"),plot.tag=element_text(size=10,face="bold"),
                  legend.position="none",panel.grid=element_blank(),plot.margin=margin(3,4,3,3)))

plot_endpoint <- function(ep,title,ylabel){
  dd <- filter(endpoint,endpoint==ep)
  ss <- filter(stats,endpoint==ep)
  ymax <- max(dd$value,na.rm=TRUE); ymin <- min(dd$value,na.rm=TRUE); rng <- max(ymax-ymin,1e-6)
  ggplot(dd,aes(condition,value,fill=condition,colour=condition))+
    geom_violin(width=.78,alpha=.14,linewidth=.45,trim=FALSE)+
    geom_boxplot(width=.26,outlier.shape=NA,alpha=.72,linewidth=.4,colour=navy)+
    geom_point(position=position_jitter(width=.09,height=0),shape=21,size=1.45,stroke=.25,alpha=.78)+
    scale_fill_manual(values=pal)+scale_colour_manual(values=pal)+
    annotate("text",x=1.5,y=ymax+.12*rng,label=sprintf("Ctrl n=%d; SSc n=%d\nP=%.3g; FDR=%.3g; Cliff's delta=%.2f",
                                                       ss$n_Ctrl,ss$n_SSc,ss$p,ss$FDR,ss$cliff_delta),size=2.0,colour=navy)+
    scale_y_continuous(expand=expansion(mult=c(.05,.25)))+
    labs(title=title,subtitle="Each point is one participant",x=NULL,y=ylabel)
}

pA <- plot_endpoint("Immune SEMA4D detection","Immune-cell SEMA4D detection","SEMA4D+ immune cells (%)")
pB <- plot_endpoint("Immune SEMA4D logCPM","Immune-cell SEMA4D pseudobulk","SEMA4D log2 CPM")
pC <- plot_endpoint("Peri_RGS5 PLXNB2 detection","Perivascular PLXNB2 detection","PLXNB2+ Peri_RGS5 cells (%)")
pD <- plot_endpoint("Peri_RGS5 PLXNB2 logCPM","Perivascular PLXNB2 pseudobulk","PLXNB2 log2 CPM")
pE <- plot_endpoint("Perivascular target program","Predicted receiver-target program","Mean target-program z score")

tg <- target_stats |> mutate(gene=factor(gene,levels=rev(gene)),sig=FDR<.05)
pF <- ggplot(tg,aes(cliff_delta,gene))+
  geom_vline(xintercept=0,linetype=2,linewidth=.35,colour="#87939B")+
  geom_segment(aes(x=0,xend=cliff_delta,yend=gene,colour=delta),linewidth=.75,alpha=.72)+
  geom_point(aes(size=-log10(pmax(FDR,1e-300)),fill=delta),shape=21,colour="white",stroke=.45)+
  scale_colour_gradient2(low=blue,mid=grey,high=red,midpoint=0,guide="none")+
  scale_fill_gradient2(low=blue,mid=grey,high=red,midpoint=0,name="Median logCPM\ndifference")+
  scale_size(range=c(1.8,4.8),name=expression(-log[10]*" FDR"))+
  labs(title="Predicted-target disease effects",subtitle="Peri_RGS5 patient pseudobulk: SSc versus normal skin",
       x="Cliff's delta (positive = higher in SSc)",y=NULL)+
  theme(legend.position="bottom",axis.line.y=element_blank(),axis.ticks.y=element_blank())

fig <- ((pA+pB+pC)+plot_layout(widths=c(1,1,1)))/
       ((pD+pE+pF)+plot_layout(widths=c(1,1,1.18)))+
       plot_layout(heights=c(1,1))+plot_annotation(tag_levels="A")

save_plot <- function(plot,stem,wmm=183,hmm=132,dpi=600){w<-wmm/25.4;h<-hmm/25.4
  ggsave(paste0(stem,".png"),plot,width=w,height=h,dpi=300,bg="white")
  ragg::agg_tiff(paste0(stem,".tiff"),width=w,height=h,units="in",res=dpi,background="white",compression="lzw");print(plot);dev.off()
  svglite::svglite(paste0(stem,".svg"),width=w,height=h,bg="white");print(plot);dev.off()
  if(FALSE && capabilities("cairo")){
    cairo_pdf(paste0(stem,"_cairo.pdf"),width=w,height=h,family="Helvetica");print(plot);dev.off()
  }
  pdf(paste0(stem,".pdf"),width=w,height=h,family="Helvetica",useDingbats=FALSE);print(plot);dev.off()
}
save_plot(fig,file.path(out,"Figure3_normal_control_audit"))

writeLines(c(
  "Figure 3 normal-control audit",
  "Core conclusion is determined by results; no endpoint was selected for significance.",
  "Participant is the inferential unit; immune endpoints require >=10 cells and Peri_RGS5 endpoints require >=5 cells, matching the prespecified Figure 2 pseudobulk rule.",
  "Detection is raw RNA count > 0; pseudobulk logCPM uses summed raw counts and total library size.",
  "The receiver-target program is the mean of gene-wise standardized perivascular patient pseudobulk values.",
  "Wilcoxon tests are two-sided; BH correction covers the five prespecified headline endpoints.",
  "Cliff's delta is positive when SSc is higher than normal skin."
),file.path(out,"QA_notes.txt"))
