suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(svglite)
})

src <- "/Users/baoying/Documents/Codex/2026-07-31/wos/work/Final_expression_gated_ligand_ranking.csv"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

dat <- read_csv(src, show_col_types = FALSE) %>%
  slice_head(n = 15) %>%
  mutate(
    ligand = factor(ligand, levels = rev(ligand)),
    class = case_when(
      as.character(ligand) == "SEMA4D" ~ "Candidate taken forward",
      obvious_mature_axis ~ "Established pathway",
      TRUE ~ "Other candidate"
    )
  )

write_csv(dat %>% mutate(ligand = as.character(ligand)),
          file.path(out_dir, "Figure3A_source_data.csv"))

cols <- c(
  "Candidate taken forward" = "#F47E21",
  "Established pathway" = "#9067AC",
  "Other candidate" = "#B8C3C8"
)

p <- ggplot(dat, aes(x = aupr_corrected, y = ligand)) +
  geom_segment(aes(x = 0, xend = aupr_corrected, yend = ligand, colour = class),
               linewidth = 1.05, lineend = "round") +
  geom_point(aes(colour = class), size = 3.4) +
  scale_colour_manual(values = cols) +
  scale_x_continuous(
    limits = c(0, 0.0235),
    breaks = c(0, 0.005, 0.010, 0.015, 0.020),
    labels = scales::label_number(accuracy = 0.001),
    expand = expansion(mult = c(0, 0.01))
  ) +
  labs(
    x = "NicheNet ligand activity (corrected AUPR)",
    y = NULL,
    colour = NULL
  ) +
  theme_classic(base_size = 10, base_family = "sans") +
  theme(
    axis.text = element_text(colour = "#222222", size = 8.5),
    axis.text.y = element_text(),
    axis.title.x = element_text(size = 9.5, margin = margin(t = 7)),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    legend.position = "bottom",
    legend.justification = "left",
    legend.margin = margin(t = 2),
    legend.key.width = grid::unit(0.9, "lines"),
    panel.grid.major.x = element_line(colour = "#E7EAEC", linewidth = 0.35),
    plot.margin = margin(7, 9, 4, 5)
  ) +
  guides(colour = guide_legend(nrow = 2, byrow = TRUE,
                               override.aes = list(linewidth = 2.2, size = 3)))

ggsave(file.path(out_dir, "Figure3A_expression_gated_NicheNet_ranking.svg"), p,
       width = 4.45, height = 4.0, units = "in", bg = "white")
ggsave(file.path(out_dir, "Figure3A_expression_gated_NicheNet_ranking.pdf"), p,
       width = 4.45, height = 4.0, units = "in", device = "pdf", bg = "white")
ggsave(file.path(out_dir, "Figure3A_expression_gated_NicheNet_ranking.png"), p,
       width = 4.45, height = 4.0, units = "in", dpi = 320, bg = "white")
ggsave(file.path(out_dir, "Figure3A_expression_gated_NicheNet_ranking.tiff"), p,
       width = 4.45, height = 4.0, units = "in", dpi = 600,
       compression = "lzw", bg = "white")
