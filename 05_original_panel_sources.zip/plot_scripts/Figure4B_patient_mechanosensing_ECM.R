suppressPackageStartupMessages({
  library(ggplot2)
  library(scales)
  library(svglite)
  library(ragg)
})

input_csv <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_YAP_TAZ_mechanotransduction/Patient_level_Peri_RGS5_YAP_TAZ_Mech_variables.csv"
stats_csv <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_YAP_TAZ_mechanotransduction/Correlation_results_Peri_RGS5_YAP_TAZ_Mech_patient_level.csv"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

d <- read.csv(input_csv, check.names = FALSE)
count_before <- nrow(d)
d <- d[complete.cases(d[, c("peri_mechanosensing", "peri_ecm")]), ]
count_after <- nrow(d)
s <- read.csv(stats_csv, check.names = FALSE)
s <- s[s$x == "peri_mechanosensing" & s$y == "peri_ecm", ][1, ]

fmt_p <- function(x) {
  if (is.na(x)) return("NA")
  if (x < 0.001) return("< 0.001")
  sprintf("= %.3f", x)
}

stat_label <- sprintf(
  "Spearman rho = %.2f\nn = %d, P %s\nFDR %s",
  s$rho, s$n, fmt_p(s$p_value), fmt_p(s$FDR)
)

p <- ggplot(d, aes(peri_mechanosensing, peri_ecm)) +
  geom_smooth(
    method = "lm", formula = y ~ x, se = TRUE,
    colour = "#CB282A", fill = "#F29979", alpha = 0.18,
    linewidth = 0.8
  ) +
  geom_point(
    shape = 21, size = 2.1, stroke = 0.4,
    colour = "#1A8FB4", fill = alpha("#59B1CC", 0.62)
  ) +
  annotate(
    "label", x = -Inf, y = Inf, label = stat_label,
    hjust = -0.08, vjust = 1.12, size = 3.0,
    family = "sans", lineheight = 1.05,
    linewidth = 0.25, label.padding = unit(2.2, "mm"),
    colour = "#202020", fill = alpha("white", 0.92)
  ) +
  labs(
    title = "Mechanosensing-ECM association",
    x = "Peri-RGS5 mechanosensing score",
    y = "Peri-RGS5 ECM score"
  ) +
  scale_x_continuous(expand = expansion(mult = c(0.06, 0.06))) +
  scale_y_continuous(expand = expansion(mult = c(0.07, 0.07))) +
  theme_classic(base_size = 9, base_family = "sans") +
  theme(
    axis.line = element_line(linewidth = 0.45, colour = "black"),
    axis.ticks = element_line(linewidth = 0.4, colour = "black"),
    axis.title = element_text(size = 9, colour = "black"),
    axis.text = element_text(size = 8, colour = "black"),
    plot.title = element_text(size = 10, face = "bold", hjust = 0, margin = margin(b = 6)),
    plot.margin = margin(7, 8, 6, 7)
  )

width_mm = 88
height_mm = 78

ggsave(file.path(out_dir, "Figure4B_patient_mechanosensing_ECM_correlation.svg"), p,
       width = width_mm, height = height_mm, units = "mm", bg = "white",
       device = svglite::svglite)

# Preferred submission device on a configured workstation: grDevices::cairo_pdf.
# This machine lacks the required X11 libraries, so use the native vector PDF device.
pdf_device <- grDevices::pdf
ggsave(file.path(out_dir, "Figure4B_patient_mechanosensing_ECM_correlation.pdf"), p,
       width = width_mm, height = height_mm, units = "mm", bg = "white", device = pdf_device)
ggsave(file.path(out_dir, "Figure4B_patient_mechanosensing_ECM_correlation.png"), p,
       width = width_mm, height = height_mm, units = "mm", dpi = 400, bg = "white")
ggsave(file.path(out_dir, "Figure4B_patient_mechanosensing_ECM_correlation.tiff"), p,
       width = width_mm, height = height_mm, units = "mm", dpi = 600,
       bg = "white", device = agg_tiff, compression = "lzw")

write.csv(
  d[, c("patient_id", "peri_mechanosensing", "peri_ecm")],
  file.path(out_dir, "Figure4B_source_data.csv"),
  row.names = FALSE
)
write.csv(s, file.path(out_dir, "Figure4B_statistics.csv"), row.names = FALSE)
writeLines(
  c(
    sprintf("Rows before complete-case filtering: %d", count_before),
    sprintf("Rows after complete-case filtering: %d", count_after),
    sprintf("Rows excluded for missing mechanosensing or ECM score: %d", count_before - count_after),
    "Statistical unit: one SSc patient",
    "Association test: two-sided Spearman correlation",
    "Multiple-testing correction: Benjamini-Hochberg FDR from the prespecified correlation table",
    "Red line and band: linear fit with 95% confidence interval, shown as a visual guide only"
  ),
  file.path(out_dir, "Figure4B_QA_notes.txt")
)
