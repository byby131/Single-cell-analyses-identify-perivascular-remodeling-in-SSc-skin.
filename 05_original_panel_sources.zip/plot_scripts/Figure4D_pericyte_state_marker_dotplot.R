suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(ggplot2)
  library(svglite)
  library(ragg)
})

input_rds <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_YAP_TAZ_mechanotransduction/Peri_RGS5_YAP_TAZ_internal_object.rds"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

obj <- readRDS(input_rds)

gene_sets <- list(
  `Receptor / adhesion` = c("PLXNB2", "CD44", "ITGB1", "ITGAV", "PDGFRB"),
  Contractile = c("RGS5", "ACTA2", "TAGLN", "MYL9"),
  `ECM / remodeling` = c("COL1A1", "COL1A2", "COL3A1", "FN1", "POSTN", "SPARC"),
  `YAP/TAZ targets` = c("CTGF", "CYR61", "SERPINE1", "AMOTL2")
)

gene_info <- do.call(rbind, lapply(names(gene_sets), function(cat) {
  data.frame(category = cat, gene = gene_sets[[cat]], stringsAsFactors = FALSE)
}))
gene_info <- gene_info[gene_info$gene %in% rownames(obj), ]

state_levels <- c("Dual_low", "YAP_high_only", "Mech_high_only", "YAP_Mech_Dual_high")
state_labels <- c(
  Dual_low = "Dual low",
  YAP_high_only = "YAP-high only",
  Mech_high_only = "Mech-high only",
  YAP_Mech_Dual_high = "Dual high"
)

state <- factor(obj$YAP_Mech_state, levels = state_levels)
expr <- LayerData(obj, assay = "RNA", layer = "data")[gene_info$gene, , drop = FALSE]

dot_list <- lapply(state_levels, function(st) {
  idx <- which(state == st)
  data.frame(
    state = st,
    gene = gene_info$gene,
    avg_expr = Matrix::rowMeans(expr[, idx, drop = FALSE]),
    pct_expr = Matrix::rowMeans(expr[, idx, drop = FALSE] > 0) * 100,
    n_cells = length(idx),
    stringsAsFactors = FALSE
  )
})
dot <- do.call(rbind, dot_list)
dot <- merge(dot, gene_info, by = "gene", all.x = TRUE, sort = FALSE)

dot$scaled_expr <- ave(dot$avg_expr, dot$gene, FUN = function(z) {
  s <- sd(z)
  if (!is.finite(s) || s == 0) return(rep(0, length(z)))
  as.numeric(scale(z))
})
dot$scaled_expr <- pmax(pmin(dot$scaled_expr, 1.5), -1.5)

dot$state <- factor(state_labels[dot$state], levels = unname(state_labels[state_levels]))
dot$category <- factor(dot$category, levels = names(gene_sets))
dot$gene <- factor(dot$gene, levels = unlist(gene_sets))

p <- ggplot(dot, aes(gene, state)) +
  geom_point(aes(size = pct_expr, colour = scaled_expr), alpha = 1) +
  facet_grid(. ~ category, scales = "free_x", space = "free_x", switch = "x") +
  scale_size_continuous(
    name = "Expressing cells (%)", range = c(0.4, 5.3),
    breaks = c(25, 50, 75), limits = c(0, 100)
  ) +
  scale_colour_gradient2(
    name = "Scaled mean\nexpression",
    low = "#1A8FB4", mid = "#FFFFFF", high = "#CB282A",
    midpoint = 0, limits = c(-1.5, 1.5), oob = scales::squish
  ) +
  labs(title = "Peri-RGS5 state-associated expression programs", x = NULL, y = NULL) +
  theme_bw(base_size = 8.5, base_family = "sans") +
  theme(
    panel.grid.major = element_line(linewidth = 0.25, colour = "#E5E5E5"),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(linewidth = 0.4, colour = "#808080"),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 7.4, colour = "black"),
    axis.text.y = element_text(size = 8.2, colour = "black"),
    axis.ticks = element_blank(),
    strip.background = element_rect(fill = "#F1F1F1", colour = "#808080", linewidth = 0.4),
    strip.text.x = element_text(size = 7.6, face = "bold", colour = "#303030", margin = margin(2, 2, 2, 2)),
    strip.placement = "outside",
    plot.title = element_text(size = 10, face = "bold", hjust = 0, margin = margin(b = 6)),
    legend.position = "right",
    legend.title = element_text(size = 7.1, face = "bold"),
    legend.text = element_text(size = 6.8),
    legend.key.height = unit(2.4, "mm"),
    plot.margin = margin(6, 7, 16, 7)
  ) +
  guides(
    size = guide_legend(order = 1, override.aes = list(colour = "#777777")),
    colour = guide_colourbar(order = 2, barheight = unit(16, "mm"), barwidth = unit(3, "mm"))
  )

width_mm = 178
height_mm = 78

ggsave(file.path(out_dir, "Figure4D_pericyte_state_marker_dotplot.svg"), p,
       width = width_mm, height = height_mm, units = "mm", bg = "white",
       device = svglite::svglite)
ggsave(file.path(out_dir, "Figure4D_pericyte_state_marker_dotplot.pdf"), p,
       width = width_mm, height = height_mm, units = "mm", bg = "white",
       device = grDevices::pdf)
ggsave(file.path(out_dir, "Figure4D_pericyte_state_marker_dotplot.png"), p,
       width = width_mm, height = height_mm, units = "mm", dpi = 400, bg = "white")
ggsave(file.path(out_dir, "Figure4D_pericyte_state_marker_dotplot.tiff"), p,
       width = width_mm, height = height_mm, units = "mm", dpi = 600,
       bg = "white", device = ragg::agg_tiff, compression = "lzw")

write.csv(dot, file.path(out_dir, "Figure4D_source_data.csv"), row.names = FALSE)
writeLines(
  c(
    "Descriptive single-cell marker dot plot; no inferential P values are assigned to individual cells.",
    "Dot size denotes the percentage of cells with non-zero normalized expression.",
    "Colour denotes gene-wise scaled mean normalized expression across four predefined states, truncated to [-1.5, 1.5].",
    sprintf("State counts: %s", paste(sprintf("%s n=%d", state_levels, as.integer(table(state)[state_levels])), collapse = "; ")),
    "The four states were defined by the pre-existing YAP/TAZ-target and mechanosensing score thresholds.",
    "Preferred PDF device on a configured workstation: grDevices::cairo_pdf; native vector PDF used here because Cairo/X11 is unavailable."
  ),
  file.path(out_dir, "Figure4D_QA_notes.txt")
)
