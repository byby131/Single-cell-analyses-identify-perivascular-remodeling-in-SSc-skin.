suppressPackageStartupMessages({
  library(Seurat); library(ggplot2); library(patchwork); library(dplyr)
  library(tidyr); library(readr); library(Matrix); library(ggrepel)
  library(scales); library(grid); library(ggnewscale)
})

# Core conclusion: independent-cohort, identity-refined analysis reproduces a
# perivascular ECM-remodeling program and links myeloid SEMA4D abundance to the
# predicted receiver target program at participant level.
# Archetype: asymmetric mixed-modality validation figure; R-only rendering.

dir.create("outputs", showWarnings = FALSE, recursive = TRUE)
my <- readRDS("work/GSE138669_myeloid_reclustered_clean.rds")
pv <- readRDS("work/GSE138669_perivascular_reclustered_clean.rds")
de <- read_csv("outputs/Figure5_upgrade_perivascular_pseudobulk_edgeR.csv", show_col_types = FALSE)
gsea <- read_csv("outputs/Figure5_upgrade_perivascular_GSEA.csv", show_col_types = FALSE)
coupling <- read_csv("outputs/Figure5_upgrade_patient_ligand_target_coupling.csv", show_col_types = FALSE)
coupling_stats <- read_csv("outputs/Figure5_upgrade_patient_ligand_target_statistics.csv", show_col_types = FALSE)
target_weights <- read_csv("outputs/Figure3D_source_data.csv", show_col_types = FALSE)

red <- "#CB282A"; blue <- "#1A8FB4"; purple <- "#9067AC"; orange <- "#F47E21"
teal <- "#2A9D8F"; gold <- "#E9B949"; navy <- "#26384A"; grey <- "#C9D1D8"
group_pal <- c(Ctrl = blue, SSc = red)
my_cols <- c("#4E79A7", "#A0CBE8", "#E15759", "#B07AA1", "#F28E2B", "#76B7B2", "#59A14F", "#9C755F")
pv_cols <- c("#355C7D", "#6C5B7B", "#C06C84", "#F67280", "#F8B195", "#2A9D8F", "#E9C46A", "#E76F51")
names(my_cols) <- c("CCL2+ Macro", "CD1C+ DC", "S100A8+ Mono", "APOC1+ Macro",
                    "FCGR3A+ Macro", "Cycling", "CLEC9A+ DC", "Rare myeloid")
names(pv_cols) <- c("PLK2+", "HAS2+", "RGS5/POSTN+", "PLN+ contractile",
                    "IL6+", "INHBA+", "CCL21+", "CALCA+")

theme_pub <- theme_classic(base_size = 7.2, base_family = "Helvetica") +
  theme(axis.line = element_line(linewidth = .35, colour = navy),
        axis.ticks = element_line(linewidth = .35, colour = navy),
        axis.text = element_text(size = 6.2, colour = navy),
        axis.title = element_text(size = 7, colour = navy),
        plot.title = element_text(size = 8.2, face = "bold", colour = "#17212B"),
        plot.subtitle = element_text(size = 6.4, colour = "#5C6770"),
        plot.tag = element_text(size = 11, face = "bold", colour = "black"),
        legend.title = element_text(size = 6.2), legend.text = element_text(size = 5.8),
        strip.background = element_blank(), strip.text = element_text(size = 6.5, face = "bold"),
        panel.grid = element_blank(), plot.margin = margin(3, 4, 3, 3))
theme_set(theme_pub)

my_map <- c(`0`="CCL2+ Macro", `1`="CD1C+ DC", `3`="S100A8+ Mono", `4`="APOC1+ Macro",
            `5`="FCGR3A+ Macro", `6`="Cycling", `7`="CLEC9A+ DC", `9`="Rare myeloid")
pv_map <- c(`0`="PLK2+", `1`="HAS2+", `2`="RGS5/POSTN+", `3`="PLN+ contractile",
            `4`="IL6+", `5`="INHBA+", `6`="CCL21+", `7`="CALCA+")
my$state <- factor(unname(my_map[as.character(my$seurat_clusters)]), levels = names(my_cols))
pv$state <- factor(unname(pv_map[as.character(pv$seurat_clusters)]), levels = names(pv_cols))

umap_panel <- function(x, pal, title) {
  d <- as.data.frame(Embeddings(x, "umap")); names(d)[1:2] <- c("UMAP_1","UMAP_2")
  d$state <- x$state
  set.seed(20260802); d <- d[sample(seq_len(nrow(d))), ]
  centers <- d |> group_by(state) |> summarise(UMAP_1=median(UMAP_1), UMAP_2=median(UMAP_2), .groups="drop")
  ggplot(d, aes(UMAP_1, UMAP_2, colour=state)) +
    geom_point(size=.32, alpha=.72, stroke=0) +
    stat_ellipse(aes(group=state), linewidth=.3, alpha=.42, show.legend=FALSE,
                 type="norm", level=.68) +
    geom_label_repel(data=centers, aes(label=state), size=1.9, family="Helvetica",
                     colour=navy, fill=alpha("white",.86), label.size=.18,
                     min.segment.length=0, seed=20260802, show.legend=FALSE) +
    scale_colour_manual(values=pal, drop=FALSE) + coord_equal() +
    labs(title=title, x=NULL, y=NULL, colour=NULL) +
    theme(axis.text=element_blank(), axis.ticks=element_blank(), axis.line=element_blank(),
          legend.position="none", plot.title=element_text(margin=margin(l=8)))
}
pA_inner <- umap_panel(my, my_cols, "Myeloid states") +
  umap_panel(pv, pv_cols, "Perivascular states") + plot_layout(widths=c(.92,1.08))
pA <- wrap_elements(full=pA_inner)

dot_stats <- function(x, genes, compartment) {
  genes <- intersect(genes, rownames(x)); e <- GetAssayData(x, layer="data")
  bind_rows(lapply(levels(x$state), function(st) {
    cells <- colnames(x)[x$state == st]; m <- e[genes,cells,drop=FALSE]
    tibble(compartment=compartment, state=st, gene=genes,
           avg=Matrix::rowMeans(m), pct=Matrix::rowMeans(m>0)*100)
  }))
}
dot <- bind_rows(
  dot_stats(my, c("LST1","TYROBP","CD68","CCL2","S100A8","FCGR3A","APOC1","CD1C","CLEC9A","MKI67","SEMA4D"), "Myeloid"),
  dot_stats(pv, c("RGS5","PDGFRB","CSPG4","ACTA2","TAGLN","HAS2","POSTN","IL6","CCL21","PLXNB2"), "Perivascular")
) |> group_by(compartment,gene) |>
  mutate(z=if(sd(avg)>0) as.numeric(scale(avg)) else rep(0,n())) |> ungroup()
dot$gene <- factor(dot$gene, levels=unique(dot$gene))
dot$state <- factor(dot$state, levels=rev(c(names(my_cols),names(pv_cols))))
pB <- ggplot(dot, aes(gene,state)) +
  geom_tile(aes(fill=z), colour="white", linewidth=.25) +
  geom_point(aes(size=pct), shape=21, fill=alpha("white",.78), colour=navy, stroke=.18) +
  facet_grid(compartment~., scales="free", space="free") +
  scale_fill_gradient2(low=blue,mid="#F5F5F5",high=red,midpoint=0,limits=c(-2,2),oob=squish,name="Scaled\nmean") +
  scale_size(range=c(.2,3.6),limits=c(0,100),name="Expressing\n(%)") +
  labs(title="State-resolved expression matrix",subtitle="Colour: scaled mean; circle size: expressing cells (%)",x=NULL,y=NULL) +
  theme(axis.text.x=element_text(angle=45,hjust=1,face="italic",size=5.5),
        axis.text.y=element_text(size=5.2), axis.line=element_blank(),axis.ticks=element_blank(),
        legend.position="none", panel.spacing=unit(1.5,"mm"))

de_plot <- de |> mutate(class=case_when(FDR<.05 & logFC>0 ~ "Up in SSc",
                                        FDR<.05 & logFC<0 ~ "Down in SSc", TRUE ~ "Not significant"),
                         neglog=-log10(pmax(FDR,1e-300)))
key_genes <- c("THY1","IGFBP2","ECM1","SERPINF1","COL4A1","COL4A2","COL3A1","COL1A2","SPARC","CCL21")
labels <- de_plot |> filter(gene %in% key_genes)
pC <- ggplot(de_plot, aes(logFC,neglog)) +
  geom_point(data=filter(de_plot,class=="Not significant"),colour="#D8DEE3",size=.55,alpha=.55) +
  geom_point(data=filter(de_plot,class!="Not significant"),aes(colour=class),size=.8,alpha=.72) +
  geom_vline(xintercept=0,linetype=2,linewidth=.3,colour="#8A949E") +
  geom_hline(yintercept=-log10(.05),linetype=3,linewidth=.3,colour="#8A949E") +
  geom_point(data=labels,shape=21,fill="white",aes(colour=class),size=2,stroke=.7) +
  geom_text_repel(data=labels,aes(label=gene),size=2.05,fontface="italic",family="Helvetica",
                  max.overlaps=Inf,box.padding=.25,point.padding=.15,seed=20260802,show.legend=FALSE) +
  scale_colour_manual(values=c("Up in SSc"=red,"Down in SSc"=blue,"Not significant"=grey)) +
  labs(title="Participant-level pseudobulk",subtitle="Perivascular cells; edgeR model: disease + chemistry",
       x=expression(log[2]*" fold change (SSc / Ctrl)"),y=expression(-log[10]*" FDR"),colour=NULL) +
  theme(legend.position="bottom",legend.direction="horizontal")

pretty_path <- function(x) {
  x <- sub("^(REACTOME_|GOBP_|HALLMARK_)","",x)
  x <- gsub("_"," ",x); tools::toTitleCase(tolower(x))
}
gsea_show <- gsea |> filter(padj<.05) |>
  distinct(pathway,.keep_all=TRUE) |> slice_head(n=11) |>
  mutate(label=pretty_path(pathway), direction=ifelse(NES>0,"Enriched in SSc","Enriched in Ctrl"),
         strength=-log10(padj), label=factor(label,levels=rev(label)))
pD <- ggplot(gsea_show,aes(NES,label)) +
  geom_segment(aes(x=0,xend=NES,yend=label,colour=direction),linewidth=.75,alpha=.75) +
  geom_point(aes(size=strength,fill=NES),shape=21,colour="white",stroke=.45) +
  geom_vline(xintercept=0,linetype=2,linewidth=.3,colour="#8A949E") +
  scale_colour_manual(values=c("Enriched in SSc"=red,"Enriched in Ctrl"=blue),guide="none") +
  scale_fill_gradient2(low=blue,mid="#F6F6F6",high=red,midpoint=0,name="NES") +
  scale_size(range=c(2,6),name=expression(-log[10]*" FDR")) +
  labs(title="Fibrotic pathway landscape",subtitle="Signed GSEA; point size denotes -log10 FDR",x="Normalized enrichment score",y=NULL) +
  theme(axis.line.y=element_blank(),axis.ticks.y=element_blank(),axis.text.y=element_text(size=5.6),legend.position="none")

network <- target_weights |> left_join(select(de,gene,logFC,FDR),by=c("target"="gene")) |>
  arrange(rank) |> mutate(y=seq(1,0,length.out=n()),x=2)
nodes_targets <- network |> transmute(node=target,x=2,y=y,type="Target",logFC=logFC,FDR=FDR,weight=weight)
nodes_core <- tibble(node=c("SEMA4D","PLXNB2"),x=c(0,1),y=c(.5,.5),type=c("Ligand","Receptor"),
                     logFC=c(NA, de$logFC[match("PLXNB2",de$gene)]),FDR=c(NA,de$FDR[match("PLXNB2",de$gene)]),weight=max(network$weight)*c(1.25,1.15))
edges_target <- network |> transmute(x=1,y=.5,xend=2,yend=y,weight=weight,edge_col=logFC)
pE <- ggplot() +
  geom_curve(data=tibble(x=0,y=.5,xend=1,yend=.5),aes(x=x,y=y,xend=xend,yend=yend),
             curvature=.08,linewidth=1.6,colour=orange,arrow=arrow(length=unit(2,"mm"),type="closed")) +
  geom_curve(data=edges_target,aes(x=x,y=y,xend=xend,yend=yend,linewidth=weight,colour=edge_col),
             curvature=.08,alpha=.72,arrow=arrow(length=unit(1.5,"mm"),type="closed")) +
  scale_colour_gradient2(low=blue,mid="#BFC7CD",high=red,midpoint=0,guide="none") +
  ggnewscale::new_scale_colour() +
  geom_point(data=nodes_targets,aes(x,y,size=weight,fill=logFC,colour=FDR<.05),shape=21,stroke=.75) +
  geom_point(data=nodes_core,aes(x,y,size=weight,fill=logFC),shape=21,colour=navy,stroke=1) +
  geom_text(data=nodes_core,aes(x,y,label=node),fontface="bold",size=2.4,vjust=-1.7) +
  geom_text(data=nodes_targets,aes(x,y,label=node),hjust=-.25,size=2,fontface="italic") +
  annotate("text",x=c(0,1,2),y=1.07,label=c("Myeloid ligand","Perivascular receptor","Predicted targets"),
           fontface="bold",size=2.2,colour=navy) +
  scale_fill_gradient2(low=blue,mid="#F5F5F5",high=red,midpoint=0,limits=c(-2.5,2.5),oob=squish,na.value=orange,name=expression("External "*log[2]*"FC")) +
  scale_colour_manual(values=c(`TRUE`=navy,`FALSE`="#BFC7CD"),name="Target FDR < 0.05") +
  scale_linewidth(range=c(.25,1.2),guide="none") + scale_size(range=c(3.5,6),guide="none") +
  coord_cartesian(xlim=c(-.2,2.55),ylim=c(-.05,1.12),clip="off") +
  labs(title="Ligand-receptor-target evidence map",subtitle="Node fill: external log2FC; dark outline: FDR < 0.05; edge width: NicheNet weight") +
  theme_void(base_family="Helvetica",base_size=7.2) + theme(plot.title=element_text(size=8.2,face="bold"),plot.subtitle=element_text(size=6.2,colour="#5C6770"),legend.position="none",plot.margin=margin(3,18,3,3))

st <- coupling_stats[1,]
pF <- ggplot(coupling,aes(myeloid_SEMA4D_pct,perivascular_target_score,colour=disease_group,shape=chemistry)) +
  geom_smooth(aes(group=1),method="lm",se=TRUE,colour=navy,fill="#DDE5EB",linewidth=.65) +
  geom_rug(sides="bl",alpha=.35,linewidth=.35) +
  geom_point(size=2.3,alpha=.92,stroke=.55) +
  scale_colour_manual(values=group_pal,name=NULL) + scale_shape_manual(values=c(V1=21,V2=24),name="Chemistry") +
  labs(title="Cross-compartment coupling",subtitle="Each point represents one participant",
       x="SEMA4D+ myeloid cells (%)",y="Perivascular predicted-target score") +
  annotate("label",x=Inf,y=-Inf,hjust=1.04,vjust=-.35,size=2.2,family="Helvetica",fill=alpha("white",.86),linewidth=.2,
           label=sprintf("Spearman rho = %.2f\nAdjusted P = %.3g",st$spearman_rho,st$p)) +
  guides(colour=guide_legend(order=1),shape=guide_legend(order=2)) +
  theme(legend.position="top",legend.direction="horizontal",legend.box="horizontal",
        legend.margin=margin(0,0,0,0),legend.background=element_rect(fill="white",colour=NA))

assembly <- ((pA + pB) + plot_layout(widths=c(1.12,.88))) /
  ((pC + pD) + plot_layout(widths=c(.92,1.08))) /
  ((pE + pF) + plot_layout(widths=c(1.08,.92))) +
  plot_layout(heights=c(1.02,.96,.98)) + plot_annotation(tag_levels="A")

save_plot <- function(plot,stem,wmm,hmm,dpi=600) {
  w<-wmm/25.4; h<-hmm/25.4
  ggsave(paste0(stem,".png"),plot,width=w,height=h,units="in",dpi=300,bg="white")
  ragg::agg_tiff(paste0(stem,".tiff"),width=w,height=h,units="in",res=dpi,
                 background="white",compression="lzw");print(plot);grDevices::dev.off()
  svglite::svglite(paste0(stem,".svg"),width=w,height=h,bg="white");print(plot);grDevices::dev.off()
  use_cairo<-FALSE # local Cairo/X11 DLL is unavailable
  if(use_cairo && isTRUE(capabilities("cairo"))){
    grDevices::cairo_pdf(paste0(stem,".pdf"),width=w,height=h,family="Helvetica",bg="white")
  } else {
    grDevices::pdf(paste0(stem,".pdf"),width=w,height=h,family="Helvetica",bg="white",useDingbats=FALSE)
  }
  print(plot);grDevices::dev.off()
}
save_plot(pA,"outputs/Figure5A_upgraded_target_state_atlas",108,76)
save_plot(pB,"outputs/Figure5B_upgraded_state_expression_matrix",78,76)
save_plot(pC,"outputs/Figure5C_upgraded_perivascular_pseudobulk",94,74)
save_plot(pD,"outputs/Figure5D_upgraded_GSEA_landscape",88,74)
save_plot(pE,"outputs/Figure5E_upgraded_ligand_target_network",102,76)
save_plot(pF,"outputs/Figure5F_upgraded_cross_compartment_coupling",82,76)
save_plot(assembly,"outputs/Figure5_upgraded_assembly_v2",183,220)

write_lines(c(
  "Figure 5 upgraded analysis and QA notes",
  "Independent cohort: GSE138669; Ctrl n=10, SSc n=12 participants.",
  "Perivascular identity refinement: 7,081 to 7,040 cells; excluded 41 KRT5/KRT14/COL17A1-high contaminant cells (0.58%).",
  "Myeloid identity/QC refinement: 2,815 to 2,347 cells; excluded low-complexity cluster 2 and keratinocyte-like/doublet cluster 8 (16.63%).",
  "Panel C: patient-level pseudobulk edgeR quasi-likelihood model includes chemistry and disease group.",
  "Panel D: signed GSEA ranking = sign(logFC) * sqrt(edgeR F); BH-adjusted pathway FDR.",
  sprintf("Panel F: Spearman rho %.4f; disease- and chemistry-adjusted association P %.6g.",st$spearman_rho,st$p),
  "Panel E overlays discovery-cohort NicheNet weights with independent-cohort perivascular target logFC; it is not a direct experimental signaling assay.",
  "All quantitative disease inference uses participants, not cells, as independent observations."
),"outputs/Figure5_upgraded_QA_notes.txt")
message("Upgraded Figure 5 exports complete.")
