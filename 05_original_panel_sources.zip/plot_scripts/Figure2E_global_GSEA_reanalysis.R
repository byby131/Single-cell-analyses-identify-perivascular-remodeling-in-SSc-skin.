suppressPackageStartupMessages({
  library(dplyr); library(readr); library(msigdbr); library(fgsea)
})

set.seed(20260802)
de <- read_csv("outputs/Figure2E_ECMhigh_patient_pseudobulk_full_results.csv",
               show_col_types = FALSE)

# Global, non-topic-prefiltered pathway universe. Hallmark gives a compact
# overview; Reactome supplies mechanistic resolution. This avoids selecting
# only ECM/contractile terms before enrichment testing.
msig <- bind_rows(
  msigdbr(species = "Homo sapiens", collection = "H") |>
    transmute(collection = "Hallmark", pathway = gs_name, gene = gene_symbol),
  msigdbr(species = "Homo sapiens", collection = "C2", subcollection = "CP:REACTOME") |>
    transmute(collection = "Reactome", pathway = gs_name, gene = gene_symbol)
) |> distinct(collection, pathway, gene)

pathways <- split(msig$gene, paste(msig$collection, msig$pathway, sep = "::"))
ranks <- sign(de$logFC) * sqrt(de$F)
names(ranks) <- de$gene
ranks <- sort(ranks[is.finite(ranks)], decreasing = TRUE)

gsea <- fgseaMultilevel(pathways, ranks, minSize = 10, maxSize = 500, eps = 0) |>
  as_tibble() |>
  tidyr::separate(pathway, into = c("collection", "pathway"), sep = "::", extra = "merge") |>
  arrange(padj, desc(abs(NES))) |>
  mutate(leadingEdge = vapply(leadingEdge, paste, collapse = ";", FUN.VALUE = character(1)))

write_csv(gsea, "outputs/Figure2E_global_GSEA_full_results.csv")
message("Global GSEA complete: ", nrow(gsea), " pathways; ",
        sum(gsea$padj < 0.05, na.rm = TRUE), " at FDR < 0.05; directions SSc=",
        sum(gsea$padj < 0.05 & gsea$NES > 0, na.rm = TRUE), ", Ctrl=",
        sum(gsea$padj < 0.05 & gsea$NES < 0, na.rm = TRUE))
