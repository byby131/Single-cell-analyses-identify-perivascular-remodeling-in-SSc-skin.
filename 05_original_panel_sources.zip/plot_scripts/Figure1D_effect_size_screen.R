suppressPackageStartupMessages({
  library(ggplot2)
  library(svglite)
  library(ragg)
})

stat_file <- "/Users/baoying/Desktop/巨噬细胞/Within_lineage_publication_analysis/Table_within_lineage_fraction_Wilcoxon_effect_size_min20.csv"
out_base <- "outputs/Figure1D_subtype_effect_size_screen_Cell_palette_v2"
width_mm <- 100
height_mm <- 66

st <- read.csv(stat_file, check.names=FALSE)
keep <- c("M_IL1B", "Mf", "M_CD16_IL1B", "Mf_TREM2",
          "Peri_RGS5", "Peri_TGFBI", "Vascular_ACKR1", "Vascular_RBP7")
st <- st[match(keep, st$annotation), ]
stopifnot(nrow(st) == length(keep), !anyNA(st$cliffs_delta))

labels <- c(
  "M_IL1B"="M_IL1B", "Mf"="Macrophages", "M_CD16_IL1B"="M_CD16_IL1B",
  "Mf_TREM2"="TREM2+ macrophages", "Peri_RGS5"="RGS5+ pericytes",
  "Peri_TGFBI"="TGFBI+ pericytes", "Vascular_ACKR1"="ACKR1+ endothelial",
  "Vascular_RBP7"="RBP7+ endothelial"
)
st$display <- factor(unname(labels[st$annotation]), levels=rev(unname(labels[keep])))
st$lineage_group <- ifelse(grepl("^M_|^Mf$|^Mf_", st$annotation), "Myeloid",
                           ifelse(grepl("^Peri_", st$annotation), "Pericyte", "Vascular"))
fmt_fdr <- function(x) ifelse(x < 0.001, "FDR < 0.001",
                              paste0("FDR = ", formatC(x, format="f", digits=3)))
st$fdr_label <- fmt_fdr(st$FDR)

cols <- c("Myeloid"="#CB282A", "Pericyte"="#9067AC", "Vascular"="#1A8FB4")
p <- ggplot(st, aes(cliffs_delta, display, colour=lineage_group)) +
  geom_vline(xintercept=0, colour="#9A9A9A", linewidth=0.42) +
  geom_segment(aes(x=0, xend=cliffs_delta, yend=display), linewidth=0.8,
               alpha=0.62, show.legend=FALSE) +
  geom_point(size=2.55) +
  geom_text(aes(x=0.56, label=fdr_label), colour="#333333", hjust=0,
            family="Helvetica", size=2.25, show.legend=FALSE) +
  scale_colour_manual(values=cols) +
  scale_x_continuous(limits=c(-0.62,0.84), breaks=c(-0.5,-0.25,0,0.25,0.5),
                     expand=expansion(mult=c(0,0))) +
  labs(x="Cliff's delta", y=NULL) +
  theme_classic(base_size=7, base_family="Helvetica") +
  theme(
    axis.text.y=element_text(size=6.6, colour="#222222"),
    axis.text.x=element_text(size=6.2), axis.title.x=element_text(size=7),
    axis.line.y=element_blank(), axis.ticks.y=element_blank(),
    axis.line.x=element_line(linewidth=0.35), axis.ticks.x=element_line(linewidth=0.35),
    panel.grid.major.y=element_line(colour="#E9E9E9", linewidth=0.28),
    legend.position="none", plot.margin=margin(3,3,3,3)
  )

svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                 system_fonts=list(sans="Arial"), pointsize=7)
print(p); dev.off()
pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
    family="Helvetica", pointsize=7, useDingbats=FALSE)
print(p); dev.off()
ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
               units="in", res=600, compression="lzw", background="white")
print(p); dev.off()
ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
              units="in", res=300, background="white")
print(p); dev.off()
write.csv(st, paste0(out_base,"_source_data.csv"), row.names=FALSE)
