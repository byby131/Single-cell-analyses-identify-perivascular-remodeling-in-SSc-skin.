suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(patchwork)
  library(svglite)
  library(ragg)
})

infile <- "work/ECM_high_threshold_sensitivity.csv"
out_base <- "outputs/FigureS1A_ECM_high_threshold_sensitivity"
dat <- read_csv(infile, show_col_types = FALSE)

med <- dat |>
  select(threshold, n_Ctrl, n_SSc, median_Ctrl, median_SSc) |>
  pivot_longer(c(median_Ctrl, median_SSc), names_to = "group", values_to = "median_fraction") |>
  mutate(
    group = recode(group, median_Ctrl = "Ctrl", median_SSc = "SSc"),
    n = if_else(group == "Ctrl", n_Ctrl, n_SSc),
    group = factor(group, levels = c("Ctrl", "SSc"))
  )

cols <- c(Ctrl = "#1A8FB4", SSc = "#CB282A")
base_theme <- theme_classic(base_size = 8.5, base_family = "Arial") +
  theme(
    axis.title = element_text(size = 8.5),
    axis.text = element_text(size = 8, colour = "#202124"),
    axis.line = element_line(linewidth = 0.55),
    axis.ticks = element_line(linewidth = 0.55),
    legend.text = element_text(size = 8),
    plot.title = element_text(size = 9, face = "bold", hjust = 0),
    plot.margin = margin(4, 5, 4, 5)
  )

p1 <- ggplot(med, aes(threshold, median_fraction, colour = group, group = group)) +
  geom_line(linewidth = 0.9) +
  geom_point(size = 2.2) +
  geom_text(aes(label = paste0("n=", n),
                vjust = if_else(group == "Ctrl", -1.05, 1.75)), size = 2.55,
            show.legend = FALSE) +
  scale_colour_manual(values = cols, name = NULL) +
  scale_x_continuous(breaks = dat$threshold) +
  scale_y_continuous(limits = c(52, 78), expand = expansion(mult = c(0.02, 0.03))) +
  labs(
    title = "Sensitivity to the minimum Peri_RGS5 cell-count filter",
    x = NULL, y = "Median ECM-high cells (%)"
  ) +
  base_theme +
  theme(legend.position = "top", legend.justification = "left",
        legend.direction = "horizontal")

effect_labels <- paste0("P=", formatC(dat$p_value, digits = 2, format = "f"))
p2 <- ggplot(dat, aes(threshold, cliffs_delta)) +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.55, colour = "#777777") +
  geom_line(colour = "#9067AC", linewidth = 0.9) +
  geom_point(colour = "#9067AC", fill = "white", shape = 21, stroke = 0.8, size = 2.4) +
  geom_text(aes(label = effect_labels), size = 2.55, vjust = -1.15, colour = "#444444") +
  scale_x_continuous(breaks = dat$threshold) +
  scale_y_continuous(limits = c(-0.22, 0.48), breaks = c(-0.2, 0, 0.2, 0.4)) +
  labs(
    x = "Minimum Peri_RGS5 cells required per patient",
    y = "Cliff's delta\n(SSc vs Ctrl)"
  ) +
  base_theme

p <- p1 / p2 + plot_layout(heights = c(1, 0.9))

width_mm <- 120
height_mm <- 115
svglite(paste0(out_base, ".svg"), width = width_mm / 25.4, height = height_mm / 25.4,
        system_fonts = list(sans = "Arial"))
print(p); dev.off()
grDevices::pdf(paste0(out_base, ".pdf"), width = width_mm / 25.4,
               height = height_mm / 25.4, family = "Helvetica", useDingbats = FALSE)
print(p); dev.off()
agg_tiff(paste0(out_base, ".tiff"), width = width_mm / 25.4, height = height_mm / 25.4,
         units = "in", res = 600, compression = "lzw", background = "white")
print(p); dev.off()
agg_png(paste0(out_base, ".png"), width = width_mm / 25.4, height = height_mm / 25.4,
        units = "in", res = 320, background = "white")
print(p); dev.off()

write_csv(dat, paste0(out_base, "_source_data.csv"))
