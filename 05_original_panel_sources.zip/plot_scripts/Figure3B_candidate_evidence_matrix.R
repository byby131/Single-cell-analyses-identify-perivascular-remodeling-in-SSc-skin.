suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(tidyr)
  library(stringr)
  library(svglite)
})

src <- "/Users/baoying/Documents/Codex/2026-07-31/wos/work/Final_expression_gated_ligand_ranking.csv"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

focus <- c("DCN", "TGFB1", "TIMP2", "SEMA4D")
dat <- read_csv(src, show_col_types = FALSE) %>%
  filter(ligand %in% focus) %>%
  mutate(
    ligand = factor(ligand, levels = rev(focus)),
    receptor_n = str_count(receptors, ",") + 1L,
    receptor_specificity = 1 / receptor_n,
    pathway_status = if_else(obvious_mature_axis,
                             "Established fibrotic axis", "Other candidate")
  )

metric_long <- dat %>%
  transmute(
    ligand,
    `Ligand\nactivity` = aupr_corrected,
    `Sender\nenrichment` = sender_delta_max,
    `Receiver\nenrichment` = receptor_delta_max,
    `Pair\nsupport` = best_pair_support,
    `Receptor\nspecificity` = receptor_specificity
  ) %>%
  pivot_longer(-ligand, names_to = "metric", values_to = "raw") %>%
  group_by(metric) %>%
  mutate(score = if (max(raw) == min(raw)) rep(0.5, n()) else (raw - min(raw)) / (max(raw) - min(raw))) %>%
  ungroup() %>%
  mutate(
    metric = factor(metric, levels = c("Ligand\nactivity", "Sender\nenrichment",
                                      "Receiver\nenrichment", "Pair\nsupport",
                                      "Receptor\nspecificity")),
    label = case_when(
      metric == "Ligand\nactivity" ~ sprintf("%.3f", raw),
      metric %in% c("Sender\nenrichment", "Receiver\nenrichment") ~ sprintf("%+.1f pp", 100 * raw),
      metric == "Pair\nsupport" ~ sprintf("%.3f", raw),
      metric == "Receptor\nspecificity" ~ paste0(round(1 / raw), if_else(round(1 / raw) == 1, " receptor", " receptors")),
      TRUE ~ ""
    )
  )

status <- dat %>%
  transmute(ligand, metric = factor("Pathway\nstatus",
                                    levels = c(levels(metric_long$metric), "Pathway\nstatus")),
            pathway_status)
metric_long$metric <- factor(metric_long$metric,
                             levels = c(levels(metric_long$metric), "Pathway\nstatus"))

write_csv(dat %>% mutate(ligand = as.character(ligand)),
          file.path(out_dir, "Figure3B_candidate_summary_source_data.csv"))
write_csv(metric_long %>% mutate(ligand = as.character(ligand), metric = as.character(metric)),
          file.path(out_dir, "Figure3B_candidate_matrix_source_data.csv"))

p <- ggplot() +
  geom_tile(data = metric_long, aes(metric, ligand, fill = score),
            colour = "white", linewidth = 1.2, width = 0.96, height = 0.88) +
  geom_text(data = metric_long, aes(metric, ligand, label = label),
            size = 2.75, colour = "#202124", lineheight = 0.9) +
  geom_tile(data = status, aes(metric, ligand), fill = "#F7F7F5",
            colour = "white", linewidth = 1.2, width = 0.96, height = 0.88) +
  geom_point(data = status, aes(metric, ligand, colour = pathway_status), size = 4.0) +
  geom_text(data = status, aes(metric, ligand,
                               label = if_else(pathway_status == "Established fibrotic axis", "Established", "Other")),
            nudge_y = -0.27, size = 2.15, colour = "#202124") +
  scale_fill_gradientn(colours = c("#F3F5F5", "#B9DCE6", "#1A8FB4"),
                       limits = c(0, 1), name = "Within-column\nrelative evidence") +
  scale_colour_manual(values = c("Established fibrotic axis" = "#9067AC",
                                 "Other candidate" = "#F47E21"),
                      name = NULL) +
  scale_x_discrete(position = "top", expand = expansion(add = 0)) +
  scale_y_discrete(expand = expansion(add = 0)) +
  coord_cartesian(clip = "off") +
  labs(x = NULL, y = NULL) +
  theme_void(base_size = 10, base_family = "sans") +
  theme(
    axis.text.x = element_text(size = 8.2, colour = "#202124", face = "bold",
                               lineheight = 0.92, margin = margin(b = 7)),
    axis.text.y = element_text(size = 9.2, colour = "#202124", face = "italic",
                               margin = margin(r = 7)),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.justification = "left",
    legend.key.width = grid::unit(1.2, "cm"),
    legend.key.height = grid::unit(0.24, "cm"),
    legend.text = element_text(size = 7.8),
    legend.title = element_text(size = 7.8),
    plot.margin = margin(8, 8, 4, 5)
  ) +
  guides(
    fill = guide_colourbar(order = 1, title.position = "top", title.hjust = 0),
    colour = guide_legend(order = 2, override.aes = list(size = 3.5))
  )

ggsave(file.path(out_dir, "Figure3B_candidate_evidence_matrix.svg"), p,
       width = 6.8, height = 3.45, units = "in", bg = "white")
ggsave(file.path(out_dir, "Figure3B_candidate_evidence_matrix.pdf"), p,
       width = 6.8, height = 3.45, units = "in", device = "pdf", bg = "white")
ggsave(file.path(out_dir, "Figure3B_candidate_evidence_matrix.png"), p,
       width = 6.8, height = 3.45, units = "in", dpi = 320, bg = "white")
ggsave(file.path(out_dir, "Figure3B_candidate_evidence_matrix.tiff"), p,
       width = 6.8, height = 3.45, units = "in", dpi = 600,
       compression = "lzw", bg = "white")
