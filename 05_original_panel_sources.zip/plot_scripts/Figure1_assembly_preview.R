suppressPackageStartupMessages(library(magick))

out_dir <- "outputs"
files <- c(
  A=file.path(out_dir,"Figure1A_neutral_study_workflow.png"),
  B=file.path(out_dir,"Figure1B_SSc_skin_cell_atlas_preview.png"),
  C=file.path(out_dir,"Figure1C_M_IL1B_Peri_RGS5_marker_dotplot_preview.png"),
  D=file.path(out_dir,"Figure1D_subtype_effect_size_screen_Cell_palette_v2_preview.png"),
  E=file.path(out_dir,"Figure1E_M_IL1B_patient_fraction_preview.png"),
  F=file.path(out_dir,"Figure1F_Peri_RGS5_patient_fraction_preview.png")
)
stopifnot(all(file.exists(files)))

panel <- function(path, width, height, label) {
  im <- image_read(path) |>
    image_resize(paste0(width,"x",height)) |>
    image_extent(paste0(width,"x",height), gravity="center", color="white")
  image_annotate(im, label, gravity="northwest", location="+8+5",
                 size=28, font="Helvetica", weight=700, color="black")
}
spacer_h <- function(width, height=18) image_blank(width,height,"white")
spacer_v <- function(width=18, height) image_blank(width,height,"white")

A <- panel(files[["A"]], 980, 690, "A")
B <- panel(files[["B"]], 800, 690, "B")
row1 <- image_append(c(A,spacer_v(20,690),B), stack=FALSE)

C <- panel(files[["C"]], 1800, 1030, "C")

D <- panel(files[["D"]], 1000, 700, "D")
E <- panel(files[["E"]], 380, 700, "E")
F <- panel(files[["F"]], 380, 700, "F")
row3 <- image_append(c(D,spacer_v(20,700),E,spacer_v(20,700),F), stack=FALSE)

assembled <- image_append(c(row1,spacer_h(1800),C,spacer_h(1800),row3), stack=TRUE)
assembled <- image_border(assembled, "white", "15x15")
image_write(assembled, file.path(out_dir,"Figure1_assembly_preview_revised_v2.png"),
            format="png")
