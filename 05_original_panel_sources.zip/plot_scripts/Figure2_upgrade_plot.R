suppressPackageStartupMessages({
  library(Seurat); library(ggplot2); library(patchwork); library(dplyr)
  library(tidyr); library(readr); library(Matrix); library(ggrepel); library(scales)
})

# Claim: Peri_RGS5 cells occupy a contractile-to-ECM continuum, while the
# ECM-high state shows participant-level fibrotic transcriptional remodelling
# in SSc without requiring a change in the binary ECM-high fraction.
# Archetype: asymmetric mixed-modality quantitative figure; R-only rendering.

obj <- readRDS("work/peri_all_processed.rds")
md <- obj@meta.data |> tibble::rownames_to_column("cell_id_internal")
de <- read_csv("outputs/Figure2E_ECMhigh_patient_pseudobulk_full_results.csv",show_col_types=FALSE)
gsea <- read_csv("outputs/Figure2E_global_GSEA_full_results.csv",show_col_types=FALSE)
heat <- read_csv("outputs/Figure2_upgrade_patient_pseudobulk_heatmap.csv",show_col_types=FALSE)

red<-"#CB282A"; blue<-"#1A8FB4"; purple<-"#7B61A8"; orange<-"#F28E2B"
teal<-"#2A9D8F"; gold<-"#E9C46A"; coral<-"#E76F51"; indigo<-"#4C5BB4"
magenta<-"#C84C83"; navy<-"#26384A"; grey<-"#D5DCE1"
# Disease is the only invariant red/blue mapping. Cell state, programmes and
# pathway families use an orthogonal Cell-inspired multihue system.
state_pal<-c(`ECM-low`=teal,`ECM-high`=coral)
final_width_mm <- 183
theme_pub<-theme_classic(base_size=7.2,base_family="Helvetica")+
  theme(axis.line=element_line(linewidth=.35,colour=navy),axis.ticks=element_line(linewidth=.35,colour=navy),
        axis.text=element_text(size=6.2,colour=navy),axis.title=element_text(size=7,colour=navy),
        plot.title=element_text(size=8.2,face="bold",colour="#17212B"),
        plot.subtitle=element_text(size=6.3,colour="#65717C"),plot.tag=element_text(size=11,face="bold"),
        legend.title=element_text(size=6.2),legend.text=element_text(size=5.8),
        strip.background=element_blank(),strip.text=element_text(size=6.4,face="bold"),
        panel.grid=element_blank(),plot.margin=margin(3,4,3,3))
theme_set(theme_pub)

# A: continuous programme phase portrait.
set.seed(20260802); phase<-md[sample(seq_len(nrow(md))),]
pA<-ggplot(phase,aes(Contractile_z,ECM_z))+
  geom_point(aes(colour=ECM_delta),size=.45,alpha=.42,stroke=0)+
  geom_density_2d(data=filter(phase,ECM_state=="ECM-high"),colour=coral,bins=4,linewidth=.45)+
  geom_density_2d(data=filter(phase,ECM_state=="ECM-low"),colour=teal,bins=4,linewidth=.45)+
  geom_abline(slope=1,intercept=0,linetype=2,linewidth=.4,colour=navy)+
  scale_colour_gradientn(colours=c(indigo,"#5DA5B3","#F3E9C9",orange,magenta),
                         values=rescale(c(-4,-2,0,2,4)),limits=c(-4,4),oob=squish,
                         name="ECM -\ncontractile")+
  annotate("label",x=quantile(md$Contractile_z,.10),y=quantile(md$ECM_z,.92),label="ECM-dominant",size=2,
           fill=alpha("white",.82),colour=coral,linewidth=.2)+
  annotate("label",x=quantile(md$Contractile_z,.88),y=quantile(md$ECM_z,.10),label="Contractile-dominant",size=2,
           fill=alpha("white",.82),colour=teal,linewidth=.2)+
  labs(title="Perivascular state phase portrait",subtitle="4,864 Peri_RGS5 cells; colour encodes programme balance",
       x="Contractile programme (z)",y="ECM programme (z)")+
  theme(legend.position="right")

# B: participant-balanced differential occupancy. Every participant contributes
# total cell weight 1, preventing cell-rich participants from dominating.
lims_x<-quantile(md$Contractile_z,c(.01,.99),na.rm=TRUE); lims_y<-quantile(md$ECM_z,c(.01,.99),na.rm=TRUE)
nx<-18; ny<-18
occ<-md |> filter(disease_group %in% c("Ctrl","SSc")) |>
  group_by(patient_id) |> mutate(cell_weight=1/n()) |> ungroup() |>
  mutate(xc=pmin(pmax(Contractile_z,lims_x[1]),lims_x[2]),yc=pmin(pmax(ECM_z,lims_y[1]),lims_y[2]),
         xb=cut(xc,breaks=seq(lims_x[1],lims_x[2],length.out=nx+1),include.lowest=TRUE,labels=FALSE),
         yb=cut(yc,breaks=seq(lims_y[1],lims_y[2],length.out=ny+1),include.lowest=TRUE,labels=FALSE)) |>
  group_by(disease_group,xb,yb) |> summarise(w=sum(cell_weight),.groups="drop") |>
  group_by(disease_group) |> mutate(density=w/sum(w)) |> ungroup() |>
  select(-w) |> complete(disease_group,xb=1:nx,yb=1:ny,fill=list(density=0)) |>
  pivot_wider(names_from=disease_group,values_from=density,values_fill=0) |>
  mutate(support=SSc+Ctrl,log2_ratio=log2((SSc+2e-5)/(Ctrl+2e-5)),
         x=lims_x[1]+(xb-.5)*diff(lims_x)/nx,y=lims_y[1]+(yb-.5)*diff(lims_y)/ny)
support_cut<-quantile(occ$support[occ$support>0],.20,na.rm=TRUE)
occ$log2_ratio[occ$support<support_cut]<-NA_real_
write_csv(occ,"outputs/Figure2B_upgraded_patient_balanced_occupancy_source_data.csv")
pB<-ggplot(occ,aes(x,y,fill=log2_ratio))+
  geom_raster(interpolate=FALSE)+
  geom_abline(slope=1,intercept=0,linetype=2,linewidth=.35,colour=navy)+
  scale_fill_gradient2(low=blue,mid="#F1F1F1",high=red,midpoint=0,limits=c(-3,3),oob=squish,
                       na.value="#F1F3F4",name=expression(log[2]*" density ratio"))+coord_cartesian(expand=FALSE)+
  labs(title="Patient-balanced disease occupancy",subtitle="Each participant contributes equal total weight",
       x="Contractile programme (z)",y="ECM programme (z)")+
  theme(legend.position="right")

# C: state-resolved programme matrix.
genes<-intersect(c("MYH11","ACTA2","TAGLN","PLN","COL1A1","COL1A2","COL3A1","POSTN","SPARC","THY1","RGS5","PDGFRB"),rownames(obj))
expr<-GetAssayData(obj,layer="data")
dot<-bind_rows(lapply(c("ECM-low","ECM-high"),function(st){cells<-rownames(obj@meta.data)[obj$ECM_state==st];m<-expr[genes,cells,drop=FALSE]
  tibble(state=st,gene=genes,avg=Matrix::rowMeans(m),pct=Matrix::rowMeans(m>0)*100)})) |>
  group_by(gene) |> mutate(z=if(sd(avg)>0) as.numeric(scale(avg)) else rep(0,n())) |> ungroup() |>
  mutate(program=case_when(gene %in% c("MYH11","ACTA2","TAGLN","PLN")~"Contractile",
                           gene %in% c("COL1A1","COL1A2","COL3A1","POSTN","SPARC","THY1")~"ECM",
                           TRUE~"Identity"))
dot$gene<-factor(dot$gene,levels=genes);dot$state<-factor(dot$state,levels=c("ECM-high","ECM-low"))
pC<-ggplot(dot,aes(gene,state))+
  geom_tile(aes(fill=z),colour="white",linewidth=.45)+
  geom_point(aes(size=pct,colour=program),shape=21,fill=alpha("white",.82),stroke=.55)+
  geom_vline(xintercept=c(4.5,10.5),colour="white",linewidth=2)+
  scale_fill_gradient2(low=indigo,mid="#F5EBD2",high=coral,midpoint=0,limits=c(-1,1),oob=squish,
                       name="Relative mean\nexpression (z)",
                       guide=guide_colourbar(direction="horizontal",barwidth=grid::unit(18,"mm"),
                                             barheight=grid::unit(2.1,"mm"),title.position="top",
                                             title.hjust=.5,ticks.colour=navy,frame.colour=navy))+
  scale_colour_manual(values=c(Contractile=indigo,ECM=coral,Identity=gold),guide="none")+
  scale_size(range=c(1.2,8),limits=c(0,100),breaks=c(25,50,75,100),
             name="Expressing cells (%)",
             guide=guide_legend(direction="horizontal",title.position="top",title.hjust=.5,
                                nrow=1,byrow=TRUE,override.aes=list(colour=navy,fill="white",stroke=.45)))+
  annotate("text",x=c(2.5,7.5,11.5),y=2.72,label=c("Contractile","ECM","Identity"),fontface="bold",size=2.25)+
  labs(title="State-resolved programme matrix",subtitle="Colour: relative mean; circle size: expressing cells (%)",x=NULL,y=NULL)+
  theme(axis.text.x=element_text(angle=45,hjust=1,face="italic"),axis.line=element_blank(),axis.ticks=element_blank(),
        legend.position="bottom",legend.box="horizontal",legend.box.just="center",
        legend.title=element_text(size=5.5,lineheight=.9),legend.text=element_text(size=5.2),
        legend.key.width=grid::unit(4.2,"mm"),legend.key.height=grid::unit(3.0,"mm"),
        legend.spacing.x=grid::unit(2.5,"mm"),legend.margin=margin(0,0,0,0),
        plot.margin=margin(10,4,3,3))+coord_cartesian(ylim=c(.55,2.8),clip="off")

# D: participant-level pseudobulk volcano.
dp<-de |> mutate(class=case_when(FDR<.05&logFC>0~"Up in SSc",FDR<.05&logFC<0~"Down in SSc",TRUE~"Not significant"),
                 neglog=-log10(pmax(FDR,1e-300)))
key<-c("COL1A1","COL1A2","COL3A1","COL4A1","IGFBP7","BGN","APOE","NR4A1","HSPA1A","EGR1")
lab<-dp |> filter(gene%in%key,FDR<.05)
pD<-ggplot(dp,aes(logFC,neglog))+
  geom_point(data=filter(dp,class=="Not significant"),colour=grey,size=.6,alpha=.55)+
  geom_point(data=filter(dp,class!="Not significant"),aes(colour=class),size=.85,alpha=.75)+
  geom_hline(yintercept=-log10(.05),linetype=3,linewidth=.3,colour="#8A949E")+
  geom_vline(xintercept=0,linetype=2,linewidth=.3,colour="#8A949E")+
  geom_point(data=lab,shape=21,fill="white",aes(colour=class),size=2,stroke=.7)+
  geom_text_repel(data=lab,aes(label=gene),size=2.05,fontface="italic",max.overlaps=Inf,seed=20260802,show.legend=FALSE)+
  scale_colour_manual(values=c(`Up in SSc`=red,`Down in SSc`=blue,`Not significant`=grey))+
  labs(title="ECM-high state remodelling",subtitle="Participant pseudobulk; 33 Ctrl and 81 SSc",
       x=expression(log[2]*" fold change (SSc / Ctrl)"),y=expression(-log[10]*" FDR"),colour=NULL)+
  theme(legend.position="bottom")

pretty_path<-function(x){
  x<-sub("^(REACTOME_|GOBP_|HALLMARK_)","",x)
  x<-gsub("_"," ",x)
  x<-tools::toTitleCase(tolower(x))
  x<-gsub("Tnfa Signaling via Nfkb","TNFalpha signaling via NF-kappaB",x,fixed=TRUE)
  x<-gsub("Ecm","ECM",x,fixed=TRUE)
  x<-gsub("Esr","ESR",x,fixed=TRUE)
  stringr::str_wrap(x,width=29)
}
# Unbiased overview: every tested Hallmark/Reactome pathway is retained in the
# source layer. Labels are assigned algorithmically to the five lowest-FDR
# pathways in each direction, not chosen by biological topic.
gs<-gsea |>
  mutate(direction=ifelse(NES>0,"SSc enriched","Ctrl enriched"),
         strength=-log10(pmax(padj,1e-300)),
         significant=padj<.05,
         short=pretty_path(pathway),
         family=case_when(
           grepl("ECM|MATRIX|COLLAGEN|INTEGRIN|EPITHELIAL_MESENCHYMAL",pathway)~"Matrix remodelling",
           grepl("TNFA|IMMUNO|CYTOKINE|INTERFERON|PD_1|PD_L1",pathway)~"Immune signalling",
           grepl("HEAT_STRESS|HSP90|UV_RESPONSE|HYPOXIA|P53",pathway)~"Stress response",
           grepl("MUSCLE|ACTIN|CELL_CYCLE|DEVELOPMENTAL",pathway)~"Cell state",
           TRUE~"Other signalling"))
labE<-bind_rows(
  gs |> filter(significant,NES>0) |> arrange(padj,desc(abs(NES))) |> slice_head(n=2),
  gs |> filter(significant,NES<0) |> arrange(padj,desc(abs(NES))) |> slice_head(n=2)
)
pE<-ggplot(gs,aes(NES,strength))+
  annotate("rect",xmin=-Inf,xmax=0,ymin=-Inf,ymax=Inf,fill=alpha(blue,.035))+
  annotate("rect",xmin=0,xmax=Inf,ymin=-Inf,ymax=Inf,fill=alpha(red,.035))+
  geom_point(data=filter(gs,!significant),colour=grey,size=.7,alpha=.42)+
  geom_point(data=filter(gs,significant),aes(fill=family,size=size),shape=21,
             colour="white",stroke=.35,alpha=.9)+
  geom_vline(xintercept=0,linetype=2,linewidth=.3,colour="#8A949E")+
  geom_hline(yintercept=-log10(.05),linetype=3,linewidth=.3,colour="#8A949E")+
  geom_text_repel(data=labE,aes(label=short,colour=family),size=1.72,
                  lineheight=.82,box.padding=.35,point.padding=.18,
                  min.segment.length=0,segment.size=.22,max.overlaps=Inf,
                  seed=20260802,show.legend=FALSE)+
  scale_fill_manual(values=c(`Matrix remodelling`=coral,`Immune signalling`=teal,
                             `Stress response`=purple,`Cell state`=gold,
                             `Other signalling`="#6F7D8C"),name="Pathway family",
                    guide=guide_legend(nrow=2,byrow=TRUE))+
  scale_colour_manual(values=c(`Matrix remodelling`=coral,`Immune signalling`=teal,
                               `Stress response`=purple,`Cell state`=gold,
                               `Other signalling`="#6F7D8C"),guide="none")+
  scale_size(range=c(1.6,4.2),guide="none")+
  labs(title="Global pathway landscape",
       subtitle="Hallmark + Reactome; no topic prefilter; BH FDR",
       x="Normalized enrichment score",y=expression(-log[10]*" FDR"))+
  theme(legend.position="bottom",legend.box="horizontal",
        legend.title=element_blank(),legend.text=element_text(size=5.1),
        legend.key.width=grid::unit(3.2,"mm"),legend.spacing.x=grid::unit(1.5,"mm"))

# F: participant pseudobulk heatmap with disease annotation strip.
heat$gene<-factor(heat$gene,levels=rev(unique(heat$gene[order(heat$gene_order)])))
pF_strip<-heat |> distinct(patient_order,disease_group) |>
  ggplot(aes(patient_order,1,fill=disease_group))+geom_tile()+scale_fill_manual(values=c(Ctrl=blue,SSc=red),name=NULL)+
  theme_void()+theme(legend.position="top",legend.direction="horizontal",plot.margin=margin(0,3,0,3))
pF_heat<-ggplot(heat,aes(patient_order,gene,fill=z))+geom_raster()+
  scale_fill_gradient2(low=indigo,mid="#F5EBD2",high=magenta,midpoint=0,
                       limits=c(-2.5,2.5),oob=squish,name="Row z")+
  labs(x="Participants (Ctrl then SSc)",y=NULL)+
  theme(axis.text.x=element_blank(),axis.ticks.x=element_blank(),axis.line=element_blank(),legend.position="right",
        axis.text.y=element_text(size=5.4,face="italic"),plot.margin=margin(0,3,3,3))
pF_inner<-(pF_strip/pF_heat+plot_layout(heights=c(.10,.90),guides="collect"))+
  plot_annotation(title="Patient heatmap",
                  subtitle="ECM-high cells: 33 Ctrl, 81 SSc") &
  theme(plot.title=element_text(size=8.2,face="bold",family="Helvetica",margin=margin(l=8)),
        plot.subtitle=element_text(size=6.3,colour="#65717C",family="Helvetica",margin=margin(l=8)))
pF<-wrap_elements(full=pF_inner)

assembly<-((wrap_elements(full=pA)+wrap_elements(full=pB))+plot_layout(widths=c(1.02,.98)))/
  ((wrap_elements(full=pC)+wrap_elements(full=pD))+plot_layout(widths=c(.95,1.05)))/
  ((wrap_elements(full=pE)+pF)+plot_layout(widths=c(1.02,.98)))+
  plot_layout(heights=c(1.02,.94,.98))+plot_annotation(tag_levels="A")

save_plot<-function(plot,stem,wmm,hmm,dpi=600){w<-wmm/25.4;h<-hmm/25.4
  ggsave(paste0(stem,".png"),plot,width=w,height=h,units="in",dpi=300,bg="white")
  ragg::agg_tiff(paste0(stem,".tiff"),width=w,height=h,units="in",res=dpi,
                 background="white",compression="lzw"); print(plot); grDevices::dev.off()
  svglite::svglite(paste0(stem,".svg"),width=w,height=h,bg="white");
  print(plot); grDevices::dev.off()
  use_cairo <- FALSE # local R reports Cairo but its X11-linked DLL is unavailable
  if (use_cairo && isTRUE(capabilities("cairo"))) {
    grDevices::cairo_pdf(paste0(stem,".pdf"),width=w,height=h,family="Helvetica",
                         bg="white",onefile=TRUE)
  } else {
    grDevices::pdf(paste0(stem,".pdf"),width=w,height=h,family="Helvetica",
                   bg="white",useDingbats=FALSE)
  }
  print(plot); grDevices::dev.off()
}
save_plot(pA,"outputs/Figure2A_upgraded_state_phase_portrait",92,72)
save_plot(pB,"outputs/Figure2B_upgraded_differential_occupancy",90,72)
save_plot(pC,"outputs/Figure2C_upgraded_state_matrix",84,76)
save_plot(pD,"outputs/Figure2D_upgraded_pseudobulk_volcano",98,70)
save_plot(pE,"outputs/Figure2E_upgraded_GSEA",94,72)
save_plot(pF,"outputs/Figure2F_upgraded_patient_heatmap",88,72)
save_plot(assembly,"outputs/Figure2_upgraded_assembly_v5_multihue",final_width_mm,215)

write_lines(c("Figure 2 upgraded QA notes",
  "Cell-level phase and occupancy panels are descriptive; differential occupancy weights each participant equally.",
  "Participant programme summaries were audited with a >=10-cell rule; no state metric remained significant after BH correction, so no patient-level programme boxplot is used as positive evidence.",
  "Pseudobulk differential expression and GSEA use ECM-high cells from participants with >=5 ECM-high cells: 33 Ctrl and 81 SSc.",
  "Global GSEA tests Hallmark and Reactome without topic prefiltering. Ranking is sign(logFC)*sqrt(edgeR F), with BH-adjusted pathway FDR.",
  "Panel C includes explicit legends for tile fill (gene-wise relative mean expression z-score) and circle size (percentage of expressing cells); circle-outline colour denotes the directly labelled programme family.",
  "Vector export uses svglite for editable SVG; PDF falls back to the standard R vector device when Cairo is unavailable in the local R runtime.",
  "Panel F shows row-z-scored pseudobulk expression and is descriptive of participant heterogeneity."),
  "outputs/Figure2_upgraded_QA_notes.txt")
message("Upgraded Figure 2 exports complete.")
