#!/usr/bin/env Rscript

# Supplementary figure contract
# S1: Threshold sensitivity of the ECM-high fraction; quantitative grid.
# S2: CellChat and expression-gated ligand-receptor checks; quantitative grid.
# S3: Independent-cohort target-program score sensitivity; quantitative grid.
# S4: Nearest distance in CD3- and F4/80-stained panels; mouse-level dot grid.
# These panels describe robustness and limitations; none imply direct signaling.

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(patchwork)
})

out_dir <- "outputs/supplementary_2026-09-28"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

ctrl <- "#1A8FB4"
ssc <- "#CB282A"
neutral <- "#596579"
accent <- "#8B64A9"

theme_supp <- function() {
  theme_classic(base_size = 9, base_family = "Arial") +
    theme(
      text = element_text(colour = "black"),
      axis.text = element_text(size = 8.5, colour = "black"),
      axis.title = element_text(size = 9, colour = "black"),
      axis.line = element_line(linewidth = 0.55, colour = "black"),
      axis.ticks = element_line(linewidth = 0.45, colour = "black"),
      legend.title = element_blank(),
      legend.text = element_text(size = 8.5),
      strip.text = element_text(size = 9, face = "bold", colour = "black"),
      strip.background = element_rect(fill = "#F2F4F6", colour = NA),
      plot.tag = element_text(size = 14, face = "bold", colour = "black"),
      plot.tag.position = c(0.015, 1.005),
      plot.margin = margin(11, 8, 8, 8)
    )
}

save_figure <- function(plot, stem, width_mm, height_mm) {
  w <- width_mm / 25.4
  h <- height_mm / 25.4
  svglite::svglite(file.path(out_dir, paste0(stem, ".svg")), width = w, height = h)
  print(plot)
  dev.off()
  pdf_path <- file.path(out_dir, paste0(stem, ".pdf"))
  if (file.exists(pdf_path)) file.remove(pdf_path)
  cairo_ok <- tryCatch({
    grDevices::cairo_pdf(pdf_path, width = w, height = h, family = "Arial")
    print(plot)
    dev.off()
    file.exists(pdf_path) && file.info(pdf_path)$size > 0
  }, warning = function(warning) {
    if (dev.cur() > 1) dev.off()
    FALSE
  }, error = function(error) {
    if (dev.cur() > 1) dev.off()
    FALSE
  })
  if (!cairo_ok) {
    # Fallback retains vector paths and selectable Helvetica text when the
    # host lacks cairo/X11 shared libraries.
    grDevices::pdf(pdf_path, width = w, height = h,
                   family = "Helvetica", useDingbats = FALSE)
    print(plot)
    dev.off()
  }
  ragg::agg_png(file.path(out_dir, paste0(stem, ".png")), width = w, height = h, units = "in", res = 600)
  print(plot)
  dev.off()
  ragg::agg_tiff(file.path(out_dir, paste0(stem, ".tiff")), width = w, height = h, units = "in", res = 600, compression = "lzw")
  print(plot)
  dev.off()
}

# S1: Reuse exact source values but redraw at the final common size and type scale.
s1 <- read_csv("outputs/FigureS1A_ECM_high_threshold_sensitivity_source_data.csv", show_col_types = FALSE)
stopifnot(nrow(s1) == 4, all(c("threshold", "n_Ctrl", "n_SSc", "median_Ctrl", "median_SSc", "cliffs_delta", "p_value") %in% names(s1)))
file.copy("outputs/FigureS1A_ECM_high_threshold_sensitivity_source_data.csv", file.path(out_dir, "S1_source_data.csv"), overwrite = TRUE)

s1_median <- bind_rows(
  transmute(s1, threshold, group = "Ctrl", median = median_Ctrl, n = n_Ctrl),
  transmute(s1, threshold, group = "SSc", median = median_SSc, n = n_SSc)
) |> mutate(group = factor(group, levels = c("Ctrl", "SSc")),
            label_x = case_when(threshold == 10 & group == "Ctrl" ~ 9,
                                threshold == 10 & group == "SSc" ~ 11,
                                TRUE ~ as.numeric(threshold)),
            label_y = median + ifelse(group == "Ctrl", 1.15, -1.15))

s1a <- ggplot(s1_median, aes(threshold, median, colour = group)) +
  geom_line(linewidth = 0.75) +
  geom_point(size = 2.4) +
  geom_text(aes(x = label_x, y = label_y, label = paste0("n=", n)), size = 2.65,
            show.legend = FALSE) +
  scale_colour_manual(values = c(Ctrl = ctrl, SSc = ssc)) +
  scale_x_continuous(breaks = s1$threshold, limits = c(2, 33)) +
  coord_cartesian(ylim = c(57, 76)) +
  labs(x = "Minimum Peri_RGS5 cells per participant", y = "Median ECM-high fraction (%)") +
  theme_supp() + theme(legend.position = "bottom")

s1b <- ggplot(s1 |> mutate(label_y = case_when(
  threshold == 5 ~ -0.04,
  threshold == 10 ~ 0.075,
  TRUE ~ cliffs_delta + 0.055
)), aes(threshold, cliffs_delta)) +
  geom_hline(yintercept = 0, linetype = "dashed", colour = "#8C8C8C", linewidth = 0.45) +
  geom_line(colour = accent, linewidth = 0.75) +
  geom_point(shape = 21, fill = "white", colour = accent, stroke = 1.05, size = 2.5) +
  geom_text(aes(y = label_y, label = sprintf("P=%.2f", p_value)), size = 2.75,
            colour = "#3D3D3D") +
  scale_x_continuous(breaks = s1$threshold, limits = c(2, 33)) +
  coord_cartesian(ylim = c(-0.24, 0.45)) +
  labs(x = "Minimum Peri_RGS5 cells per participant", y = "Cliff's delta (SSc vs Ctrl)") +
  theme_supp()

s1_fig <- (s1a + s1b + plot_layout(widths = c(1, 1))) +
  plot_annotation(tag_levels = "A")
save_figure(s1_fig, "Supplementary_Figure_S1", 180, 92)

# S2: Count only reported SEMA4D-PLXNB2 CellChat edges. An empty primary file is
# a verified zero, not a missing value. LIANA-compatible rows are expression-
# gated candidate pairs and are not interactions established by CellChat.
primary <- read_csv("outputs/cellchat_discovery/CellChat_SEMA4D_interactions.csv", show_col_types = FALSE)
sensitivity <- read_csv("outputs/cellchat_discovery/CellChat_SEMA4D_sensitivity_interactions.csv", show_col_types = FALSE)
stopifnot(nrow(primary) == 0, nrow(sensitivity) == 6,
          all(sensitivity$ligand == "SEMA4D"), all(sensitivity$receptor == "PLXNB2"))

cellchat_counts <- sensitivity |>
  mutate(receiver = ifelse(grepl("pericyte", target, ignore.case = TRUE), "Perivascular", "Immune")) |>
  count(condition, receiver, name = "edges") |>
  complete(condition = c("Ctrl", "SSc"), receiver = c("Immune", "Perivascular"), fill = list(edges = 0)) |>
  mutate(method = "truncatedMean (sensitivity)") |>
  bind_rows(expand_grid(condition = c("Ctrl", "SSc"), receiver = c("Immune", "Perivascular")) |>
              mutate(edges = 0L, method = "triMean (primary)")) |>
  mutate(condition = factor(condition, levels = c("Ctrl", "SSc")),
         method = factor(method, levels = c("triMean (primary)", "truncatedMean (sensitivity)")),
         receiver = factor(receiver, levels = c("Immune", "Perivascular")))
write_csv(cellchat_counts, file.path(out_dir, "S2A_CellChat_detected_edges.csv"))

liana <- read_csv("outputs/liana_compatible_check/LIANA_compatible_SEMA4D_PLXNB2.csv", show_col_types = FALSE)
stopifnot(nrow(liana) == 8, all(liana$ligand == "SEMA4D"), all(liana$receptor == "PLXNB2"))
gate_counts <- liana |>
  count(expression_cutoff, condition, name = "pairs") |>
  complete(expression_cutoff = c(0.05, 0.10), condition = c("Ctrl", "SSc"), fill = list(pairs = 0)) |>
  mutate(condition = factor(condition, levels = c("Ctrl", "SSc")),
         cutoff_label = factor(paste0(round(expression_cutoff * 100), "%"), levels = c("5%", "10%")))
write_csv(gate_counts, file.path(out_dir, "S2B_expression_gated_pairs.csv"))

s2a <- ggplot(cellchat_counts, aes(receiver, edges, fill = condition)) +
  geom_col(position = position_dodge(width = 0.7), width = 0.62, colour = "#333333", linewidth = 0.25) +
  geom_text(aes(label = edges), position = position_dodge(width = 0.7), vjust = -0.55, size = 3) +
  facet_wrap(~method, ncol = 1) +
  scale_fill_manual(values = c(Ctrl = ctrl, SSc = ssc)) +
  scale_y_continuous(breaks = 0:4, limits = c(0, 4.8), expand = expansion(mult = c(0, 0))) +
  labs(x = "Receiver compartment", y = "Detected SEMA4D-PLXNB2 edges") +
  theme_supp() + theme(legend.position = "none")

s2b <- ggplot(gate_counts, aes(cutoff_label, pairs, fill = condition)) +
  geom_col(position = position_dodge(width = 0.7), width = 0.62, colour = "#333333", linewidth = 0.25) +
  geom_text(aes(label = pairs), position = position_dodge(width = 0.7), vjust = -0.6, size = 3) +
  scale_fill_manual(values = c(Ctrl = ctrl, SSc = ssc)) +
  scale_y_continuous(breaks = 0:4, limits = c(0, 4.8), expand = expansion(mult = c(0, 0))) +
  labs(x = "Minimum detected-cell fraction", y = "Expression-gated source-receiver pairs") +
  theme_supp() + theme(legend.position = "bottom")

s2_fig <- (s2a + s2b + plot_layout(widths = c(1, 1))) +
  plot_annotation(tag_levels = "A")
save_figure(s2_fig, "Supplementary_Figure_S2", 180, 117)

# S3: Three standardized program scores can share a coefficient axis. The raw
# unstandardized mean is retained in the audit CSV but excluded from the plot
# because its outcome unit is different.
model <- read_csv("audit/results/figure5/coupling_model_sensitivity.csv", show_col_types = FALSE)
model_display <- model |>
  filter(model == "cell_count_adjusted", score %in% c("score_unweighted_z", "score_weighted_z", "score_without_ACTB_z")) |>
  mutate(label = recode(score,
                        score_unweighted_z = "Standardized mean (primary)",
                        score_weighted_z = "NicheNet-weighted mean",
                        score_without_ACTB_z = "Standardized mean without ACTB"),
         label = factor(label, levels = c("Standardized mean without ACTB", "NicheNet-weighted mean", "Standardized mean (primary)")))
stopifnot(nrow(model_display) == 3, all(model_display$n == 22))
write_csv(model_display, file.path(out_dir, "S3A_score_sensitivity.csv"))

target_loo <- read_csv("audit/results/figure5/leave_one_target_gene_out.csv", show_col_types = FALSE) |>
  mutate(ci_low = estimate - qt(0.975, df = 16) * std_error,
         ci_high = estimate + qt(0.975, df = 16) * std_error,
         omitted_target = factor(omitted_target, levels = rev(omitted_target)))
stopifnot(nrow(target_loo) == 10)
write_csv(target_loo, file.path(out_dir, "S3B_leave_one_target_out.csv"))

s3a <- ggplot(model_display, aes(estimate, label)) +
  geom_vline(xintercept = 0, linetype = "dashed", colour = "#8C8C8C", linewidth = 0.45) +
  geom_segment(aes(x = ci_low, xend = ci_high, yend = label), linewidth = 0.75, colour = neutral) +
  geom_point(shape = 21, fill = "white", colour = neutral, stroke = 1.1, size = 2.5) +
  coord_cartesian(xlim = c(-0.008, 0.080)) +
  labs(x = "Adjusted coefficient per 1% SEMA4D+ myeloid cells", y = NULL) +
  theme_supp()

s3b <- ggplot(target_loo, aes(estimate, omitted_target)) +
  geom_vline(xintercept = 0, linetype = "dashed", colour = "#8C8C8C", linewidth = 0.45) +
  geom_vline(xintercept = 0.0351321263, linetype = "dotted", colour = accent, linewidth = 0.6) +
  geom_segment(aes(x = ci_low, xend = ci_high, yend = omitted_target), linewidth = 0.65, colour = neutral) +
  geom_point(aes(fill = ci_low > 0), shape = 21, colour = neutral, stroke = 0.8, size = 2.1) +
  scale_fill_manual(values = c(`TRUE` = accent, `FALSE` = "white"), guide = "none") +
  coord_cartesian(xlim = c(-0.012, 0.082)) +
  labs(x = "Adjusted coefficient after target omission", y = "Omitted gene") +
  theme_supp()

s3_fig <- (s3a + s3b + plot_layout(widths = c(1, 1))) +
  plot_annotation(tag_levels = "A")
save_figure(s3_fig, "Supplementary_Figure_S3", 180, 105)

# S4: The experimentalist confirmed that each of the three region-labeled
# records in a group came from a different mouse, despite reused image prefixes.
distance_dir <- "/Users/baoying/Desktop/免疫荧光/pcs&pfs统计 - 副本/pcs&pfs最近距离"
distance_files <- tibble::tribble(
  ~panel, ~group, ~file,
  "CD3", "Control", "pcs456/pcsctrl456/pcsctrl456.xlsx",
  "CD3", "3d", "pcs456/pcs3d456/pcs3d456.xlsx",
  "CD3", "7d", "pcs456/pcs7d456/pcs7d456.xlsx",
  "F4/80", "Control", "pfs456/pfsctrl456/pfsctrl456.xlsx",
  "F4/80", "3d", "pfs456/pfs3d456/pfs3d456.xlsx",
  "F4/80", "7d", "pfs456/pfs7d456/pfs7d456.xlsx"
)
distance <- purrr::pmap_dfr(distance_files, function(panel, group, file) {
  x <- readxl::read_xlsx(file.path(distance_dir, file), sheet = 1)
  stopifnot(nrow(x) == 3, all(x[[2]] == "IF555+"), all(x[[3]] == "IF647+"))
  tibble(panel = panel, group = group, record = seq_len(nrow(x)),
         region = sub(".*(Region_[0-9]+).*", "\\1", x[[1]]),
         distance_um = as.numeric(x[[6]]))
}) |>
  mutate(panel = factor(panel, levels = c("CD3", "F4/80")),
         group = factor(group, levels = c("Control", "3d", "7d")))
stopifnot(nrow(distance) == 18, all(is.finite(distance$distance_um)))
write_csv(distance, file.path(out_dir, "S4_mouse_level_nearest_distance.csv"))

kw_exact <- function(x) {
  r <- rank(x)
  h <- function(a, b) {
    g <- rep(3L, 9)
    g[a] <- 1L
    g[b] <- 2L
    12 / (9 * 10) * sum(vapply(1:3, function(k) sum(r[g == k])^2 / 3, numeric(1))) - 30
  }
  observed <- h(1:3, 4:6)
  all_h <- numeric(1680)
  i <- 0L
  for (a in combn(9, 3, simplify = FALSE)) {
    for (b in combn(setdiff(1:9, a), 3, simplify = FALSE)) {
      i <- i + 1L
      all_h[i] <- h(a, b)
    }
  }
  stopifnot(i == 1680L)
  c(H = observed, P = mean(all_h >= observed - 1e-10))
}
kw_cd3 <- kw_exact(distance$distance_um[distance$panel == "CD3"])
kw_f480 <- kw_exact(distance$distance_um[distance$panel == "F4/80"])
stopifnot(abs(kw_cd3[["P"]] - 0.1679) < 1e-4,
          abs(kw_f480[["P"]] - 0.2321) < 1e-4)

distance_palette <- c(Control = "#A9B4BB", `3d` = "#E29540", `7d` = "#CD282A")
draw_distance <- function(which_panel, p_value) {
  d <- distance |> filter(panel == which_panel)
  m <- d |> group_by(group) |> summarize(median = median(distance_um), .groups = "drop") |>
    mutate(x = as.numeric(group))
  ggplot(d |> mutate(x = as.numeric(group)), aes(x, distance_um)) +
    geom_segment(data = m, aes(x = x - 0.21, xend = x + 0.21,
                               y = median, yend = median),
                 inherit.aes = FALSE, linewidth = 0.8, colour = "black") +
    geom_point(aes(fill = group), shape = 21, colour = "#303030", stroke = 0.45,
               size = 3, position = position_jitter(width = 0.065, height = 0, seed = 14)) +
    scale_fill_manual(values = distance_palette, guide = "none") +
    scale_x_continuous(breaks = 1:3, labels = c("Control", "3d", "7d"),
                       limits = c(0.5, 3.5)) +
    scale_y_continuous(limits = c(0, 50), breaks = seq(0, 50, 10),
                       expand = expansion(mult = c(0, 0))) +
    annotate("text", x = 2, y = 47, label = sprintf("Exact P = %.4f", p_value),
             size = 3.2, colour = "#303030") +
    labs(x = NULL, y = "Nearest distance (µm)") +
    theme_supp()
}
s4_fig <- (draw_distance("CD3", kw_cd3[["P"]]) +
             draw_distance("F4/80", kw_f480[["P"]]) +
             plot_layout(widths = c(1, 1))) +
  plot_annotation(tag_levels = "A")
save_figure(s4_fig, "Supplementary_Figure_S4", 180, 92)

writeLines(c(
  "All supplementary figures were plotted in R from the indicated source tables.",
  "S1: 4 prespecified minimum-cell thresholds; all supplied rows retained.",
  "S2A: the primary CellChat SEMA4D interaction table contains zero rows; the sensitivity table contains six edges, all inflammatory-myeloid to immune receivers and none to pericytes.",
  "S2B: eight rows in the LIANA-compatible expression audit; this is not a full LIANA consensus analysis or a disease-differential test.",
  "S3A: three standardized scores shown on one numeric axis. The raw unstandardized mean remains in the source audit but is not plotted because it has different outcome units.",
  "S3B: all ten target-gene omissions shown. Approximate 95% confidence intervals are computed as beta +/- t(0.975,16)*SE from the supplied regression output.",
  "S4: three records per condition and panel. The experimentalist confirmed that the three records represent independent mice even though the image prefixes were reused. Each plotted point is one mouse; horizontal bars show medians. Exact Kruskal-Wallis P values were enumerated over 1680 group assignments and match Prism.",
  "These figures do not establish direct cell-cell contact, receptor activation, or causality."
), file.path(out_dir, "QA_notes.txt"))

message("Created Supplementary Figures S1-S4 in ", out_dir)
