suppressPackageStartupMessages({library(ggplot2);library(patchwork)})

# Rebuild the already-audited external-validation plots, then package them as
# three compound panels so wet-lab HE/IF validation can occupy panels D onward.
source("work/Figure5_upgrade_plot.R",local=TRUE)

panelA <- wrap_elements(full=(pA+pB)+plot_layout(widths=c(1.06,.94)))
panelB <- wrap_elements(full=(pC+pD)+plot_layout(widths=c(.92,1.08)))
pE_comp <- pE + theme(plot.title=element_text(margin=margin(l=10)),
                      plot.subtitle=element_text(margin=margin(l=10)))
panelC <- wrap_elements(full=(pE_comp+pF)+plot_layout(widths=c(1.05,.95)))

computational_ABC <- (panelA/panelB/panelC)+
  plot_layout(heights=c(1.03,.92,.96))+
  plot_annotation(tag_levels="A")

save_plot(panelA,"outputs/Figure5A_external_state_atlas_and_expression",183,77)
save_plot(panelB,"outputs/Figure5B_external_pseudobulk_and_pathways",183,73)
save_plot(panelC,"outputs/Figure5C_external_axis_convergence",183,78)
save_plot(computational_ABC,"outputs/Figure5_computational_ABC_current",183,228)

writeLines(c(
  "Figure 5 computational validation panels A-C",
  "A combines independent-cohort myeloid/perivascular state refinement with a state-resolved expression matrix.",
  "B combines participant-level perivascular pseudobulk differential expression with signed GSEA.",
  "C combines discovery NicheNet weights and independent-cohort receiver effects with participant-level cross-compartment coupling.",
  "Independent cohort: GSE138669; Ctrl n=10 and SSc n=12.",
  "All disease inference is participant-level; no cell is treated as an independent biological replicate.",
  "The network is computational convergence, not a direct signaling assay.",
  "Panels D onward are reserved for HE/IF representative images and animal-level quantification after data delivery."
),"outputs/Figure5_computational_ABC_QA_notes.txt")
message("Figure 5 computational A-C assembly complete.")
