suppressPackageStartupMessages({
  library(Seurat)
  library(dplyr)
  library(readr)
  library(tidyr)
})

obj <- readRDS("work/GSE138669_QC_merged.rds")
marker_sets <- list(
  Keratinocyte = c("KRT14", "KRT5", "KRT1", "KRT10"),
  Fibroblast = c("DCN", "COL1A1", "COL3A1", "LUM"),
  Perivascular = c("RGS5", "PDGFRB", "CSPG4", "MCAM", "NOTCH3"),
  Endothelial = c("PECAM1", "VWF", "KDR", "EMCN"),
  Myeloid = c("LST1", "TYROBP", "FCER1G", "CTSS", "CD68"),
  T_NK = c("CD3D", "CD3E", "TRBC1", "NKG7"),
  B_cell = c("CD79A", "MS4A1", "CD37", "CD74"),
  Mast = c("TPSAB1", "TPSB2", "KIT", "CPA3"),
  Melanocyte = c("PMEL", "MLANA", "TYR", "DCT")
)
marker_sets <- lapply(marker_sets, intersect, y = rownames(obj))

for (nm in names(marker_sets)) {
  obj <- AddModuleScore(obj, features = list(marker_sets[[nm]]),
                        name = paste0("type_", nm), seed = 20260802)
}
score_cols <- paste0("type_", names(marker_sets), "1")
cluster_scores <- obj@meta.data |>
  mutate(cluster = as.character(seurat_clusters)) |>
  group_by(cluster) |>
  summarise(n_cells = n(), across(all_of(score_cols), mean), .groups = "drop") |>
  rowwise() |>
  mutate(
    assigned_type = names(marker_sets)[which.max(c_across(all_of(score_cols)))],
    max_score = max(c_across(all_of(score_cols)))
  ) |>
  ungroup()

avg <- AverageExpression(obj, assays = "RNA", features = unique(unlist(marker_sets)),
                         group.by = "seurat_clusters", layer = "data", verbose = FALSE)$RNA |>
  as.data.frame() |>
  tibble::rownames_to_column("gene") |>
  pivot_longer(-gene, names_to = "cluster", values_to = "average_expression")

write_csv(cluster_scores, "outputs/Figure5_GSE138669_cluster_module_scores.csv")
write_csv(avg, "outputs/Figure5_GSE138669_cluster_marker_average.csv")
print(cluster_scores |> select(cluster, n_cells, assigned_type, max_score))
