suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(svglite)
  library(ragg)
})

work_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/work"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"

theme_set(theme_classic(base_size = 8, base_family = "sans"))

load_plot <- function(script, object_name) {
  e <- new.env(parent = globalenv())
  sys.source(file.path(work_dir, script), envir = e)
  e[[object_name]]
}

pA <- load_plot("Figure4A_pericyte_mechanosensing_map.R", "fig")
pB <- load_plot("Figure4B_patient_mechanosensing_ECM.R", "p")
pC <- load_plot("Figure4C_patient_program_correlation_profile.R", "p")
pD <- load_plot("Figure4D_pericyte_state_marker_dotplot.R", "p")
pE <- load_plot("Figure4E_SEMA4D_target_alignment.R", "p")

# Wrap each completed panel so nested layouts do not receive extra panel letters.
wA <- wrap_elements(full = pA)
wB <- wrap_elements(full = pB)
wC <- wrap_elements(full = pC)
wD <- wrap_elements(full = pD)
wE <- wrap_elements(full = pE)

assembly <- wA / (wB | wC) / wD / wE +
  plot_layout(heights = c(0.78, 1.12, 0.92, 0.95)) +
  plot_annotation(
    tag_levels = "A",
    theme = theme(
      plot.tag = element_text(family = "sans", face = "bold", size = 11, colour = "black"),
      plot.tag.position = c(0.004, 0.995),
      plot.margin = margin(3, 3, 3, 3)
    )
  )

width_mm = 178
height_mm = 260

svglite::svglite(
  file.path(out_dir, "Figure4_assembly_5panel_current.svg"),
  width = width_mm / 25.4, height = height_mm / 25.4, bg = "white"
)
print(assembly)
dev.off()

# Preferred on systems with working Cairo/X11 libraries. The current workstation
# uses the native vector PDF export below because those libraries are unavailable.
save_cairo_pdf_when_available <- function(path, plot) {
  grDevices::cairo_pdf(path, width = width_mm / 25.4, height = height_mm / 25.4,
                       family = "sans")
  print(plot)
  dev.off()
}
ggsave(file.path(out_dir, "Figure4_assembly_5panel_current.pdf"), assembly,
       width = width_mm, height = height_mm, units = "mm", bg = "white",
       device = grDevices::pdf)
ggsave(file.path(out_dir, "Figure4_assembly_5panel_current.png"), assembly,
       width = width_mm, height = height_mm, units = "mm", dpi = 300, bg = "white")
ggsave(file.path(out_dir, "Figure4_assembly_5panel_current.tiff"), assembly,
       width = width_mm, height = height_mm, units = "mm", dpi = 600,
       bg = "white", device = ragg::agg_tiff, compression = "lzw")

writeLines(
  c(
    "Figure 4 current assembly: five panels (A-E).",
    "A: matched ECM-state and mechanosensing UMAPs.",
    "B: patient-level mechanosensing-ECM association.",
    "C: patient-level correlation profile with bootstrap confidence intervals.",
    "D: descriptive state-associated marker dot plot.",
    "E: descriptive alignment of SEMA4D-predicted targets with the ECM-high program.",
    "Palette contract: literature red #CB282A and literature blue #1A8FB4 are used consistently for directional/high-low encodings; purple and orange are reserved for distinct functional modules.",
    "Mouse HE/IF validation is intentionally not placed in Figure 4 before images and animal-level quantification are available."
  ),
  file.path(out_dir, "Figure4_assembly_5panel_notes.txt")
)
