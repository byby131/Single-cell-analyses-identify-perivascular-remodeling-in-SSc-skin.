suppressPackageStartupMessages({
  library(Seurat); library(ggplot2); library(dplyr); library(tidyr)
  library(readr); library(scales); library(patchwork); library(ggrepel)
})
set.seed(20260802)

# Claim: a coherent mechanosensing program accompanies ECM remodelling in
# Peri_RGS5 cells at both cell-state and participant levels. Association is not
# interpreted as SEMA4D-PLXNB2 or YAP/TAZ causality.

out <- "outputs"
obj_ecm <- readRDS("/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_ECM_high_vs_low_analysis/Peri_RGS5_ECM_state_seurat.rds")
obj_mech <- readRDS("/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_YAP_TAZ_mechanotransduction/Peri_RGS5_YAP_TAZ_internal_object.rds")
patient_all <- as_tibble(read.csv("/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_YAP_TAZ_mechanotransduction/Patient_level_Peri_RGS5_YAP_TAZ_Mech_variables.csv",check.names=FALSE))
target <- read_csv("outputs/Figure4E_source_data.csv",show_col_types=FALSE)

red<-"#CB282A"; blue<-"#1A8FB4"; purple<-"#7B61A8"; orange<-"#F28E2B"
teal<-"#2A9D8F"; gold<-"#E9C46A"; coral<-"#E76F51"; magenta<-"#C84C83"
indigo<-"#4C5BB4"; navy<-"#26384A"; grey<-"#D5DCE1"; cream<-"#F5EBD2"
final_width_mm <- 183

theme_pub <- theme_classic(base_size=7.2,base_family="Helvetica")+
  theme(axis.line=element_line(linewidth=.35,colour=navy),axis.ticks=element_line(linewidth=.32,colour=navy),
        axis.text=element_text(size=6.2,colour=navy),axis.title=element_text(size=6.9,colour=navy),
        plot.title=element_text(size=8.3,face="bold",colour="#17212B"),
        plot.subtitle=element_text(size=6.2,colour="#65717C"),plot.tag=element_text(size=11,face="bold"),
        legend.title=element_text(size=6.1),legend.text=element_text(size=5.7),
        strip.background=element_blank(),strip.text=element_text(size=6.2,face="bold"),
        panel.grid=element_blank(),plot.margin=margin(3,4,3,3))
theme_set(theme_pub)

# A: same cells, same UMAP, one harmonised mechanosensing score used throughout.
common <- intersect(colnames(obj_ecm),colnames(obj_mech))
um <- as.data.frame(Embeddings(obj_ecm,"umap")[common,1:2,drop=FALSE])
names(um)<-c("UMAP_1","UMAP_2")
um$cell<-rownames(um); um$ECM_state<-obj_ecm@meta.data[common,"ECM_state"]
um$Mechanosensing<-obj_mech@meta.data[common,"Mechanosensing1"]
write_csv(um,file.path(out,"Figure4A_revised_harmonised_source_data.csv"))

map_theme<-theme_void(base_family="Helvetica")+
  theme(plot.title=element_text(size=6.8,face="bold",hjust=0),
        plot.subtitle=element_text(size=5.3,colour="#65717C"),plot.margin=margin(2,3,2,8))
pA1<-ggplot(um,aes(UMAP_1,UMAP_2))+
  geom_point(aes(colour=ECM_state),size=.55,alpha=.78)+
  stat_density_2d(data=filter(um,ECM_state=="ECM-high"),colour=coral,bins=4,linewidth=.35)+
  scale_colour_manual(values=c(`ECM-low`=teal,`ECM-high`=coral),name=NULL)+
  labs(title="ECM topology",subtitle="Peri_RGS5 cells")+map_theme+
  theme(legend.position="bottom",legend.text=element_text(size=5.2),legend.key.width=grid::unit(3,"mm"))
lims<-quantile(um$Mechanosensing,c(.02,.98),na.rm=TRUE)
pA2<-ggplot(um,aes(UMAP_1,UMAP_2))+
  geom_point(aes(colour=Mechanosensing),size=.58,alpha=.82)+
  scale_colour_gradientn(colours=c(indigo,"#5DA5B3",cream,orange,magenta),
                         limits=lims,oob=squish,name="Mechanosensing\nscore")+
  labs(title="Mechanosensing map",subtitle="Harmonised score used in A-D")+map_theme+
  theme(legend.position="right",legend.key.height=grid::unit(4.5,"mm"))
pA<-wrap_elements(full=pA1+pA2+plot_layout(widths=c(1,1.06),guides="keep"))

# Patient eligibility: use >=10 Peri_RGS5 cells, consistent with the prior
# participant-level programme analysis and robust mean-score estimation.
count_before <- nrow(patient_all)
patient <- patient_all |>
  mutate(n_peri=round(total_cells*peri_rgs5_fraction/100)) |>
  filter(n_peri>=10,complete.cases(peri_mechanosensing,peri_ecm))
count_after <- nrow(patient)
write_csv(patient,file.path(out,"Figure4_revised_patient_eligible_n10.csv"))

programs<-tibble(variable=c("peri_ecm","peri_remodeling","peri_contractile","peri_identity","peri_yap_taz_target"),
                 label=c("ECM","Remodelling","Contractile","Pericyte identity","YAP/TAZ target"),
                 family=c("Matrix","Matrix","Cell state","Identity","Mechanotransduction"),
                 colour=c(coral,purple,teal,gold,indigo))
calc_one<-function(v,nboot=4000){
  z<-patient[,c("peri_mechanosensing",v)] |> drop_na()
  ct<-suppressWarnings(cor.test(z[[1]],z[[2]],method="spearman",exact=FALSE))
  boots<-replicate(nboot,{i<-sample.int(nrow(z),replace=TRUE);cor(z[[1]][i],z[[2]][i],method="spearman")})
  tibble(n=nrow(z),rho=unname(ct$estimate),p=ct$p.value,
         ci_low=quantile(boots,.025,na.rm=TRUE),ci_high=quantile(boots,.975,na.rm=TRUE))
}
stats_core<-bind_rows(lapply(programs$variable,calc_one))
stats<-bind_cols(programs,stats_core) |>
  mutate(FDR=p.adjust(p,"BH"),sig=case_when(FDR<.001~"FDR < 0.001",FDR<.05~sprintf("FDR = %.3f",FDR),TRUE~"n.s."))
write_csv(stats,file.path(out,"Figure4_revised_patient_program_statistics_n10.csv"))

# B: joint association plot with marginal distributions. Margins show the
# eligible participant distributions rather than adding another test.
stB<-filter(stats,variable=="peri_ecm")
pBmain<-ggplot(patient,aes(peri_mechanosensing,peri_ecm))+
  geom_smooth(method="lm",formula=y~x,se=TRUE,colour=coral,fill=coral,alpha=.13,linewidth=.65)+
  geom_point(aes(size=n_peri,fill=n_peri),shape=21,colour="white",stroke=.4,alpha=.92)+
  scale_fill_gradientn(colours=c(gold,orange,magenta),name="Peri_RGS5\ncells")+
  scale_size(range=c(1.6,4.2),guide="none")+
  annotate("label",x=-Inf,y=Inf,hjust=-.06,vjust=1.08,
           label=sprintf("Spearman rho = %.2f\nn = %d; FDR = %.3f",stB$rho,stB$n,stB$FDR),
           size=2.05,fill=alpha("white",.9),colour=navy,linewidth=.2)+
  labs(x="Mechanosensing score",y="ECM score")+
  theme(legend.position="right")
pBtop<-ggplot(patient,aes(peri_mechanosensing))+geom_density(fill=purple,colour=NA,alpha=.65,linewidth=0)+theme_void()
pBright<-ggplot(patient,aes(peri_ecm))+geom_density(fill=coral,colour=NA,alpha=.65,linewidth=0)+coord_flip()+theme_void()
pB<-wrap_elements(full=(pBtop+plot_spacer()+plot_layout(widths=c(.86,.14)))/
                    (pBmain+pBright+plot_layout(widths=c(.86,.14)))+
                    plot_layout(heights=c(.15,.85))+
                    plot_annotation(title="Patient-level joint association",
                                    subtitle="Eligible SSc participants with >=10 Peri_RGS5 cells",
                                    theme=theme(plot.title=element_text(margin=margin(l=10)),
                                                plot.subtitle=element_text(margin=margin(l=10)))))

# C: multivariate correlation profile remains the most transparent form.
stats$label<-factor(stats$label,levels=rev(programs$label))
pC<-ggplot(stats,aes(rho,label,colour=family))+
  geom_vline(xintercept=0,linetype=2,linewidth=.35,colour="#8B969E")+
  geom_errorbarh(aes(xmin=ci_low,xmax=ci_high),height=0,linewidth=.9)+
  geom_point(aes(fill=family,size=-log10(FDR)),shape=21,colour="white",stroke=.5)+
  geom_text(aes(label=sig),hjust=.5,vjust=-1.35,size=1.8,colour=navy)+
  scale_colour_manual(values=c(Matrix=coral,`Cell state`=teal,Identity=gold,Mechanotransduction=indigo),guide="none")+
  scale_fill_manual(values=c(Matrix=coral,`Cell state`=teal,Identity=gold,Mechanotransduction=indigo),name=NULL)+
  scale_size(range=c(2.2,4.6),guide="none")+
  scale_x_continuous(limits=c(-.25,1.03),breaks=seq(-.2,1,.2))+
  labs(title="Mechanosensing correlation spectrum",subtitle="Patient-level Spearman rho with bootstrap 95% CI",
       x="Spearman rho",y=NULL)+
  theme(axis.line.y=element_blank(),axis.ticks.y=element_blank(),legend.position="bottom")

# D: continuous state landscape replaces a definition-driven marker dot plot.
md<-obj_mech@meta.data |> tibble::rownames_to_column("cell")
state_pal<-c(Dual_low="#8D99A6",YAP_high_only=indigo,Mech_high_only=orange,YAP_Mech_Dual_high=magenta)
cent<-md |> group_by(YAP_Mech_state) |>
  summarise(x=median(Mechanosensing1),y=median(YAP_TAZ_Target1),ecm=median(ECM1),n=n(),.groups="drop")
cent<-cent |> mutate(state_label=recode(YAP_Mech_state,Dual_low="Dual low",
                                        YAP_high_only="YAP-high",Mech_high_only="Mech-high",
                                        YAP_Mech_Dual_high="Dual high"))
write_csv(md |> select(cell,Mechanosensing1,YAP_TAZ_Target1,ECM1,YAP_Mech_state),
          file.path(out,"Figure4D_revised_state_landscape_source_data.csv"))
pD<-ggplot(md,aes(Mechanosensing1,YAP_TAZ_Target1))+
  geom_point(aes(colour=ECM1),size=.55,alpha=.42)+
  stat_density_2d(aes(linetype=YAP_Mech_state),colour=navy,bins=2,linewidth=.38,show.legend=FALSE)+
  geom_point(data=cent,aes(x,y,size=n,fill=YAP_Mech_state),shape=21,colour="white",stroke=.6,inherit.aes=FALSE)+
  geom_text_repel(data=cent,aes(x,y,label=state_label),inherit.aes=FALSE,
                  size=1.8,colour=navy,seed=20260802,min.segment.length=0,
                  box.padding=.7,point.padding=.45,force=1.8,max.overlaps=Inf)+
  scale_colour_gradientn(colours=c(indigo,"#6AA8B0",cream,orange,magenta),name="ECM score")+
  scale_fill_manual(values=state_pal,guide="none")+
  scale_size(range=c(3.2,5.2),guide="none")+
  labs(title="Mechanotransduction state landscape",
       subtitle="Cell-level topology; contours mark predefined score states",
       x="Mechanosensing score",y="YAP/TAZ target score")+
  theme(legend.position="right")

# E: bivariate target evidence map. This visualizes, but does not independently
# validate, the receiver-state distribution of NicheNet-predicted targets.
target<-target |> mutate(strength=-log10(pmax(p_val_adj,1e-300)),
                         evidence=case_when(p_val_adj<.05&avg_log2FC>.25~"ECM-high associated",
                                            p_val_adj<.05&avg_log2FC < -0.25~"ECM-low associated",
                                            TRUE~"Not differential"))
write_csv(target,file.path(out,"Figure4E_revised_target_evidence_source_data.csv"))
pE<-ggplot(target,aes(avg_log2FC,weight))+
  annotate("rect",xmin=-Inf,xmax=0,ymin=-Inf,ymax=Inf,fill=alpha(blue,.045))+
  annotate("rect",xmin=0,xmax=Inf,ymin=-Inf,ymax=Inf,fill=alpha(coral,.045))+
  geom_vline(xintercept=0,linetype=2,linewidth=.35,colour="#8B969E")+
  geom_point(aes(size=strength,fill=evidence),shape=21,colour="white",stroke=.55,alpha=.95)+
  geom_text_repel(aes(label=target),size=2.0,fontface="italic",seed=20260802,
                  max.overlaps=Inf,min.segment.length=0,segment.size=.25)+
  scale_fill_manual(values=c(`ECM-high associated`=coral,`ECM-low associated`=blue,
                             `Not differential`="#8D99A6"),name=NULL)+
  scale_size(range=c(2.2,6),name=expression(-log[10]*" adjusted P"))+
  labs(title="Predicted-target evidence landscape",
       subtitle="Receiver-state distribution; descriptive, not independent validation",
       x=expression(log[2]*" fold change (ECM-high / ECM-low)"),
       y="NicheNet regulatory potential")+
  theme(legend.position="bottom")

assembly<-((((pA+pB)+plot_layout(widths=c(1.05,.95)))/
            ((pC+pD)+plot_layout(widths=c(.86,1.14)))/pE)+
            plot_layout(heights=c(.95,.92,.88))+plot_annotation(tag_levels="A"))

save_plot<-function(plot,stem,wmm,hmm,dpi=600){w<-wmm/25.4;h<-hmm/25.4
  ggsave(paste0(stem,".png"),plot,width=w,height=h,units="in",dpi=300,bg="white")
  ragg::agg_tiff(paste0(stem,".tiff"),width=w,height=h,units="in",res=dpi,background="white",compression="lzw");print(plot);dev.off()
  svglite::svglite(paste0(stem,".svg"),width=w,height=h,bg="white");print(plot);dev.off()
  use_cairo <- FALSE # local Cairo/X11 DLL is unavailable
  if(use_cairo && isTRUE(capabilities("cairo"))){
    grDevices::cairo_pdf(paste0(stem,".pdf"),width=w,height=h,family="Helvetica",bg="white")
  } else {
    grDevices::pdf(paste0(stem,".pdf"),width=w,height=h,family="Helvetica",bg="white",useDingbats=FALSE)
  }
  print(plot);dev.off()
}
save_plot(pA,file.path(out,"Figure4A_revised_harmonised_topology"),96,70)
save_plot(pB,file.path(out,"Figure4B_revised_joint_association_n10"),87,70)
save_plot(pC,file.path(out,"Figure4C_revised_correlation_spectrum_n10"),82,70)
save_plot(pD,file.path(out,"Figure4D_revised_state_landscape"),101,75)
save_plot(pE,file.path(out,"Figure4E_revised_target_evidence_landscape"),183,68)
save_plot(assembly,file.path(out,"Figure4_revised_assembly_v2"),final_width_mm,213)

write_lines(c("Figure 4 revised QA notes",
  "Panel A uses Mechanosensing1, the same score used in panels B-D; the former Mechanosensing_Core1 map was removed.",
  "Panels B-C include participants with at least 10 Peri_RGS5 cells (n=33); each participant is one statistical unit.",
  sprintf("Participant eligibility: %d before filtering and %d after the >=10 Peri_RGS5-cell and complete-score rule.",count_before,count_after),
  "Correlations are two-sided Spearman tests with BH correction across five prespecified programs; intervals use 4,000 patient bootstrap resamples.",
  "Panel D is descriptive cell-level topology. Score-defined state contours are not inferential tests and do not establish YAP/TAZ causality.",
  "Panel E is a descriptive bivariate map of upstream-selected targets; it is not an independent validation because receiver DE contributed to NicheNet target selection.",
  "The linear fit in panel B is a visual guide; the reported association is Spearman rho."),
  file.path(out,"Figure4_revised_QA_notes.txt"))
message("Revised Figure 4 complete.")
