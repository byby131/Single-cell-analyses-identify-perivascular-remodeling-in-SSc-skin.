suppressPackageStartupMessages({
  library(Seurat); library(dplyr); library(tidyr); library(readr)
  library(fgsea); library(msigdbr); library(Matrix); library(edgeR)
})
set.seed(20260802)
x <- readRDS("work/peri_all_processed.rds")
md <- x@meta.data |> tibble::rownames_to_column("cell_id_internal")

patient <- md |> group_by(patient_id, disease_group) |>
  summarise(n_cells=n(), ECM_z=mean(ECM_z), Contractile_z=mean(Contractile_z),
            ECM_delta=mean(ECM_delta), ECM_high_fraction=mean(ECM_state=="ECM-high")*100,
            .groups="drop")
write_csv(patient,"outputs/Figure2_upgrade_patient_state_metrics_all.csv")
patient_all <- patient
patient <- patient_all |> filter(n_cells >= 10)
write_csv(patient,"outputs/Figure2_upgrade_patient_state_metrics_eligible.csv")
write_csv(tibble(before_patients=nrow(patient_all),after_patients=nrow(patient),
                 excluded_patients=nrow(patient_all)-nrow(patient),
                 rule="at least 10 Peri_RGS5 cells per participant",
                 reason="stabilise participant-level programme means and fractions"),
          "outputs/Figure2_upgrade_patient_exclusion_log.csv")

cliff_delta <- function(ssc,ctrl) mean(outer(ssc,ctrl,">"))-mean(outer(ssc,ctrl,"<"))
metrics <- c("ECM_z","Contractile_z","ECM_delta","ECM_high_fraction")
stats <- bind_rows(lapply(metrics,function(v){
  ctrl<-patient[[v]][patient$disease_group=="Ctrl"]
  ssc<-patient[[v]][patient$disease_group=="SSc"]
  delta<-cliff_delta(ssc,ctrl)
  boots<-replicate(5000,cliff_delta(sample(ssc,replace=TRUE),sample(ctrl,replace=TRUE)))
  wt<-wilcox.test(ssc,ctrl,exact=FALSE)
  tibble(metric=v,n_Ctrl=length(ctrl),n_SSc=length(ssc),median_Ctrl=median(ctrl),median_SSc=median(ssc),
         cliffs_delta=delta,ci_low=quantile(boots,.025),ci_high=quantile(boots,.975),p=wt$p.value)
})) |> mutate(FDR=p.adjust(p,"BH"))
write_csv(stats,"outputs/Figure2_upgrade_patient_state_statistics.csv")

de <- read_csv("outputs/Figure2E_ECMhigh_patient_pseudobulk_full_results.csv",show_col_types=FALSE)
msig <- bind_rows(
  msigdbr(species="Homo sapiens",collection="H"),
  msigdbr(species="Homo sapiens",collection="C2",subcollection="CP:REACTOME"),
  msigdbr(species="Homo sapiens",collection="C5",subcollection="GO:BP")
) |> filter(grepl("EXTRACELLULAR_MATRIX|COLLAGEN|TGF_BETA|TGF_B|MUSCLE_CONTRACTION|CONTRACTILE|CELL_MATRIX|WOUND_HEALING|ACTIN_FILAMENT",gs_name))
pathways<-split(msig$gene_symbol,msig$gs_name)
ranks<-sign(de$logFC)*sqrt(de$F); names(ranks)<-de$gene
ranks<-sort(ranks[is.finite(ranks)],decreasing=TRUE)
gsea<-fgseaMultilevel(pathways,ranks,minSize=10,maxSize=500,eps=0) |> as_tibble() |>
  arrange(padj,desc(abs(NES))) |>
  mutate(leadingEdge=vapply(leadingEdge,paste,collapse=";",FUN.VALUE=character(1)))
write_csv(gsea,"outputs/Figure2_upgrade_pseudobulk_GSEA.csv")

# Participant-level ECM-high pseudobulk heatmap source data (same >=5-cell rule
# as the prespecified edgeR comparison used in Figure 2).
eligible_md <- md |> filter(ECM_state=="ECM-high",disease_group %in% c("Ctrl","SSc"))
cell_n <- eligible_md |> count(patient_id,name="n_ECM_high_cells")
eligible_ids <- cell_n |> filter(n_ECM_high_cells>=5) |> pull(patient_id)
eligible_md <- eligible_md |> filter(patient_id %in% eligible_ids)
counts <- GetAssayData(x,assay="RNA",layer="counts")[rownames(x),eligible_md$cell_id_internal,drop=FALSE]
pf <- factor(eligible_md$patient_id,levels=unique(eligible_md$patient_id))
pb <- counts %*% Matrix::sparse.model.matrix(~0+pf)
colnames(pb)<-levels(pf)
pb_group <- eligible_md |> distinct(patient_id,disease_group) |>
  slice(match(colnames(pb),patient_id))
sel_up <- de |> filter(FDR<.05,logFC>0) |> arrange(FDR,desc(abs(logFC))) |> slice_head(n=12) |> pull(gene)
sel_dn <- de |> filter(FDR<.05,logFC<0) |> arrange(FDR,desc(abs(logFC))) |> slice_head(n=8) |> pull(gene)
sel <- unique(c(sel_up,sel_dn))
lcpm <- edgeR::cpm(pb,log=TRUE,prior.count=2)[sel,,drop=FALSE]
zmat <- t(scale(t(lcpm))); zmat[!is.finite(zmat)]<-0
signature <- colMeans(zmat[intersect(sel_up,rownames(zmat)),,drop=FALSE])
ord <- order(factor(pb_group$disease_group,levels=c("Ctrl","SSc")),signature)
heat <- as.data.frame(as.table(zmat[,ord,drop=FALSE]),stringsAsFactors=FALSE)
names(heat)<-c("gene","patient_id","z")
heat <- heat |> left_join(pb_group,by="patient_id") |>
  mutate(patient_order=match(patient_id,colnames(zmat)[ord]),
         gene_order=match(gene,rev(sel)))
write_csv(heat,"outputs/Figure2_upgrade_patient_pseudobulk_heatmap.csv")
message("Figure 2 upgrade analysis complete: ",nrow(patient_all)," total and ",nrow(patient),
        " eligible participants; ",nrow(gsea)," pathways.")
