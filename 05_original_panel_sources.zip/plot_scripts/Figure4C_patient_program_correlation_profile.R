suppressPackageStartupMessages({
  library(ggplot2)
  library(svglite)
  library(ragg)
})

input_csv <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_YAP_TAZ_mechanotransduction/Patient_level_Peri_RGS5_YAP_TAZ_Mech_variables.csv"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

d <- read.csv(input_csv, check.names = FALSE)
programs <- data.frame(
  variable = c("peri_ecm", "peri_remodeling", "peri_contractile", "peri_identity", "peri_yap_taz_target"),
  label = c("ECM", "Remodeling", "Contractile", "Pericyte identity", "YAP/TAZ target"),
  colour = c("#CB282A", "#9067AC", "#1A8FB4", "#BBBB36", "#59B1CC"),
  stringsAsFactors = FALSE
)

set.seed(20260802)
calc_one <- function(yvar, n_boot = 4000) {
  z <- d[complete.cases(d[, c("peri_mechanosensing", yvar)]), c("peri_mechanosensing", yvar)]
  rho <- suppressWarnings(cor(z[[1]], z[[2]], method = "spearman"))
  test <- suppressWarnings(cor.test(z[[1]], z[[2]], method = "spearman", exact = FALSE))
  boot <- replicate(n_boot, {
    idx <- sample.int(nrow(z), nrow(z), replace = TRUE)
    suppressWarnings(cor(z[[1]][idx], z[[2]][idx], method = "spearman"))
  })
  ci <- quantile(boot[is.finite(boot)], c(0.025, 0.975), na.rm = TRUE)
  data.frame(n = nrow(z), rho = rho, ci_low = ci[1], ci_high = ci[2], p_value = test$p.value)
}

res <- do.call(rbind, lapply(programs$variable, calc_one))
res <- cbind(programs, res)
res$FDR <- p.adjust(res$p_value, method = "BH")
res$sig <- ifelse(res$FDR < 0.001, "FDR < 0.001",
                  ifelse(res$FDR < 0.05, sprintf("FDR = %.3f", res$FDR), "n.s."))
res$label <- factor(res$label, levels = rev(programs$label))

p <- ggplot(res, aes(rho, label, colour = label)) +
  geom_vline(xintercept = 0, linewidth = 0.45, colour = "#9B9B9B", linetype = 2) +
  geom_errorbarh(aes(xmin = ci_low, xmax = ci_high), height = 0, linewidth = 0.85) +
  geom_point(shape = 21, size = 3.4, stroke = 0.6, fill = "white") +
  geom_text(aes(x = rho, label = sig), colour = "#303030", hjust = 0.5,
            vjust = -1.55, size = 2.35, family = "sans") +
  scale_colour_manual(values = setNames(programs$colour, programs$label), guide = "none") +
  scale_x_continuous(
    limits = c(-0.25, 1.06), breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8, 1.0),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    title = "Mechanosensing correlation profile",
    subtitle = "Across SSc patients (n = 93)",
    x = "Spearman rho (95% bootstrap CI)",
    y = NULL
  ) +
  theme_classic(base_size = 9, base_family = "sans") +
  theme(
    axis.line.y = element_blank(),
    axis.line.x = element_line(linewidth = 0.45, colour = "black"),
    axis.ticks.y = element_blank(),
    axis.ticks.x = element_line(linewidth = 0.4, colour = "black"),
    axis.text.y = element_text(size = 8.5, colour = "black", margin = margin(r = 4)),
    axis.text.x = element_text(size = 7.5, colour = "black"),
    axis.title.x = element_text(size = 8.5, colour = "black", margin = margin(t = 5)),
    plot.title = element_text(size = 9.8, face = "bold", hjust = 0, margin = margin(b = 1)),
    plot.subtitle = element_text(size = 8, colour = "#555555", hjust = 0, margin = margin(b = 7)),
    plot.margin = margin(6, 7, 5, 7)
  )

width_mm = 88
height_mm = 76

ggsave(file.path(out_dir, "Figure4C_patient_program_correlation_profile.svg"), p,
       width = width_mm, height = height_mm, units = "mm", bg = "white",
       device = svglite::svglite)
ggsave(file.path(out_dir, "Figure4C_patient_program_correlation_profile.pdf"), p,
       width = width_mm, height = height_mm, units = "mm", bg = "white",
       device = grDevices::pdf)
ggsave(file.path(out_dir, "Figure4C_patient_program_correlation_profile.png"), p,
       width = width_mm, height = height_mm, units = "mm", dpi = 400, bg = "white")
ggsave(file.path(out_dir, "Figure4C_patient_program_correlation_profile.tiff"), p,
       width = width_mm, height = height_mm, units = "mm", dpi = 600,
       bg = "white", device = ragg::agg_tiff, compression = "lzw")

write.csv(res, file.path(out_dir, "Figure4C_source_data_and_statistics.csv"), row.names = FALSE)
writeLines(
  c(
    "Statistical unit: one SSc patient.",
    "Association test: two-sided Spearman correlation.",
    "Intervals: patient-level percentile bootstrap 95% confidence intervals (4,000 resamples).",
    "Multiple-testing correction: Benjamini-Hochberg FDR across five prespecified program correlations.",
    "All patients with complete values were retained; n = 93 for every displayed comparison.",
    "The plot shows association and does not establish SEMA4D-PLXNB2 causality.",
    "Preferred PDF device on a configured workstation: grDevices::cairo_pdf; native vector PDF used here because Cairo/X11 is unavailable."
  ),
  file.path(out_dir, "Figure4C_QA_notes.txt")
)
