suppressPackageStartupMessages({
  library(ggplot2); library(dplyr); library(tidyr); library(readr)
  library(scales); library(patchwork); library(ggrepel)
})
set.seed(20260811)

# Figure 3 contract
# Normal skin is the disease comparator for participant-level inference.
# Panels A-B prioritize a testable candidate; C-E audit disease specificity;
# panel F localizes expression states without claiming spatial contact.
ranked <- read_csv("outputs/Figure3A_source_data.csv",show_col_types=FALSE)
cand <- read_csv("outputs/Figure3B_candidate_summary_source_data.csv",show_col_types=FALSE)
mat <- read_csv("outputs/Figure3B_candidate_matrix_source_data.csv",show_col_types=FALSE)
endpoint <- read_csv("outputs/Figure3_normal_control_audit/patient_endpoint_values.csv",show_col_types=FALSE)
headline <- read_csv("outputs/Figure3_normal_control_audit/patient_endpoint_statistics.csv",show_col_types=FALSE)
target_stats <- read_csv("outputs/Figure3_normal_control_audit/perivascular_target_gene_disease_statistics.csv",show_col_types=FALSE)
myeloid <- read_csv("outputs/Figure3E_SEMA4D_myeloid_UMAP_source_data.csv",show_col_types=FALSE)
peri <- read_csv("outputs/Figure3E_PLXNB2_Peri_RGS5_UMAP_source_data.csv",show_col_types=FALSE)

red <- "#CB282A"; blue <- "#1A8FB4"; purple <- "#7B61A8"; orange <- "#F28E2B"
teal <- "#2A9D8F"; gold <- "#E9C46A"; coral <- "#E76F51"; magenta <- "#C84C83"
navy <- "#26384A"; grey <- "#D5DCE1"; light <- "#F4F6F7"
pal <- c(Ctrl=blue,SSc=red)

theme_pub <- theme_classic(base_size=7.2,base_family="Helvetica")+
  theme(axis.line=element_line(linewidth=.35,colour=navy),
        axis.ticks=element_line(linewidth=.32,colour=navy),
        axis.text=element_text(size=6.2,colour=navy),
        axis.title=element_text(size=6.9,colour=navy),
        plot.title=element_text(size=8.3,face="bold",colour="#17212B"),
        plot.subtitle=element_text(size=6.2,colour="#65717C"),
        plot.tag=element_text(size=11,face="bold"),
        legend.title=element_text(size=6),legend.text=element_text(size=5.7),
        panel.grid=element_blank(),plot.margin=margin(3,4,3,3))
theme_set(theme_pub)

# A. Expression-gated ligand ranking.
ra <- ranked |> slice_head(n=15) |>
  mutate(ligand=factor(ligand,levels=rev(ligand)),
         status=case_when(ligand=="SEMA4D"~"Validation focus",
                          obvious_mature_axis~"Established axis",
                          ligand=="DCN"~"Top activity",
                          TRUE~"Other candidate"))
pA <- ggplot(ra,aes(aupr_corrected,ligand))+
  geom_segment(aes(x=0,xend=aupr_corrected,yend=ligand,colour=status),linewidth=.72,alpha=.72)+
  geom_point(aes(fill=status),shape=21,size=2.55,colour="white",stroke=.42)+
  scale_colour_manual(values=c(`Validation focus`=orange,`Established axis`=purple,
                               `Top activity`=teal,`Other candidate`="#AEBAC2"),guide="none")+
  scale_fill_manual(values=c(`Validation focus`=orange,`Established axis`=purple,
                             `Top activity`=teal,`Other candidate`="#AEBAC2"),name=NULL,
                    labels=c(`Validation focus`="Validation focus",`Established axis`="Established",
                             `Top activity`="Top activity",`Other candidate`="Other"),
                    guide=guide_legend(nrow=2,byrow=TRUE))+
  scale_x_continuous(expand=expansion(mult=c(0,.08)))+
  labs(title="Expression-gated ligand ranking",subtitle="SEMA4D ranks fourth by corrected AUPR",
       x="NicheNet ligand activity (corrected AUPR)",y=NULL)+
  theme(legend.position="bottom",axis.line.y=element_blank(),axis.ticks.y=element_blank())

# B. Candidate matrix; raw values remain primary, colour is within-column.
mat$metric <- factor(mat$metric,levels=c("Ligand\nactivity","Sender\nenrichment",
                                        "Receiver\nenrichment","Pair\nsupport","Receptor\nspecificity"))
mat$ligand <- factor(mat$ligand,levels=rev(c("DCN","TGFB1","TIMP2","SEMA4D")))
pB_core <- ggplot(mat,aes(metric,ligand))+
  geom_tile(aes(fill=score),colour="white",linewidth=.75)+
  geom_text(aes(label=label),size=1.82,colour=navy)+
  scale_fill_gradientn(colours=c("#F1F3F4","#D7E8E8","#8CC7C2",teal),limits=c(0,1),
                       name="Within-column\nrelative evidence")+
  labs(x=NULL,y=NULL)+
  theme(axis.text.x=element_text(size=5.4,face="bold"),axis.text.y=element_text(face="italic",size=6.3),
        axis.line=element_blank(),axis.ticks=element_blank(),legend.position="bottom",plot.margin=margin(2,1,2,2))
status_review <- cand |> mutate(ligand=factor(ligand,levels=levels(mat$ligand)),
                                status=case_when(ligand=="SEMA4D"~"Validation focus",
                                                 pathway_status=="Established fibrotic axis"~"Established",
                                                 TRUE~"Other"))
pB_status <- ggplot(status_review,aes("Axis\nstatus",ligand))+
  geom_tile(fill="#F1F3F4",colour="white",linewidth=.75)+
  geom_point(aes(fill=status),shape=21,size=3.0,colour="white",stroke=.45)+
  scale_fill_manual(values=c(Established=purple,`Validation focus`=orange,Other=teal),guide="none")+
  labs(x=NULL,y=NULL)+
  theme(axis.text.x=element_text(size=5.4,face="bold"),axis.text.y=element_blank(),
        axis.line=element_blank(),axis.ticks=element_blank(),plot.margin=margin(2,2,2,0))
pB <- wrap_elements(full=(pB_core+pB_status+plot_layout(widths=c(5,1.1)))+
  plot_annotation(title="Multi-evidence candidate matrix",
                  subtitle="Raw values shown; colour normalized within each evidence column") &
  theme(plot.title=element_text(size=8.3,face="bold",family="Helvetica",colour="#17212B",margin=margin(l=12)),
        plot.subtitle=element_text(size=6.2,family="Helvetica",colour="#65717C",margin=margin(l=12))))

cliff_delta <- function(x,y) mean(outer(x,y,"-")>0)-mean(outer(x,y,"-")<0)
boot_delta <- function(dd,B=1600){
  x <- dd$value[dd$condition=="SSc"]; y <- dd$value[dd$condition=="Ctrl"]
  b <- replicate(B,cliff_delta(sample(x,length(x),TRUE),sample(y,length(y),TRUE)))
  quantile(b,c(.025,.975),na.rm=TRUE,names=FALSE)
}

# C. Disease audit using participant-level effect sizes and bootstrap CIs.
effect_labels <- c(
  "Immune SEMA4D detection"="SEMA4D+ immune cells",
  "Immune SEMA4D logCPM"="SEMA4D immune pseudobulk",
  "Peri_RGS5 PLXNB2 detection"="PLXNB2+ Peri_RGS5 cells",
  "Peri_RGS5 PLXNB2 logCPM"="PLXNB2 Peri_RGS5 pseudobulk",
  "Perivascular target program"="Predicted receiver-target program")
cis <- endpoint |> group_by(endpoint) |> group_modify(~{
  ci <- boot_delta(.x); tibble(ci_low=ci[1],ci_high=ci[2])
}) |> ungroup()
hc <- headline |> left_join(cis,by="endpoint") |>
  mutate(label=unname(effect_labels[endpoint]),
         label=factor(label,levels=rev(unname(effect_labels))),
         direction=case_when(FDR<.05 & cliff_delta>0~"Higher in SSc",
                             FDR<.05 & cliff_delta<0~"Higher in Ctrl",
                             TRUE~"Not significant"),
         fdr_label=ifelse(FDR<.001,"FDR < 0.001",sprintf("FDR = %.3f",FDR)))
pC <- ggplot(hc,aes(cliff_delta,label))+
  geom_vline(xintercept=0,linetype=2,linewidth=.35,colour="#87939B")+
  geom_errorbarh(aes(xmin=ci_low,xmax=ci_high,colour=direction),height=.13,linewidth=.58)+
  geom_point(aes(fill=direction),shape=21,size=3.1,colour="white",stroke=.45)+
  geom_text(aes(x=.80,label=fdr_label),hjust=0,size=1.72,colour=navy)+
  scale_colour_manual(values=c(`Higher in SSc`=red,`Higher in Ctrl`=blue,`Not significant`="#AEBAC2"),guide="none")+
  scale_fill_manual(values=c(`Higher in SSc`=red,`Higher in Ctrl`=blue,`Not significant`="#AEBAC2"),name=NULL)+
  coord_cartesian(xlim=c(-.55,1.14),clip="off")+
  labs(title="Normal-skin disease audit",subtitle="Participant-level Cliff's delta with bootstrap 95% CI",
       x="Effect size (positive = higher in SSc)",y=NULL)+
  theme(axis.line.y=element_blank(),axis.ticks.y=element_blank(),legend.position="bottom")

# D. Hero result: receiver-target programme.
td <- endpoint |> filter(endpoint=="Perivascular target program")
ts <- headline |> filter(endpoint=="Perivascular target program")
pD <- ggplot(td,aes(condition,value,fill=condition,colour=condition))+
  geom_violin(width=.78,alpha=.14,linewidth=.5,trim=FALSE)+
  geom_boxplot(width=.25,outlier.shape=NA,alpha=.72,linewidth=.4,colour=navy)+
  geom_point(position=position_jitter(width=.08,height=0,seed=18),shape=21,size=1.35,stroke=.22,alpha=.75)+
  scale_fill_manual(values=pal)+scale_colour_manual(values=pal)+
  annotate("text",x=1.5,y=max(td$value)+.30,label=sprintf("Ctrl n=%d; SSc n=%d\nP = %.2g; FDR = %.2g; delta = %.2f",
                                                        ts$n_Ctrl,ts$n_SSc,ts$p,ts$FDR,ts$cliff_delta),size=1.92,colour=navy)+
  scale_y_continuous(expand=expansion(mult=c(.04,.23)))+
  labs(title="Receiver-target programme is increased in SSc",subtitle="Each point is one participant",
       x=NULL,y="Mean predicted-target programme (z score)")+
  theme(legend.position="none")

# E. Individual predicted targets with participant bootstrap CIs.
target_values <- read_csv("outputs/Figure3_normal_control_audit/patient_pseudobulk_all_endpoints.csv",show_col_types=FALSE) |>
  filter(compartment=="Peri_RGS5",eligible,gene %in% target_stats$gene)
target_ci <- target_values |> group_by(gene) |> group_modify(~{
  dd <- transmute(.x,condition,value=logCPM); ci <- boot_delta(dd,1200)
  tibble(ci_low=ci[1],ci_high=ci[2])
}) |> ungroup()
te <- target_stats |> left_join(target_ci,by="gene") |>
  arrange(cliff_delta) |> mutate(gene=factor(gene,levels=gene),significant=FDR<.05)
pE <- ggplot(te,aes(cliff_delta,gene))+
  geom_vline(xintercept=0,linetype=2,linewidth=.35,colour="#87939B")+
  geom_errorbarh(aes(xmin=ci_low,xmax=ci_high),height=.11,linewidth=.48,colour="#9AA6AE")+
  geom_point(aes(size=-log10(pmax(FDR,1e-8)),fill=delta,alpha=significant),shape=21,colour="white",stroke=.45)+
  scale_fill_gradient2(low=blue,mid=grey,high=red,midpoint=0,name="Median logCPM\ndifference")+
  scale_size(range=c(2.0,4.7),name=expression(-log[10]*" FDR"))+
  scale_alpha_manual(values=c(`TRUE`=1,`FALSE`=.48),guide="none")+
  labs(title="Predicted-target disease effects",subtitle="Peri_RGS5 participant pseudobulk; bootstrap 95% CI",
       x="Cliff's delta (positive = higher in SSc)",y=NULL)+
  theme(axis.line.y=element_blank(),axis.ticks.y=element_blank(),axis.text.y=element_text(face="italic"),
        legend.position="bottom",legend.box="horizontal")

# F. Cell-state localization; descriptive only.
map_theme <- theme_void(base_family="Helvetica")+
  theme(plot.title=element_text(size=6.6,face="bold",hjust=0),
        plot.subtitle=element_text(size=5.35,colour="#69747D"),plot.margin=margin(2,2,1,10))
pm_state <- ggplot(myeloid,aes(map_x,map_y))+
  geom_point(aes(colour=state_group),size=.31,alpha=.72)+
  scale_colour_manual(values=c(M_CD16_IL1B=purple,M_IL1B=magenta,Other="#CBD4D9"),guide="none")+
  labs(title="Myeloid states",subtitle="SSc myeloid compartment")+map_theme
pp_state <- ggplot(peri,aes(map_x,map_y))+
  geom_point(aes(colour=ECM_state),size=.29,alpha=.62)+
  scale_colour_manual(values=c(`ECM-low`=teal,`ECM-high`=coral),guide="none")+
  labs(title="Perivascular states",subtitle="Peri_RGS5: Ctrl + SSc")+map_theme
expr_cols <- c("#F2F4F5",gold,orange,magenta,"#7A1737")
pm_expr <- ggplot(myeloid,aes(map_x,map_y))+
  geom_point(colour="#DCE2E5",size=.28)+
  geom_point(data=filter(myeloid,expression>0),aes(colour=relative_expression),size=.55,alpha=.9)+
  scale_colour_gradientn(colours=expr_cols,limits=c(0,1),guide="none")+
  labs(title=expression(italic(SEMA4D)),subtitle="Within-gene expression")+map_theme
pp_expr <- ggplot(peri,aes(map_x,map_y))+
  geom_point(colour="#DCE2E5",size=.25)+
  geom_point(data=filter(peri,expression>0),aes(colour=relative_expression),size=.48,alpha=.86)+
  scale_colour_gradientn(colours=expr_cols,limits=c(0,1),name="Relative\nexpression")+
  labs(title=expression(italic(PLXNB2)),subtitle="Within-gene expression")+map_theme+
  theme(legend.position="right",legend.key.height=grid::unit(5,"mm"))
pF <- wrap_elements(full=(pm_state+pp_state)/(pm_expr+pp_expr)+plot_layout(guides="collect"))

tag_panel <- function(p,tag){
  letter <- ggplot()+
    annotate("text",x=0,y=1,label=tag,hjust=0,vjust=1,
             family="Helvetica",fontface="bold",size=4.0,colour="#111111")+
    xlim(0,1)+ylim(0,1)+theme_void()
  wrap_elements(full=(letter+p)+plot_layout(widths=c(.045,.955)))
}
row1 <- (tag_panel(pA,"A")+tag_panel(pB,"B"))+plot_layout(widths=c(.82,1.18))
row2 <- (tag_panel(pC,"C")+tag_panel(pD,"D"))+plot_layout(widths=c(1.12,.88))
row3 <- (tag_panel(pE,"E")+tag_panel(pF,"F"))+plot_layout(widths=c(.88,1.12))
fig <- (row1/row2/row3)+
  plot_layout(heights=c(.90,.83,1.18))

save_vector <- function(plot,stem,wmm,hmm,dpi=600){
  w <- wmm/25.4; h <- hmm/25.4
  ggsave(paste0(stem,".png"),plot,width=w,height=h,dpi=320,bg="white")
  ragg::agg_tiff(paste0(stem,".tiff"),width=w,height=h,units="in",res=dpi,background="white",compression="lzw")
  print(plot); grDevices::dev.off()
  grDevices::pdf(paste0(stem,".pdf"),width=w,height=h,family="Helvetica",useDingbats=FALSE,bg="white")
  print(plot); grDevices::dev.off()
}

save_vector(fig,"outputs/Figure3_normal_control_rebuild_v5",183,230)

# Exact A4 portrait vector preview. Figure content is centered at 183 mm width.
a4 <- ((plot_spacer()+fig+plot_spacer())+plot_layout(widths=c(13.5,183,13.5)))
save_vector(a4,"outputs/Figure3_normal_control_rebuild_v5_A4",210,297)
dir.create("output/pdf",recursive=TRUE,showWarnings=FALSE)
file.copy("outputs/Figure3_normal_control_rebuild_v5_A4.pdf",
          "output/pdf/Figure3_normal_control_rebuild_v5_A4_vector.pdf",overwrite=TRUE)

write_csv(hc,"outputs/Figure3C_normal_skin_axis_audit_source_data.csv")
write_csv(te,"outputs/Figure3E_normal_skin_target_effects_source_data.csv")
writeLines(c(
  "Figure 3 normal-control rebuild v5",
  "Ctrl is #1A8FB4 and SSc is #CB282A throughout disease comparisons.",
  "Panels C-E use the participant as the inferential unit; immune endpoints require >=10 cells and Peri_RGS5 endpoints require >=5 cells.",
  "SEMA4D immune abundance and PLXNB2 detection are not increased in SSc; Peri_RGS5 PLXNB2 pseudobulk is lower in SSc.",
  "The predicted receiver-target programme is higher in SSc; this supports disease-context-dependent downstream responsiveness, not ligand or receptor upregulation.",
  "Panel A does not claim SEMA4D is the top ligand. Panel B uses within-column normalization only.",
  "Panel F is descriptive and does not establish spatial contact or direct signaling.",
  "A4 PDF is exact 210 x 297 mm and remains vector."
),"outputs/Figure3_normal_control_rebuild_v5_QA_notes.txt")
