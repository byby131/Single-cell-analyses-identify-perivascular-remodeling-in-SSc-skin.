library(grid)

out_dir <- "outputs"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
width_mm <- 180
height_mm <- 180

C <- list(
  ink="#242326", cream="#FBF0DA", lilac="#EEE5F1", blue="#E6F0F7",
  mint="#E5F1EF", blush="#F8E4E3", skin="#F2B6AA", dermis="#F9D5CE",
  vessel="#B85E4F", lumen="#FFF7F2", rbc="#CE514E", myeloid="#D96870",
  pericyte="#55A99B", purple="#76509A", gold="#E8A451", grey="#66717A",
  dark="#16222D", cyan="#42D3C2", magenta="#D94D8C"
)

gp0 <- function(fill=NA, col=C$ink, lwd=1.3, fontsize=8, fontface="plain")
  gpar(fill=fill, col=col, lwd=lwd, fontsize=fontsize, fontfamily="Helvetica", fontface=fontface,
       linejoin="round", lineend="round")
txt <- function(label,x,y,size=8,face="plain",col=C$ink,just="centre",rot=0)
  grid.text(label,x,y,just=just,rot=rot,gp=gp0(col=col,fontsize=size,fontface=face))
rr <- function(x,y,w,h,fill,rad=.02,col=C$ink,lwd=1.2)
  grid.roundrect(x,y,w,h,r=unit(rad,"npc"),gp=gp0(fill,col,lwd))
ln <- function(x,y,col=C$ink,lwd=1.4,arrow=FALSE)
  grid.lines(x,y,gp=gp0(col=col,lwd=lwd),arrow=if(arrow) arrow(type="closed",length=unit(2.4,"mm")) else NULL)

cell <- function(x,y,r=.025,fill=C$myeloid, nucleus="#F8C8C8") {
  grid.circle(x,y,r,gp=gp0(fill,C$ink,1.0)); grid.circle(x-.007,y+.006,r*.29,gp=gp0(nucleus,NA,0))
  grid.circle(x+.008,y-.004,r*.25,gp=gp0(nucleus,NA,0))
}
pericyte <- function(x,y,rot=0,s=.06) {
  grid.ellipse <- function(...) grid.circle(...)
  pushViewport(viewport(x=x,y=y,width=s,height=s*.56,angle=rot))
  grid.circle(.5,.5,.42,gp=gp0(C$pericyte,"#347D73",1.2)); grid.circle(.5,.5,.19,gp=gp0("#F0C2A8","#9D644D",.8))
  popViewport()
}
mouse_icon <- function(x,y,s=.06,fill="#DDA989") {
  grid.ellipse <- function(x,y,w,h,...) grid.circle(x,y,unit(min(w,h)/2,"npc"),...)
  grid.circle(x,y,s*.55,gp=gp0(fill,"#A56547",1.1)); grid.circle(x+s*.42,y+s*.11,s*.27,gp=gp0(fill,"#A56547",1.1))
  grid.circle(x+s*.5,y+s*.31,s*.11,gp=gp0("#F1CCB3","#A56547",.8)); grid.circle(x+s*.5,y+s*.14,s*.035,gp=gp0(C$ink,NA,0))
  grid.bezier(c(x-s*.45,x-s*.8,x-s*.75,x-s*.95),c(y,y+s*.25,y+s*.42,y+s*.05),gp=gp0(col="#A56547",lwd=1.2))
}

draw <- function() {
  grid.newpage(); grid.rect(gp=gp0("white",NA,0)); grid.rect(gp=gp0(NA,C$ink,2.2))
  # softly separated evidence zones
  grid.rect(.255,.755,.49,.47,gp=gp0(C$cream,NA,0)); grid.rect(.755,.755,.47,.47,gp=gp0(C$lilac,NA,0))
  grid.rect(.255,.255,.49,.47,gp=gp0(C$blue,NA,0)); grid.rect(.755,.255,.47,.47,gp=gp0(C$mint,NA,0))

  # top left: human atlas
  txt("Human SSc skin atlas",.04,.956,14,"bold",just="left")
  txt("Control",.09,.905,8,"bold","#37677E"); txt("SSc",.205,.905,8,"bold","#B75457")
  # skin punch illustrations
  for (xx in c(.09,.205)) {
    grid.polygon(c(xx-.035,xx+.035,xx+.031,xx-.031),c(.865,.865,.79,.79),gp=gp0(C$dermis,C$ink,.8))
    grid.polygon(c(xx-.035,xx-.015,xx+.005,xx+.035),c(.865,.877,.86,.865),gp=gp0(C$skin,NA,0))
    for(k in 0:3) ln(c(xx-.025,xx+.022),c(.82+k*.01,.81+k*.012),"#DB9C91",.55)
  }
  ln(c(.09,.09),c(.775,.73),lwd=1.2,arrow=TRUE); ln(c(.205,.205),c(.775,.73),lwd=1.2,arrow=TRUE)
  rr(.147,.655,.22,.135,"#FFFDFC",.012,C$ink,1)
  cols <- c("#E98C52","#5A8FB8","#5CA99E","#9675B5","#D65E66")
  px <- c(.075,.102,.128,.155,.184,.214,.09,.119,.147,.176,.205,.066,.098,.132,.165,.198,.082,.116,.151,.187,.221,.139)
  py <- c(.625,.642,.615,.655,.63,.648,.67,.688,.672,.695,.678,.705,.72,.71,.725,.704,.742,.755,.744,.762,.738,.635)
  for(i in seq_along(px)) grid.circle(px[i],py[i],.0065,gp=gp0(cols[(i-1)%%length(cols)+1],NA,0))
  txt("GSE195452 · scRNA-seq",.04,.57,7.2,"plain",just="left")
  txt("Myeloid-pericyte candidates",.04,.545,6.8,"bold",C$purple,just="left")

  # top right: prioritization
  txt("Ligand-receptor prioritization",.535,.956,14,"bold",just="left")
  txt("Expression-gated NicheNet screening",.535,.91,7.5,"bold",C$purple,just="left")
  rr(.55,.69,.18,.17,"white",.012,C$ink,1)
  ln(c(.575,.575),c(.715,.825),lwd=.9); ln(c(.575,.705),c(.715,.715),lwd=.9)
  hs <- c(.035,.055,.08,.115); xs <- seq(.605,.69,length.out=4)
  for(i in 1:4) grid.rect(xs[i],.715+hs[i]/2,.018,hs[i],gp=gp0(c("#C7ADD3","#AE8BC1","#9470AB",C$purple)[i],NA,0))
  txt("SEMA4D",.688,.845,7,"bold",C$purple); txt("rank 4",.69,.695,6.5)
  cell(.79,.79,.035); txt("SEMA4D",.79,.735,7.3,"bold",C$purple)
  ln(c(.82,.875),c(.775,.775),C$purple,2.2,TRUE); pericyte(.91,.775,0,.08); txt("PLXNB2",.91,.715,7.3,"bold",C$purple)
  txt("myeloid sender",.79,.675,6.7,"plain",C$grey); txt("pericyte receiver",.91,.675,6.7,"plain",C$grey)

  # bottom left: mouse validation
  txt("Mouse model of SSc",.255,.045,13,"bold")
  mouse_icon(.09,.42,.07)
  ln(c(.13,.15),c(.40,.38),lwd=1.2,arrow=TRUE)
  days <- c("Normal","2 d","3 d","5 d","7 d")
  for(i in seq_along(days)) {
    yy <- .37-(i-1)*.032; grid.circle(.15,yy,.010,gp=gp0(if(i==1) "#7AA2B8" else c("#F0B0A7","#E98F87","#D87570","#B95755")[i-1],C$ink,.65)); txt(days[i],.17,yy,5.8,just="left")
  }
  txt("n = 3 mice/group",.04,.205,6.7,"plain",C$grey,just="left")
  rr(.07,.18,.095,.08,"white",.01,"#A66B4F",1); grid.rect(.07,.18,.058,.047,gp=gp0("#F2C7AD","#D58C6E",.8)); txt("H&E",.07,.123,7.2,"bold")
  txt("+",.142,.18,14,"bold")
  rr(.21,.18,.095,.08,C$dark,.01,"#A66B4F",1); grid.circle(.19,.185,.011,gp=gp0("#4B73FF",NA,0)); grid.circle(.218,.198,.009,gp=gp0(C$magenta,NA,0)); grid.circle(.23,.17,.012,gp=gp0("#39C7AB",NA,0)); txt("Multiplex IF",.21,.123,7.2,"bold")
  ln(c(.262,.35),c(.18,.18),lwd=1.4,arrow=TRUE); rr(.39,.18,.055,.085,"white",.008,C$ink,1)
  for(p in list(c(.38,.165),c(.394,.19),c(.402,.155),c(.388,.205))) grid.circle(p[1],p[2],.004,gp=gp0("#B95558",NA,0)); ln(c(.375,.405),c(.145,.145),lwd=1)
  txt("mouse-level quantification",.39,.115,6.2,"bold")

  # bottom right: spatial validation
  txt("Fibrotic perivascular niche",.755,.045,13,"bold")
  rr(.745,.25,.36,.20,C$dark,.012,C$ink,1)
  # vessel and fluorescence objects
  grid.xspline(c(.59,.66,.74,.84,.9),c(.23,.32,.22,.32,.29),shape=1,open=TRUE,gp=gp0(col=C$cyan,lwd=12))
  grid.xspline(c(.59,.66,.74,.84,.9),c(.23,.32,.22,.32,.29),shape=1,open=TRUE,gp=gp0(col="#75E0D2",lwd=3))
  for(p in list(c(.64,.22),c(.77,.31),c(.86,.22))) { grid.circle(p[1],p[2],.025,gp=gp0(C$magenta,NA,0)); grid.circle(p[1],p[2],.009,gp=gp0("#F18BB3",NA,0)) }
  for(p in list(c(.61,.26),c(.7,.21),c(.81,.27))) grid.circle(p[1],p[2],.006,gp=gp0(C$purple,NA,0))
  txt("SEMA4D+ myeloid cells near PLXNB2+ pericytes",.535,.115,7.1,"bold",just="left")
  txt("cell source - receptor localization - spatial proximity",.535,.088,6.4,"plain",C$grey,just="left")

  # central hero circle; white rim reduces quadrant collision
  grid.circle(.5,.51,.275,gp=gp0("#FFF5F4",C$ink,2.0))
  txt("SSc perivascular niche",.5,.755,11.5,"bold")
  # epidermis cap and dermis
  grid.polygon(c(.29,.71,.69,.31),c(.70,.70,.65,.65),gp=gp0(C$skin,NA,0))
  grid.polygon(c(.31,.69,.66,.34),c(.65,.65,.335,.335),gp=gp0(C$dermis,NA,0))
  for(k in 0:5) grid.xspline(c(.34,.42,.5,.58,.66),rep(.38+k*.045,5)+c(0,.018,-.012,.014,0),shape=1,open=TRUE,gp=gp0(col="#DE9A90",lwd=.85))
  # vessel
  grid.ellipse <- function(x,y,w,h,fill,col,lwd=1) {
    pushViewport(viewport(x=x,y=y,width=w,height=h)); grid.circle(.5,.5,.5,gp=gp0(fill,col,lwd)); popViewport()
  }
  grid.ellipse(.5,.49,.28,.13,C$vessel,C$vessel,1); grid.ellipse(.5,.49,.235,.085,C$lumen,"#D98876",1)
  for(xx in c(.45,.5,.55)) grid.ellipse(xx,.49,.035,.023,C$rbc,NA,0)
  pericyte(.39,.53,-25,.085); pericyte(.61,.46,25,.085)
  cell(.36,.43,.031); cell(.64,.57,.031)
  # ligand particles and directional communication
  for(p in list(c(.39,.45),c(.405,.47),c(.61,.54),c(.595,.52))) grid.circle(p[1],p[2],.006,gp=gp0(C$purple,NA,0))
  ln(c(.39,.42),c(.455,.505),C$purple,2.1,TRUE); ln(c(.61,.58),c(.535,.48),C$purple,2.1,TRUE)
  txt("SEMA4D",.345,.39,6.7,"bold",C$purple); txt("PLXNB2",.64,.41,6.7,"bold",C$purple)
  txt("Inflammatory myeloid-pericyte communication",.5,.305,7.2,"bold",C$purple)

  # restrained callout connectors behind the story direction
  ln(c(.27,.33),c(.63,.59),lwd=1.15,arrow=TRUE)
  ln(c(.73,.67),c(.67,.60),lwd=1.15,arrow=TRUE)
  ln(c(.29,.34),c(.27,.37),lwd=1.15,arrow=TRUE)
  ln(c(.71,.66),c(.29,.38),lwd=1.15,arrow=TRUE)
}

svglite::svglite(file.path(out_dir,"Figure1A_SSc_graphical_abstract_v3.svg"),width=width_mm/25.4,height=height_mm/25.4,system_fonts=list(sans="Arial"),pointsize=8)
draw(); dev.off()
# cairo_pdf is unavailable on this Mac because XQuartz libraries are absent;
# the standard R PDF device below still preserves vector lines and selectable text.
pdf(file.path(out_dir,"Figure1A_SSc_graphical_abstract_v3.pdf"),width=width_mm/25.4,height=height_mm/25.4,family="Helvetica",pointsize=8,useDingbats=FALSE)
draw(); dev.off()
ragg::agg_png(file.path(out_dir,"Figure1A_SSc_graphical_abstract_v3_preview.png"),width=width_mm/25.4,height=height_mm/25.4,res=600,units="in",background="white")
draw(); dev.off()
ragg::agg_tiff(file.path(out_dir,"Figure1A_SSc_graphical_abstract_v3.tiff"),width=width_mm/25.4,height=height_mm/25.4,res=600,units="in",background="white",compression="lzw")
draw(); dev.off()
