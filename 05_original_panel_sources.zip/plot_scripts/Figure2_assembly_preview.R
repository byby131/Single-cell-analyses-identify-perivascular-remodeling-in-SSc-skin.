suppressPackageStartupMessages(library(magick))

out_dir <- "outputs"
files <- c(
  A=file.path(out_dir,"Figure2A_Peri_RGS5_Ctrl_SSc_shared_UMAP_preview.png"),
  B=file.path(out_dir,"Figure2B_Peri_RGS5_ECM_state_UMAP_Cell_palette_v3_preview.png"),
  C=file.path(out_dir,"Figure2D_Peri_RGS5_ECM_state_marker_dotplot_Cell_palette_v3_preview.png"),
  D=file.path(out_dir,"Figure2E_ECMhigh_SSc_vs_Ctrl_patient_pseudobulk.png"),
  F=file.path(out_dir,"Figure2F_patient_ECM_high_fraction_Cell_palette_v1_preview.png")
)
stopifnot(all(file.exists(files)))

panel <- function(path, width, height, label) {
  im <- image_read(path) |>
    image_resize(paste0(width,"x",height)) |>
    image_extent(paste0(width,"x",height), gravity="center", color="white")
  image_annotate(im, label, gravity="northwest", location="+8+5",
                 size=28, font="Helvetica", weight=700, color="black")
}
spacer_h <- function(width, height=18) image_blank(width,height,"white")
spacer_v <- function(width=18, height) image_blank(width,height,"white")

A <- panel(files[["A"]], 1100, 590, "A")
B <- panel(files[["B"]], 680, 590, "B")
row1 <- image_append(c(A,spacer_v(20,590),B), stack=FALSE)

C <- panel(files[["C"]], 1800, 700, "C")

D <- panel(files[["D"]], 1120, 760, "D")
E <- panel(files[["F"]], 660, 760, "E")
row4_core <- image_append(c(D,spacer_v(20,760),E), stack=FALSE)
row4 <- image_extent(row4_core, "1800x760", gravity="center", color="white")

assembled <- image_append(c(row1,spacer_h(1800),C,spacer_h(1800),
                            row4), stack=TRUE)
assembled <- image_border(assembled, "white", "15x15")
image_write(assembled, file.path(out_dir,"Figure2_assembly_preview_revised_v2.png"),
            format="png")
