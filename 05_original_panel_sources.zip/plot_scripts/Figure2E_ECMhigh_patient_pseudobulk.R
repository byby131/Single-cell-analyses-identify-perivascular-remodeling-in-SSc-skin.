suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(edgeR)
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(ggrepel)
  library(svglite)
})

obj_file <- "/Users/baoying/Documents/Codex/2026-07-31/wos/work/peri_all_processed.rds"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"
obj <- readRDS(obj_file)
meta <- obj@meta.data

eligible_cells <- rownames(meta)[meta$ECM_state == "ECM-high" &
                                  meta$disease_group %in% c("Ctrl", "SSc")]
md <- meta[eligible_cells, c("patient_id", "disease_group"), drop = FALSE]
cell_n <- as.data.frame(table(md$patient_id), stringsAsFactors = FALSE)
colnames(cell_n) <- c("patient_id", "n_ECM_high_cells")
eligible_patients <- cell_n$patient_id[cell_n$n_ECM_high_cells >= 5]
keep_cell <- md$patient_id %in% eligible_patients
md <- md[keep_cell, , drop = FALSE]
eligible_cells <- rownames(md)

counts <- GetAssayData(obj, assay = "RNA", layer = "counts")[, eligible_cells, drop = FALSE]
patient_factor <- factor(md$patient_id, levels = unique(md$patient_id))
design_cells <- sparse.model.matrix(~ 0 + patient_factor)
pb <- counts %*% design_cells
colnames(pb) <- levels(patient_factor)

sample_meta <- md %>%
  mutate(patient_id = as.character(patient_id)) %>%
  distinct(patient_id, disease_group) %>%
  slice(match(colnames(pb), patient_id))
stopifnot(identical(sample_meta$patient_id, colnames(pb)))
sample_meta$disease_group <- factor(sample_meta$disease_group, levels = c("Ctrl", "SSc"))

dge <- DGEList(counts = pb, samples = sample_meta, group = sample_meta$disease_group)
design <- model.matrix(~ disease_group, data = sample_meta)
keep_gene <- filterByExpr(dge, design = design)
dge <- dge[keep_gene, , keep.lib.sizes = FALSE]
dge <- calcNormFactors(dge)
dge <- estimateDisp(dge, design, robust = TRUE)
fit <- glmQLFit(dge, design, robust = TRUE)
qlf <- glmQLFTest(fit, coef = "disease_groupSSc")
res <- topTags(qlf, n = Inf, sort.by = "none")$table %>%
  tibble::rownames_to_column("gene") %>%
  mutate(
    direction = case_when(
      FDR < 0.05 & logFC > 0 ~ "Up in SSc",
      FDR < 0.05 & logFC < 0 ~ "Down in SSc",
      TRUE ~ "Not significant"
    ),
    neglog10FDR = -log10(pmax(FDR, 1e-300))
  )

write_csv(res, file.path(out_dir, "Figure2E_ECMhigh_patient_pseudobulk_full_results.csv"))
write_csv(sample_meta %>% left_join(cell_n, by = "patient_id"),
          file.path(out_dir, "Figure2E_ECMhigh_patient_pseudobulk_samples.csv"))

label_genes <- c("COL1A1", "COL1A2", "COL3A1", "COL4A1", "COL5A2",
                 "IGFBP7", "BGN", "APOE", "SPARC", "IFI27",
                 "NR4A1", "HSPA1A", "HSPA1B", "EGR1")
lab <- res %>% filter(gene %in% label_genes, FDR < 0.05)
cols <- c("Up in SSc" = "#CB282A", "Down in SSc" = "#1A8FB4",
          "Not significant" = "#C8CDD0")
n_ctrl <- sum(sample_meta$disease_group == "Ctrl")
n_ssc <- sum(sample_meta$disease_group == "SSc")

p <- ggplot(res, aes(logFC, neglog10FDR)) +
  geom_hline(yintercept = -log10(0.05), colour = "#8B8B8B", linewidth = 0.45,
             linetype = "dashed") +
  geom_vline(xintercept = 0, colour = "#777777", linewidth = 0.45) +
  geom_point(aes(colour = direction), size = 1.25, alpha = 0.78) +
  geom_text_repel(data = lab, aes(label = gene, colour = direction),
                  size = 2.7, fontface = "italic", box.padding = 0.28,
                  point.padding = 0.18, min.segment.length = 0,
                  segment.colour = "#888888", segment.size = 0.3,
                  max.overlaps = Inf, show.legend = FALSE, seed = 12) +
  scale_colour_manual(values = cols, breaks = c("Up in SSc", "Down in SSc", "Not significant")) +
  labs(
    x = expression(log[2]~fold~change~("SSc / Ctrl")),
    y = expression(-log[10]~("FDR")),
    colour = NULL,
    subtitle = paste0("Patient-level pseudobulk; ECM-high Peri_RGS5; n = ",
                      n_ctrl, " Ctrl / ", n_ssc, " SSc")
  ) +
  theme_classic(base_size = 10, base_family = "sans") +
  theme(
    plot.subtitle = element_text(size = 8.4, colour = "#4D4D4D", margin = margin(b = 6)),
    axis.title = element_text(size = 9.5),
    axis.text = element_text(size = 8.3, colour = "#202124"),
    legend.position = "bottom",
    legend.justification = "left",
    legend.text = element_text(size = 8),
    plot.margin = margin(6, 7, 4, 5)
  )

ggsave(file.path(out_dir, "Figure2E_ECMhigh_SSc_vs_Ctrl_patient_pseudobulk.svg"), p,
       width = 5.0, height = 3.8, units = "in", bg = "white")
ggsave(file.path(out_dir, "Figure2E_ECMhigh_SSc_vs_Ctrl_patient_pseudobulk.pdf"), p,
       width = 5.0, height = 3.8, units = "in", device = "pdf", bg = "white")
ggsave(file.path(out_dir, "Figure2E_ECMhigh_SSc_vs_Ctrl_patient_pseudobulk.png"), p,
       width = 5.0, height = 3.8, units = "in", dpi = 320, bg = "white")
ggsave(file.path(out_dir, "Figure2E_ECMhigh_SSc_vs_Ctrl_patient_pseudobulk.tiff"), p,
       width = 5.0, height = 3.8, units = "in", dpi = 600,
       compression = "lzw", bg = "white")
