suppressPackageStartupMessages({
  library(Seurat)
  library(dplyr)
  library(tidyr)
  library(readr)
})

obj <- readRDS("work/sce_skin_candidate_axes.rds")
meta <- obj@meta.data
expr <- GetAssayData(obj, assay = "RNA", layer = "data")

summarise_compartment <- function(cell_ids, gene, prefix) {
  tibble(
    patient_id = meta[cell_ids, "patient_id"],
    value = as.numeric(expr[gene, cell_ids])
  ) |>
    group_by(patient_id) |>
    summarise(
      "{prefix}_n_cells" := n(),
      "{prefix}_mean" := mean(value),
      "{prefix}_pct" := mean(value > 0) * 100,
      .groups = "drop"
    )
}

sender_cells <- rownames(meta)[meta$annotation %in% c("M_IL1B", "M_CD16_IL1B")]
receiver_cells <- rownames(meta)[meta$annotation == "Peri_RGS5"]

sender <- summarise_compartment(sender_cells, "SEMA4D", "sender_SEMA4D")
receiver <- summarise_compartment(receiver_cells, "PLXNB2", "receiver_PLXNB2")
ecm <- tibble(
  patient_id = meta[receiver_cells, "patient_id"],
  ecm_score = meta[receiver_cells, "Peri_ECM1"]
) |>
  group_by(patient_id) |>
  summarise(receiver_ECM_mean = mean(ecm_score, na.rm = TRUE), .groups = "drop")

patient <- sender |>
  inner_join(receiver, by = "patient_id") |>
  inner_join(ecm, by = "patient_id") |>
  mutate(disease_group = if_else(grepl("^Ctrl", patient_id), "Ctrl", "SSc"))

# Minimum five cells in each compartment limits unstable percentages from tiny samples.
eligible <- patient |>
  filter(sender_SEMA4D_n_cells >= 5, receiver_PLXNB2_n_cells >= 5)

tests <- tribble(
  ~x, ~y,
  "sender_SEMA4D_pct", "receiver_PLXNB2_pct",
  "sender_SEMA4D_pct", "receiver_ECM_mean",
  "receiver_PLXNB2_pct", "receiver_ECM_mean"
)

stats <- tests |>
  rowwise() |>
  mutate(
    n = sum(complete.cases(eligible[[x]], eligible[[y]])),
    rho = cor(eligible[[x]], eligible[[y]], method = "spearman", use = "complete.obs"),
    p = cor.test(eligible[[x]], eligible[[y]], method = "spearman", exact = FALSE)$p.value
  ) |>
  ungroup() |>
  mutate(FDR = p.adjust(p, method = "BH"))

stats_ssc <- tests |>
  rowwise() |>
  mutate(
    n = sum(complete.cases(eligible[[x]][eligible$disease_group == "SSc"],
                           eligible[[y]][eligible$disease_group == "SSc"])),
    rho = cor(eligible[[x]][eligible$disease_group == "SSc"],
              eligible[[y]][eligible$disease_group == "SSc"],
              method = "spearman", use = "complete.obs"),
    p = cor.test(eligible[[x]][eligible$disease_group == "SSc"],
                 eligible[[y]][eligible$disease_group == "SSc"],
                 method = "spearman", exact = FALSE)$p.value
  ) |>
  ungroup() |>
  mutate(FDR = p.adjust(p, method = "BH"))

write_csv(patient, "outputs/Figure3F_patient_axis_all_patients.csv")
write_csv(eligible, "outputs/Figure3F_patient_axis_eligible_patients.csv")
write_csv(stats, "outputs/Figure3F_patient_axis_statistics_all.csv")
write_csv(stats_ssc, "outputs/Figure3F_patient_axis_statistics_SSc.csv")

print(stats)
print(stats_ssc)
