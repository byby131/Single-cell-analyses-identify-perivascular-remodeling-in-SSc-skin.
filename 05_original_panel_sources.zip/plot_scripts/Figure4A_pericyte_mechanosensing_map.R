suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(patchwork)
  library(scales)
})

input_rds <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_ECM_high_vs_low_analysis/Peri_RGS5_ECM_state_seurat.rds"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

obj <- readRDS(input_rds)
um <- as.data.frame(Embeddings(obj, "umap"))
colnames(um)[1:2] <- c("UMAP_1", "UMAP_2")
um$ECM_state <- factor(obj$ECM_state, levels = c("ECM-low", "ECM-high"))
um$Mechanosensing <- obj$Mechanosensing_Core1

q <- quantile(um$Mechanosensing, c(0.02, 0.98), na.rm = TRUE)

theme_umap <- theme_void(base_size = 8.2, base_family = "Arial") +
  theme(
    plot.title = element_text(size = 9.2, face = "bold", hjust = 0, margin = margin(b = 3, l = 12)),
    legend.title = element_text(size = 7.4, face = "bold"),
    legend.text = element_text(size = 7),
    legend.key.height = unit(3.2, "mm"),
    legend.key.width = unit(3.2, "mm"),
    plot.margin = margin(3, 3, 3, 3)
  )

p_state <- ggplot(um, aes(UMAP_1, UMAP_2, colour = ECM_state)) +
  geom_point(size = 0.72, alpha = 0.88, stroke = 0) +
  scale_colour_manual(
    values = c("ECM-low" = "#1A8FB4", "ECM-high" = "#CB282A"),
    name = "Pericyte state"
  ) +
  labs(title = "ECM state") +
  guides(colour = guide_legend(override.aes = list(size = 2.6, alpha = 1))) +
  theme_umap

p_mech <- ggplot(um, aes(UMAP_1, UMAP_2, colour = Mechanosensing)) +
  geom_point(size = 0.72, alpha = 0.9, stroke = 0) +
  scale_colour_gradientn(
    colours = c("#E8EDF0", "#F3C88E", "#F47E21", "#8F2D20"),
    limits = q,
    oob = squish,
    name = "Mechanosensing\nscore"
  ) +
  labs(title = "Mechanosensing program") +
  theme_umap

fig <- p_state + p_mech +
  plot_layout(widths = c(1, 1)) +
  plot_annotation(
    theme = theme(
      plot.margin = margin(2, 2, 2, 2)
    )
  )

ggsave(file.path(out_dir, "Figure4A_ECM_state_mechanosensing_UMAP.svg"), fig,
       width = 178, height = 72, units = "mm", bg = "white")
ggsave(file.path(out_dir, "Figure4A_ECM_state_mechanosensing_UMAP.pdf"), fig,
       width = 178, height = 72, units = "mm", bg = "white", device = cairo_pdf)
ggsave(file.path(out_dir, "Figure4A_ECM_state_mechanosensing_UMAP.png"), fig,
       width = 178, height = 72, units = "mm", dpi = 400, bg = "white")

write.csv(
  data.frame(
    cell = rownames(um),
    UMAP_1 = um$UMAP_1,
    UMAP_2 = um$UMAP_2,
    ECM_state = um$ECM_state,
    Mechanosensing = um$Mechanosensing
  ),
  file.path(out_dir, "Figure4A_source_data.csv"),
  row.names = FALSE
)
