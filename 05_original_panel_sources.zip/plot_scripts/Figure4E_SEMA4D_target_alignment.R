suppressPackageStartupMessages({
  library(ggplot2)
  library(svglite)
  library(ragg)
})

target_csv <- "/Users/baoying/Desktop/巨噬细胞/NicheNet_expression_gated_final/Top20_ligand_target_links.csv"
marker_csv <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_ECM_high_vs_low_analysis/Markers_Peri_RGS5_ECM_high_vs_low_all.csv"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

targets <- read.csv(target_csv, check.names = FALSE)
targets <- targets[targets$ligand == "SEMA4D", c("target", "weight")]
markers <- read.csv(marker_csv, check.names = FALSE)
markers <- markers[, c("gene", "avg_log2FC", "p_val_adj", "pct.1", "pct.2")]

d <- merge(targets, markers, by.x = "target", by.y = "gene", all.x = TRUE, sort = FALSE)
d$direction <- ifelse(d$avg_log2FC > 0, "ECM-high", "ECM-low")
d$aligned <- d$avg_log2FC > 0.25 & d$p_val_adj < 0.05
d$target <- factor(d$target, levels = d$target[order(d$avg_log2FC)])

n_aligned <- sum(d$aligned, na.rm = TRUE)
subtitle_text <- sprintf("%d of %d predicted targets align with the ECM-high program", n_aligned, nrow(d))

p <- ggplot(d, aes(avg_log2FC, target)) +
  geom_vline(xintercept = 0, colour = "#8F8F8F", linewidth = 0.45, linetype = 2) +
  geom_segment(aes(x = 0, xend = avg_log2FC, yend = target, colour = direction),
               linewidth = 0.8, alpha = 0.78) +
  geom_point(aes(size = weight, fill = direction), shape = 21,
             colour = "white", stroke = 0.45) +
  scale_colour_manual(values = c("ECM-high" = "#CB282A", "ECM-low" = "#1A8FB4"), guide = "none") +
  scale_fill_manual(values = c("ECM-high" = "#CB282A", "ECM-low" = "#1A8FB4"), name = "Target direction") +
  scale_size_continuous(name = "NicheNet weight", range = c(2.7, 5.5), breaks = c(0.005, 0.006, 0.007, 0.008)) +
  scale_x_continuous(expand = expansion(mult = c(0.08, 0.12))) +
  labs(
    title = "SEMA4D target-program alignment",
    subtitle = subtitle_text,
    x = "ECM-high vs ECM-low log2 fold change",
    y = NULL
  ) +
  theme_classic(base_size = 8.5, base_family = "sans") +
  theme(
    axis.line.y = element_blank(),
    axis.line.x = element_line(linewidth = 0.45, colour = "black"),
    axis.ticks.y = element_blank(),
    axis.text.y = element_text(size = 8, face = "italic", colour = "black", margin = margin(r = 4)),
    axis.text.x = element_text(size = 7.3, colour = "black"),
    axis.title.x = element_text(size = 8, colour = "black", margin = margin(t = 5)),
    plot.title = element_text(size = 9.6, face = "bold", hjust = 0, margin = margin(b = 1)),
    plot.subtitle = element_text(size = 7.6, colour = "#555555", hjust = 0, margin = margin(b = 6)),
    legend.position = "right",
    legend.title = element_text(size = 7.2, face = "bold"),
    legend.text = element_text(size = 6.8),
    plot.margin = margin(6, 6, 5, 6)
  ) +
  guides(
    fill = guide_legend(order = 1, override.aes = list(size = 3.2)),
    size = guide_legend(order = 2, override.aes = list(shape = 21, fill = "#777777", colour = "white"))
  )

width_mm = 100
height_mm = 82

ggsave(file.path(out_dir, "Figure4E_SEMA4D_target_alignment.svg"), p,
       width = width_mm, height = height_mm, units = "mm", bg = "white",
       device = svglite::svglite)
ggsave(file.path(out_dir, "Figure4E_SEMA4D_target_alignment.pdf"), p,
       width = width_mm, height = height_mm, units = "mm", bg = "white",
       device = grDevices::pdf)
ggsave(file.path(out_dir, "Figure4E_SEMA4D_target_alignment.png"), p,
       width = width_mm, height = height_mm, units = "mm", dpi = 400, bg = "white")
ggsave(file.path(out_dir, "Figure4E_SEMA4D_target_alignment.tiff"), p,
       width = width_mm, height = height_mm, units = "mm", dpi = 600,
       bg = "white", device = ragg::agg_tiff, compression = "lzw")

write.csv(d, file.path(out_dir, "Figure4E_source_data.csv"), row.names = FALSE)
writeLines(
  c(
    "Descriptive alignment panel linking NicheNet-predicted SEMA4D targets to the ECM-high versus ECM-low differential program.",
    "Red #CB282A denotes ECM-high direction; blue #1A8FB4 denotes ECM-low direction.",
    "Dot size denotes NicheNet regulatory-potential weight.",
    "Aligned was defined as adjusted P < 0.05 and log2 fold change > 0.25 in the receiver-state comparison.",
    "No enrichment P value is claimed because receiver differential expression contributed to the upstream NicheNet target-selection workflow; the panel is not an independent validation."
  ),
  file.path(out_dir, "Figure4E_QA_notes.txt")
)
