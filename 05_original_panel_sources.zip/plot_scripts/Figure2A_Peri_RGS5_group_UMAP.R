suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(svglite)
  library(ragg)
})

input_rds <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_Ctrl_SSc_ECM_figures/peri_all_Ctrl_SSc_ECM_state_processed.rds"
out_base <- "outputs/Figure2A_Peri_RGS5_Ctrl_SSc_shared_UMAP"
width_mm <- 126
height_mm <- 65

obj <- readRDS(input_rds)
stopifnot("umap" %in% names(obj@reductions), "disease_group" %in% colnames(obj[[]]))
um <- as.data.frame(Embeddings(obj, "umap"))
colnames(um)[1:2] <- c("UMAP_1", "UMAP_2")
um$cell_id <- rownames(um)
um$disease_group <- factor(obj[[]][rownames(um), "disease_group"], levels=c("Ctrl","SSc"))
um$patient_id <- obj[[]][rownames(um), "patient_id"]

counts <- table(um$disease_group)
facet_names <- c(Ctrl=paste0("Ctrl (", format(counts[["Ctrl"]], big.mark=","), " cells)"),
                 SSc=paste0("SSc (", format(counts[["SSc"]], big.mark=","), " cells)"))

# Repeat the complete manifold as a quiet reference in both facets.
bg <- do.call(rbind, lapply(levels(um$disease_group), function(g) {
  z <- um[,c("UMAP_1","UMAP_2")]
  z$panel <- g
  z
}))
fg <- um
fg$panel <- as.character(fg$disease_group)
bg$panel <- factor(bg$panel, levels=c("Ctrl","SSc"), labels=unname(facet_names))
fg$panel <- factor(fg$panel, levels=c("Ctrl","SSc"), labels=unname(facet_names))

cols <- c("Ctrl"="#1A8FB4", "SSc"="#CB282A")
p <- ggplot() +
  geom_point(data=bg, aes(UMAP_1,UMAP_2), colour="#E3E3E3", size=0.24, alpha=0.65) +
  geom_point(data=fg, aes(UMAP_1,UMAP_2,colour=disease_group), size=0.34, alpha=0.82) +
  facet_wrap(~panel, nrow=1) +
  scale_colour_manual(values=cols) +
  coord_equal() +
  labs(x="UMAP 1", y="UMAP 2") +
  theme_classic(base_size=7, base_family="Helvetica") +
  theme(
    strip.background=element_blank(), strip.text=element_text(size=8,face="bold",margin=margin(b=3)),
    axis.title=element_text(size=6.6), axis.text=element_blank(), axis.ticks=element_blank(),
    axis.line=element_line(linewidth=0.35), legend.position="none",
    panel.spacing=grid::unit(7,"mm"), plot.margin=margin(4,4,3,4)
  )

svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                 system_fonts=list(sans="Arial"), pointsize=7)
print(p); dev.off()

pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
    family="Helvetica", pointsize=7, useDingbats=FALSE)
print(p); dev.off()

ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
               units="in", res=600, compression="lzw", background="white")
print(p); dev.off()

ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
              units="in", res=300, background="white")
print(p); dev.off()

write.csv(um, paste0(out_base,"_source_data.csv"), row.names=FALSE)
