suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(svglite)
  library(ragg)
})

input_rds <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_Ctrl_SSc_ECM_figures/peri_all_Ctrl_SSc_ECM_state_processed.rds"
out_base <- "outputs/Figure2D_Peri_RGS5_ECM_state_marker_dotplot_Cell_palette_v3"
width_mm <- 145
height_mm <- 55
genes <- c("MYH11", "ACTA2", "TAGLN", "PLN",
           "COL1A1", "COL1A2", "COL3A1", "POSTN", "SPARC", "THY1",
           "RGS5", "PDGFRB")

obj <- readRDS(input_rds)
missing_genes <- setdiff(genes, rownames(obj))
if (length(missing_genes) > 0) stop("Missing genes: ", paste(missing_genes, collapse=", "))
stopifnot("ECM_state" %in% colnames(obj[[]]))
obj$ECM_state <- factor(obj$ECM_state, levels=c("ECM-low", "ECM-high"))

dp <- DotPlot(obj, features=genes, group.by="ECM_state", scale=TRUE,
              col.min=-2, col.max=2, dot.min=0)$data
dp$state <- factor(as.character(dp$id), levels=c("ECM-high", "ECM-low"))
dp$gene <- factor(as.character(dp$features.plot), levels=genes)
dp$gene_group <- ifelse(as.character(dp$gene) %in% genes[1:4], "Contractile",
                        ifelse(as.character(dp$gene) %in% genes[5:10], "ECM remodeling",
                               "Pericyte\nidentity"))
dp$gene_group <- factor(dp$gene_group,
                        levels=c("Contractile", "ECM remodeling", "Pericyte\nidentity"))
dp$expression_direction <- factor(ifelse(dp$avg.exp.scaled >= 0, "Higher", "Lower"),
                                  levels=c("Higher", "Lower"))

p <- ggplot(dp, aes(gene, state)) +
  geom_point(aes(size=pct.exp, colour=expression_direction), alpha=1) +
  facet_grid(cols=vars(gene_group), scales="free_x", space="free_x") +
  scale_size_continuous(name="Cells expressing (%)", range=c(0.5,5.4),
                        limits=c(0,100), breaks=c(25,50,75,100)) +
  scale_colour_manual(name="Relative average\nexpression",
                      values=c("Higher"="#CB282A", "Lower"="#1A8FB4")) +
  labs(x=NULL, y=NULL) +
  theme_classic(base_size=7, base_family="Helvetica") +
  theme(
    axis.line=element_blank(), axis.ticks=element_blank(),
    axis.text.x=element_text(angle=45, hjust=1, vjust=1, size=6.5,
                             face="italic", colour="#222222"),
    axis.text.y=element_text(size=7, face="bold", colour="#222222"),
    strip.background=element_rect(fill="#EEE8F2", colour=NA),
    strip.text=element_text(size=6.7, face="bold", lineheight=0.9,
                            margin=margin(2.5,2,2.5,2)),
    panel.grid.major=element_line(colour="#E7E7E7", linewidth=0.28),
    panel.grid.minor=element_blank(), panel.spacing=grid::unit(2,"mm"),
    legend.position="right", legend.title=element_text(size=6.1),
    legend.text=element_text(size=5.7),
    legend.key.height=grid::unit(3,"mm"), plot.margin=margin(6,3,3,3)
  ) +
  guides(size=guide_legend(order=1, override.aes=list(colour="#777777")),
         colour=guide_legend(order=2, override.aes=list(size=2.8, alpha=1)))

svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                 system_fonts=list(sans="Arial"), pointsize=7)
print(p); dev.off()
pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
    family="Helvetica", pointsize=7, useDingbats=FALSE)
print(p); dev.off()
ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
               units="in", res=600, compression="lzw", background="white")
print(p); dev.off()
ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
              units="in", res=300, background="white")
print(p); dev.off()
write.csv(dp, paste0(out_base,"_source_data.csv"), row.names=FALSE)
