suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(tidyr)
  library(svglite)
})

src <- "/Users/baoying/Documents/Codex/2026-07-31/wos/work/Dual_enriched_ligand_receptor_pairs.csv"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"

x <- read_csv(src, show_col_types = FALSE) %>%
  filter(ligand == "SEMA4D", receptor == "PLXNB2") %>%
  slice(1)

plot_dat <- bind_rows(
  tibble(
    molecule = "SEMA4D",
    compartment = "Sender: myeloid",
    state = c("M_CD16_IL1B", "M_IL1B", "Other myeloid"),
    pct = c(x$pct_expressed_M_CD16_IL1B, x$pct_expressed_M_IL1B, x$pct_expressed_Other_myeloid),
    avg = c(x$avg_log_expression_M_CD16_IL1B, x$avg_log_expression_M_IL1B, x$avg_log_expression_Other_myeloid)
  ),
  tibble(
    molecule = "PLXNB2",
    compartment = "Receiver: Peri_RGS5",
    state = c("ECM-high", "ECM-low"),
    pct = c(x$pct_expressed_ECM_high, x$pct_expressed_ECM_low),
    avg = c(x$avg_log_expression_ECM_high, x$avg_log_expression_ECM_low)
  )
) %>%
  mutate(
    state = factor(state, levels = rev(c("M_CD16_IL1B", "M_IL1B", "Other myeloid",
                                        "ECM-high", "ECM-low"))),
    compartment = factor(compartment, levels = c("Sender: myeloid", "Receiver: Peri_RGS5")),
    panel = factor(paste0(compartment, "    ", molecule),
                   levels = c("Sender: myeloid    SEMA4D", "Receiver: Peri_RGS5    PLXNB2")),
    pct_label = sprintf("%.1f%%", 100 * pct)
  )

write_csv(plot_dat %>% mutate(state = as.character(state), compartment = as.character(compartment)),
          file.path(out_dir, "Figure3C_source_data.csv"))

p <- ggplot(plot_dat, aes(x = 1, y = state)) +
  geom_point(aes(size = pct, colour = avg), alpha = 0.95) +
  geom_text(aes(label = pct_label), nudge_x = 0.24, hjust = 0,
            size = 2.8, colour = "#333333") +
  facet_wrap(~panel, ncol = 1, scales = "free_y") +
  scale_size_continuous(range = c(3.3, 9.0), limits = c(0, 0.12),
                        breaks = c(0.04, 0.08, 0.12),
                        labels = scales::label_percent(accuracy = 1),
                        name = "Cells expressing") +
  scale_colour_gradientn(colours = c("#D9DEE0", "#F29979", "#CB282A"),
                         limits = c(0, max(plot_dat$avg) * 1.02),
                         name = "Average log\nexpression") +
  scale_x_continuous(limits = c(0.82, 1.38), breaks = NULL) +
  labs(x = NULL, y = NULL) +
  theme_classic(base_size = 10, base_family = "sans") +
  theme(
    axis.text.x = element_blank(),
    axis.text.y = element_text(size = 8.7, colour = "#202124"),
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    strip.background = element_rect(fill = "#F1F3F3", colour = NA),
    strip.text = element_text(size = 8.8, face = "bold", colour = "#202124",
                              hjust = 0.03, margin = margin(4, 4, 4, 4)),
    panel.grid.major.y = element_line(colour = "#E8EBEC", linewidth = 0.4),
    legend.position = "right",
    legend.box = "vertical",
    legend.title = element_text(size = 8),
    legend.text = element_text(size = 7.5),
    plot.margin = margin(7, 10, 6, 8)
  )

ggsave(file.path(out_dir, "Figure3C_SEMA4D_PLXNB2_expression_gate.svg"), p,
       width = 4.7, height = 3.55, units = "in", bg = "white")
ggsave(file.path(out_dir, "Figure3C_SEMA4D_PLXNB2_expression_gate.pdf"), p,
       width = 4.7, height = 3.55, units = "in", device = "pdf", bg = "white")
ggsave(file.path(out_dir, "Figure3C_SEMA4D_PLXNB2_expression_gate.png"), p,
       width = 4.7, height = 3.55, units = "in", dpi = 320, bg = "white")
ggsave(file.path(out_dir, "Figure3C_SEMA4D_PLXNB2_expression_gate.tiff"), p,
       width = 4.7, height = 3.55, units = "in", dpi = 600,
       compression = "lzw", bg = "white")
