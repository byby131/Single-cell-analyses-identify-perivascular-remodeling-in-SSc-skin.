suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(svglite)
  library(ragg)
})

input_rds <- "/Users/baoying/Desktop/巨噬细胞/Candidate_axis_competition_Peri_RGS5/sce_skin_with_candidate_axis_scores.rds"
out_base <- "outputs/Figure1C_M_IL1B_Peri_RGS5_marker_dotplot"
width_mm <- 150
height_mm <- 88

obj <- readRDS(input_rds)
groups <- c("M_IL1B", "M_CD16_IL1B", "Mf", "Mf_TREM2",
            "Peri_RGS5", "Peri_TGFBI", "Vascular_RBP7", "Vascular_ACKR1",
            "Fibro_LGR5", "Fibro_POSTN")
genes <- c("LST1", "IL1B", "S100A8", "S100A9", "FCGR3A",
           "RGS5", "PDGFRB", "CSPG4", "MCAM", "NOTCH3",
           "PECAM1", "COL1A1")

missing_genes <- setdiff(genes, rownames(obj))
if (length(missing_genes) > 0) stop("Missing genes: ", paste(missing_genes, collapse=", "))
missing_groups <- setdiff(groups, unique(as.character(obj[[]][["annotation"]])))
if (length(missing_groups) > 0) stop("Missing annotations: ", paste(missing_groups, collapse=", "))

Idents(obj) <- "annotation"
sub <- subset(obj, idents=groups)
dp <- DotPlot(sub, features=genes, group.by="annotation", scale=TRUE,
              col.min=-2, col.max=2, dot.min=0)$data

display_names <- c(
  "M_IL1B"="M_IL1B", "M_CD16_IL1B"="M_CD16_IL1B", "Mf"="Macrophages",
  "Mf_TREM2"="TREM2+ macrophages", "Peri_RGS5"="RGS5+ pericytes",
  "Peri_TGFBI"="TGFBI+ pericytes", "Vascular_RBP7"="RBP7+ endothelial",
  "Vascular_ACKR1"="ACKR1+ endothelial", "Fibro_LGR5"="LGR5+ fibroblasts",
  "Fibro_POSTN"="POSTN+ fibroblasts"
)

dp$cell_type <- unname(display_names[as.character(dp$id)])
dp$cell_type <- factor(dp$cell_type, levels=rev(unname(display_names[groups])))
dp$gene <- factor(as.character(dp$features.plot), levels=genes)
dp$gene_group <- ifelse(as.character(dp$gene) %in% genes[1:5], "Inflammatory myeloid",
                        ifelse(as.character(dp$gene) %in% genes[6:10], "Pericyte identity",
                               "Controls"))
dp$gene_group <- factor(dp$gene_group,
                        levels=c("Inflammatory myeloid", "Pericyte identity", "Controls"))
dp$avg.exp.scaled <- pmax(pmin(dp$avg.exp.scaled, 2), -2)

p <- ggplot(dp, aes(gene, cell_type)) +
  geom_point(aes(size=pct.exp, colour=avg.exp.scaled), alpha=0.95) +
  facet_grid(cols=vars(gene_group), scales="free_x", space="free_x") +
  scale_size_continuous(name="Cells expressing (%)", range=c(0.25,4.2),
                        limits=c(0,100), breaks=c(25,50,75,100)) +
  scale_colour_gradient2(name="Scaled average\nexpression", low="#486F8C",
                         mid="#F4F2F0", high="#B84F59", midpoint=0,
                         limits=c(-2,2), breaks=c(-2,-1,0,1,2)) +
  labs(x=NULL, y=NULL) +
  theme_classic(base_size=7, base_family="Helvetica") +
  theme(
    axis.line=element_blank(), axis.ticks=element_blank(),
    axis.text.x=element_text(angle=45, hjust=1, vjust=1, size=6.6,
                             face="italic", colour="#222222"),
    axis.text.y=element_text(size=6.7, colour="#222222"),
    strip.background=element_rect(fill="#EEE8F2", colour=NA),
    strip.text=element_text(size=7, face="bold", margin=margin(3,3,3,3)),
    panel.grid.major=element_line(colour="#E7E7E7", linewidth=0.28),
    panel.grid.minor=element_blank(), panel.spacing=grid::unit(1.8,"mm"),
    legend.position="right", legend.title=element_text(size=6.2),
    legend.text=element_text(size=5.8),
    legend.key.height=grid::unit(3.1,"mm"),
    plot.margin=margin(4,4,3,4)
  ) +
  guides(size=guide_legend(order=1, override.aes=list(colour="#777777")),
         colour=guide_colourbar(order=2, barheight=grid::unit(18,"mm"),
                                barwidth=grid::unit(3,"mm")))

svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                 system_fonts=list(sans="Arial"), pointsize=7)
print(p); dev.off()

pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
    family="Helvetica", pointsize=7, useDingbats=FALSE)
print(p); dev.off()

ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
               units="in", res=600, compression="lzw", background="white")
print(p); dev.off()

ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
              units="in", res=300, background="white")
print(p); dev.off()

write.csv(dp, paste0(out_base,"_source_data.csv"), row.names=FALSE)
