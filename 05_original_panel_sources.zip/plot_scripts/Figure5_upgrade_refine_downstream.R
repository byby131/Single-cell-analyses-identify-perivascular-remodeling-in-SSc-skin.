suppressPackageStartupMessages({
  library(Seurat); library(dplyr); library(tidyr); library(readr)
  library(Matrix); library(edgeR); library(fgsea); library(msigdbr)
})
set.seed(20260802)
pv_all <- readRDS("work/GSE138669_perivascular_reclustered.rds")
myeloid <- readRDS("work/GSE138669_myeloid_reclustered.rds")
pv <- subset(pv_all, subset = seurat_clusters != "8")
saveRDS(pv, "work/GSE138669_perivascular_reclustered_clean.rds", compress = FALSE)
myeloid_clean <- subset(myeloid, subset = !(seurat_clusters %in% c("2", "8")))
saveRDS(myeloid_clean, "work/GSE138669_myeloid_reclustered_clean.rds", compress = FALSE)

exclusion <- tibble(
  object = "external perivascular reclustering",
  before_cells = ncol(pv_all), after_cells = ncol(pv), excluded_cells = ncol(pv_all) - ncol(pv),
  rule = "exclude reclustered cluster 8",
  reason = "keratinocyte-like contaminant: KRT5/KRT14/COL17A1-high",
  excluded_fraction_pct = (ncol(pv_all) - ncol(pv)) / ncol(pv_all) * 100
)
write_csv(exclusion, "outputs/Figure5_upgrade_perivascular_exclusion_log.csv")
write_csv(tibble(
  object = "external myeloid reclustering", before_cells = ncol(myeloid),
  after_cells = ncol(myeloid_clean), excluded_cells = ncol(myeloid) - ncol(myeloid_clean),
  rule = "exclude reclustered clusters 2 and 8",
  reason = "cluster 2 low-complexity (median 307 genes); cluster 8 keratinocyte-like/doublet (KRT14/COL1A1-high)",
  excluded_fraction_pct = (ncol(myeloid) - ncol(myeloid_clean)) / ncol(myeloid) * 100
), "outputs/Figure5_upgrade_myeloid_exclusion_log.csv")

sample_meta <- read_csv("work/GSE138669_sample_metadata.csv", show_col_types = FALSE)
pv_counts <- AggregateExpression(pv, assays = "RNA", group.by = "gsm", slot = "counts",
                                 return.seurat = FALSE)$RNA
sample_meta <- sample_meta |> filter(gsm %in% colnames(pv_counts)) |>
  arrange(match(gsm, colnames(pv_counts)))
sample_meta$disease_group <- factor(sample_meta$disease_group, levels = c("Ctrl", "SSc"))
sample_meta$chemistry <- factor(sample_meta$chemistry, levels = c("V1", "V2"))
design <- model.matrix(~ chemistry + disease_group, data = sample_meta)
y <- DGEList(counts = pv_counts)
keep <- filterByExpr(y, design = design)
y <- calcNormFactors(y[keep, , keep.lib.sizes = FALSE])
y <- estimateDisp(y, design)
fit <- glmQLFit(y, design, robust = TRUE)
de <- topTags(glmQLFTest(fit, coef = "disease_groupSSc"), n = Inf, sort.by = "none")$table |>
  tibble::rownames_to_column("gene") |> arrange(FDR)
write_csv(de, "outputs/Figure5_upgrade_perivascular_pseudobulk_edgeR.csv")

msig <- bind_rows(
  msigdbr(species = "Homo sapiens", collection = "H"),
  msigdbr(species = "Homo sapiens", collection = "C2", subcollection = "CP:REACTOME"),
  msigdbr(species = "Homo sapiens", collection = "C5", subcollection = "GO:BP")
) |> filter(grepl("EXTRACELLULAR_MATRIX|COLLAGEN|TGF_BETA|TGF_B|MUSCLE_CONTRACTION|CELL_MATRIX|FIBROSIS|WOUND_HEALING", gs_name))
pathways <- split(msig$gene_symbol, msig$gs_name)
ranks <- sign(de$logFC) * sqrt(de$F)
names(ranks) <- de$gene
ranks <- sort(ranks[is.finite(ranks)], decreasing = TRUE)
gsea <- fgseaMultilevel(pathways, ranks, minSize = 10, maxSize = 500, eps = 0) |>
  as_tibble() |> arrange(padj, desc(abs(NES))) |>
  mutate(leadingEdge = vapply(leadingEdge, paste, collapse = ";", FUN.VALUE = character(1)))
write_csv(gsea, "outputs/Figure5_upgrade_perivascular_GSEA.csv")

target_genes <- intersect(c("IGFBP4", "EPAS1", "MGP", "IFI27", "LGALS1", "SERPINF1",
                            "IGFBP7", "ACTB", "APOE", "CLIC1"), rownames(pv))
pv_expr <- GetAssayData(pv, assay = "RNA", layer = "data")
my_expr <- GetAssayData(myeloid_clean, assay = "RNA", layer = "data")
target_patient <- tibble(gsm = pv$gsm,
                         target_score = Matrix::colMeans(pv_expr[target_genes, , drop = FALSE])) |>
  group_by(gsm) |> summarise(perivascular_target_score = mean(target_score), .groups = "drop")
sender_patient <- tibble(gsm = myeloid_clean$gsm, SEMA4D = as.numeric(my_expr["SEMA4D", ])) |>
  group_by(gsm) |> summarise(myeloid_SEMA4D_mean = mean(SEMA4D),
                             myeloid_SEMA4D_pct = mean(SEMA4D > 0) * 100, .groups = "drop")
coupling <- sample_meta |> left_join(sender_patient, by = "gsm") |> left_join(target_patient, by = "gsm")
fit_target <- lm(perivascular_target_score ~ myeloid_SEMA4D_pct + disease_group + chemistry, data = coupling)
coef_target <- coef(summary(fit_target))["myeloid_SEMA4D_pct", ]
cor_target <- cor.test(coupling$myeloid_SEMA4D_pct, coupling$perivascular_target_score,
                       method = "spearman", exact = FALSE)
write_csv(coupling, "outputs/Figure5_upgrade_patient_ligand_target_coupling.csv")
write_csv(tibble(term = "myeloid_SEMA4D_pct", estimate = coef_target[["Estimate"]],
                 std_error = coef_target[["Std. Error"]], p = coef_target[["Pr(>|t|)"]],
                 spearman_rho = unname(cor_target$estimate), spearman_p = cor_target$p.value),
          "outputs/Figure5_upgrade_patient_ligand_target_statistics.csv")
message("Refinement complete: ", ncol(pv_all), " -> ", ncol(pv), " perivascular cells; ",
        nrow(de), " genes; ", nrow(gsea), " pathways.")
