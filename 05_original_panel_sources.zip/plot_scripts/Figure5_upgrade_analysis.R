suppressPackageStartupMessages({
  library(Seurat)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(Matrix)
  library(edgeR)
  library(fgsea)
  library(msigdbr)
})

set.seed(20260802)
dir.create("outputs", showWarnings = FALSE, recursive = TRUE)
obj <- readRDS("work/GSE138669_annotated_focus.rds")
if (length(Layers(obj[["RNA"]])) > 1) obj[["RNA"]] <- JoinLayers(obj[["RNA"]])
metadata_master <- read_csv("work/GSE138669_sample_metadata.csv", show_col_types = FALSE)
obj$chemistry <- unname(setNames(metadata_master$chemistry, metadata_master$gsm)[obj$gsm])
stopifnot(!anyNA(obj$chemistry))

recluster_compartment <- function(object, compartment, resolution = 0.4) {
  cells <- rownames(object@meta.data)[object$focus_compartment == compartment]
  x <- subset(object, cells = cells)
  DefaultAssay(x) <- "RNA"
  x$chemistry_numeric <- ifelse(x$chemistry == "V2", 1, 0)
  x <- NormalizeData(x, verbose = FALSE)
  x <- FindVariableFeatures(x, nfeatures = 2500, verbose = FALSE)
  x <- ScaleData(x, vars.to.regress = "chemistry_numeric", verbose = FALSE)
  x <- RunPCA(x, npcs = 30, verbose = FALSE)
  x <- FindNeighbors(x, dims = 1:20, verbose = FALSE)
  x <- FindClusters(x, resolution = resolution, random.seed = 20260802, verbose = FALSE)
  x <- RunUMAP(x, dims = 1:20, seed.use = 20260802, verbose = FALSE)
  x
}

myeloid <- recluster_compartment(obj, "Myeloid", resolution = 0.45)
perivascular <- recluster_compartment(obj, "Perivascular", resolution = 0.40)
saveRDS(myeloid, "work/GSE138669_myeloid_reclustered.rds", compress = FALSE)
saveRDS(perivascular, "work/GSE138669_perivascular_reclustered.rds", compress = FALSE)

markers_for <- function(x, label) {
  Idents(x) <- "seurat_clusters"
  m <- FindAllMarkers(x, only.pos = TRUE, min.pct = 0.10, logfc.threshold = 0.20,
                      test.use = "wilcox", verbose = FALSE)
  write_csv(m, paste0("outputs/Figure5_upgrade_", label, "_all_markers.csv"))
  m |> group_by(cluster) |> slice_max(avg_log2FC, n = 12, with_ties = FALSE) |> ungroup()
}
my_top <- markers_for(myeloid, "myeloid")
pv_top <- markers_for(perivascular, "perivascular")
write_csv(my_top, "outputs/Figure5_upgrade_myeloid_top_markers.csv")
write_csv(pv_top, "outputs/Figure5_upgrade_perivascular_top_markers.csv")

# Cluster 8 is a small keratinocyte-like contaminant (KRT5/KRT14/COL17A1;
# 41/7,081 cells). Exclude it from perivascular inference, while retaining the
# unmodified object and recording the rule in source data/QA.
perivascular_clean <- subset(perivascular, subset = seurat_clusters != "8")
saveRDS(perivascular_clean, "work/GSE138669_perivascular_reclustered_clean.rds", compress = FALSE)
# Patient-level pseudobulk differential expression in identity-confirmed perivascular cells.
pv_counts <- AggregateExpression(perivascular_clean, assays = "RNA", group.by = "gsm",
                                 slot = "counts", return.seurat = FALSE)$RNA
sample_meta <- read_csv("work/GSE138669_sample_metadata.csv", show_col_types = FALSE) |>
  filter(gsm %in% colnames(pv_counts)) |>
  arrange(match(gsm, colnames(pv_counts)))
stopifnot(identical(sample_meta$gsm, colnames(pv_counts)))
sample_meta$disease_group <- factor(sample_meta$disease_group, levels = c("Ctrl", "SSc"))
sample_meta$chemistry <- factor(sample_meta$chemistry, levels = c("V1", "V2"))
design <- model.matrix(~ chemistry + disease_group, data = sample_meta)
y <- DGEList(counts = pv_counts)
keep <- filterByExpr(y, design = design)
y <- y[keep, , keep.lib.sizes = FALSE]
y <- calcNormFactors(y)
y <- estimateDisp(y, design)
fit <- glmQLFit(y, design, robust = TRUE)
qlf <- glmQLFTest(fit, coef = "disease_groupSSc")
de <- topTags(qlf, n = Inf, sort.by = "none")$table |>
  tibble::rownames_to_column("gene") |>
  arrange(FDR)
write_csv(de, "outputs/Figure5_upgrade_perivascular_pseudobulk_edgeR.csv")
write_csv(sample_meta, "outputs/Figure5_upgrade_pseudobulk_sample_metadata.csv")

# Curated public pathway collections; rankings use the chemistry-adjusted edgeR statistic.
msig <- bind_rows(
  msigdbr(species = "Homo sapiens", collection = "H"),
  msigdbr(species = "Homo sapiens", collection = "C2", subcollection = "CP:REACTOME"),
  msigdbr(species = "Homo sapiens", collection = "C5", subcollection = "GO:BP")
) |>
  filter(grepl("EXTRACELLULAR_MATRIX|COLLAGEN|TGF_BETA|TGF_B|MUSCLE_CONTRACTION|CELL_MATRIX|FIBROSIS|WOUND_HEALING",
               gs_name))
pathways <- split(msig$gene_symbol, msig$gs_name)
ranks <- sign(de$logFC) * sqrt(de$F)
names(ranks) <- de$gene
ranks <- sort(ranks[is.finite(ranks)], decreasing = TRUE)
gsea <- fgseaMultilevel(pathways = pathways, stats = ranks, minSize = 10, maxSize = 500,
                        eps = 0) |>
  as_tibble() |>
  arrange(padj, desc(abs(NES))) |>
  mutate(leadingEdge = vapply(leadingEdge, paste, collapse = ";", FUN.VALUE = character(1)))
write_csv(gsea, "outputs/Figure5_upgrade_perivascular_GSEA.csv")

# Independent-cohort reconstruction of the previously predicted SEMA4D target program.
target_genes <- intersect(c("IGFBP4", "EPAS1", "MGP", "IFI27", "LGALS1",
                            "SERPINF1", "IGFBP7", "ACTB", "APOE", "CLIC1"), rownames(obj))
pv_expr <- GetAssayData(perivascular_clean, assay = "RNA", layer = "data")
my_expr <- GetAssayData(myeloid, assay = "RNA", layer = "data")
pv_md <- perivascular_clean@meta.data
my_md <- myeloid@meta.data

target_patient <- tibble(gsm = pv_md$gsm,
                         target_score = Matrix::colMeans(pv_expr[target_genes, , drop = FALSE])) |>
  group_by(gsm) |>
  summarise(perivascular_target_score = mean(target_score), .groups = "drop")
sender_patient <- tibble(gsm = my_md$gsm,
                         SEMA4D = as.numeric(my_expr["SEMA4D", ])) |>
  group_by(gsm) |>
  summarise(myeloid_SEMA4D_mean = mean(SEMA4D),
            myeloid_SEMA4D_pct = mean(SEMA4D > 0) * 100, .groups = "drop")
coupling <- sample_meta |>
  left_join(sender_patient, by = "gsm") |>
  left_join(target_patient, by = "gsm")
fit_target <- lm(perivascular_target_score ~ myeloid_SEMA4D_pct + disease_group + chemistry,
                 data = coupling)
coef_target <- coef(summary(fit_target))["myeloid_SEMA4D_pct", ]
cor_target <- cor.test(coupling$myeloid_SEMA4D_pct, coupling$perivascular_target_score,
                       method = "spearman", exact = FALSE)
write_csv(coupling, "outputs/Figure5_upgrade_patient_ligand_target_coupling.csv")
write_csv(tibble(term = "myeloid_SEMA4D_pct", estimate = coef_target[["Estimate"]],
                 std_error = coef_target[["Std. Error"]], p = coef_target[["Pr(>|t|)"]],
                 spearman_rho = unname(cor_target$estimate), spearman_p = cor_target$p.value),
          "outputs/Figure5_upgrade_patient_ligand_target_statistics.csv")

message("Upgrade analysis complete: myeloid cells = ", ncol(myeloid),
        "; perivascular cells = ", ncol(perivascular),
        "; DE genes tested = ", nrow(de), "; pathways tested = ", nrow(gsea), ".")
