suppressPackageStartupMessages({
  library(ggplot2); library(dplyr); library(tidyr); library(readr)
  library(scales); library(patchwork); library(ggrepel)
})

# Claim: SEMA4D-PLXNB2 was prioritised as a focused, testable communication
# hypothesis after multi-evidence review, not because it was the top ligand by
# every computational metric.

ranked <- read_csv("outputs/Figure3A_source_data.csv", show_col_types=FALSE)
cand <- read_csv("outputs/Figure3B_candidate_summary_source_data.csv", show_col_types=FALSE)
mat <- read_csv("outputs/Figure3B_candidate_matrix_source_data.csv", show_col_types=FALSE)
gate <- read_csv("outputs/Figure3C_source_data.csv", show_col_types=FALSE)
targets <- read_csv("outputs/Figure3D_source_data.csv", show_col_types=FALSE)
myeloid <- read_csv("outputs/Figure3E_SEMA4D_myeloid_UMAP_source_data.csv", show_col_types=FALSE)
peri <- read_csv("outputs/Figure3E_PLXNB2_Peri_RGS5_UMAP_source_data.csv", show_col_types=FALSE)

red <- "#CB282A"; blue <- "#1A8FB4"; purple <- "#7B61A8"; orange <- "#F28E2B"
teal <- "#2A9D8F"; gold <- "#E9C46A"; coral <- "#E76F51"; magenta <- "#C84C83"
navy <- "#26384A"; grey <- "#D5DCE1"; light <- "#F4F6F7"
final_width_mm <- 183
metric_pal <- c("Ligand\nactivity"=orange,"Sender\nenrichment"=magenta,
                "Receiver\nenrichment"=teal,"Pair\nsupport"=gold,
                "Receptor\nspecificity"=purple)

theme_pub <- theme_classic(base_size=7.1,base_family="Helvetica") +
  theme(axis.line=element_line(linewidth=.34,colour=navy),
        axis.ticks=element_line(linewidth=.32,colour=navy),
        axis.text=element_text(size=6.1,colour=navy),
        axis.title=element_text(size=6.8,colour=navy),
        plot.title=element_text(size=8.2,face="bold",colour="#17212B"),
        plot.subtitle=element_text(size=6.2,colour="#65717C"),
        plot.tag=element_text(size=11,face="bold"),
        legend.title=element_text(size=6),legend.text=element_text(size=5.7),
        panel.grid=element_blank(),plot.margin=margin(3,4,3,3))
theme_set(theme_pub)

# A. Expression-gated NicheNet rank; semantic colour separates established
# biology from the candidate selected for validation.
ra <- ranked |> slice_head(n=15) |>
  mutate(ligand=factor(ligand,levels=rev(ligand)),
         status=case_when(ligand=="SEMA4D"~"Validation focus",
                          obvious_mature_axis~"Established axis",
                          ligand=="DCN"~"Top activity",
                          TRUE~"Other candidate"))
pA <- ggplot(ra,aes(aupr_corrected,ligand))+
  geom_segment(aes(x=0,xend=aupr_corrected,yend=ligand,colour=status),linewidth=.75,alpha=.72)+
  geom_point(aes(fill=status),shape=21,size=2.6,colour="white",stroke=.45)+
  scale_colour_manual(values=c(`Validation focus`=orange,`Established axis`=purple,
                               `Top activity`=teal,`Other candidate`="#AEBAC2"),guide="none")+
  scale_fill_manual(values=c(`Validation focus`=orange,`Established axis`=purple,
                             `Top activity`=teal,`Other candidate`="#AEBAC2"),name=NULL,
                    labels=c(`Validation focus`="Validation focus",`Established axis`="Established",
                             `Top activity`="Top activity",`Other candidate`="Other"),
                    guide=guide_legend(nrow=2,byrow=TRUE))+
  scale_x_continuous(expand=expansion(mult=c(0,.08)))+
  labs(title="Expression-gated ligand ranking",
       subtitle="SEMA4D ranks fourth by corrected AUPR",
       x="NicheNet ligand activity (corrected AUPR)",y=NULL)+
  theme(legend.position="bottom",axis.line.y=element_blank(),axis.ticks.y=element_blank())

# B. Evidence fingerprint. Scores are normalized within each evidence column,
# so they support comparison of candidates but not comparison across metrics.
mat$metric <- factor(mat$metric,levels=c("Ligand\nactivity","Sender\nenrichment",
                                        "Receiver\nenrichment","Pair\nsupport",
                                        "Receptor\nspecificity"))
mat$ligand <- factor(mat$ligand,levels=rev(c("DCN","TGFB1","TIMP2","SEMA4D")))
pB <- ggplot(mat,aes(metric,ligand))+
  annotate("rect",xmin=.5,xmax=5.5,ymin=.5,ymax=1.5,fill=alpha(orange,.10))+
  geom_tile(fill="#F0F3F4",colour="white",linewidth=.8)+
  geom_point(aes(size=score,fill=metric),shape=21,colour="white",stroke=.45,alpha=.96)+
  geom_text(aes(label=label),size=1.78,colour=navy)+
  scale_fill_manual(values=metric_pal,guide="none")+
  scale_size(range=c(2.5,8.8),limits=c(0,1),guide="none")+
  labs(title="Multi-evidence candidate fingerprint",
       subtitle="Circle area: within-column evidence; text: raw value",
       x=NULL,y=NULL)+
  theme(axis.text.x=element_text(size=5.5,face="bold"),axis.text.y=element_text(face="italic",size=6.4),
        axis.line=element_blank(),axis.ticks=element_blank())

# C. Decision funnel: a transparent selection narrative, not a new statistic.
funnel <- tibble(x=c(1,2.3,3.6),w=c(1.08,1.08,1.08),
                 label=c("15 expression-gated\nligands ranked",
                         "Top-4 candidates\nmulti-evidence audit",
                         "SEMA4D-PLXNB2\nfocused validation"),
                 sub=c("activity + receptor availability","activity | sender | receiver | pair | specificity",
                       "single mapped receptor; non-established axis"),
                 fill=c(teal,purple,orange))
pC <- ggplot(funnel)+
  geom_segment(data=slice_head(funnel,n=2),aes(x=x+.57,xend=x+.72,y=0,yend=0),
               arrow=arrow(length=grid::unit(2,"mm")),
               linewidth=.45,colour=navy)+
  geom_rect(aes(xmin=x-w/2,xmax=x+w/2,ymin=-.33,ymax=.33,fill=fill),
            colour="white",linewidth=.7)+
  geom_text(aes(x=x,y=.08,label=label),colour="white",fontface="bold",size=1.78,lineheight=.88)+
  geom_text(aes(x=x,y=-.49,label=stringr::str_wrap(sub,24)),colour="#5F6A72",size=1.42,lineheight=.86)+
  scale_fill_identity()+coord_cartesian(xlim=c(.35,4.25),ylim=c(-.78,.46),clip="off")+
  labs(title="Transparent prioritisation funnel",
       subtitle="Selection reflects focus and testability, not a claim of global dominance")+
  theme_void(base_family="Helvetica")+
  theme(plot.title=element_text(size=8.2,face="bold",colour="#17212B"),
        plot.subtitle=element_text(size=6.2,colour="#65717C"),plot.margin=margin(3,5,8,3))

# D. Expression feasibility in the prespecified sender and receiver states.
gate <- gate |> mutate(state=factor(state,levels=rev(c("M_CD16_IL1B","M_IL1B","Other myeloid","ECM-high","ECM-low"))),
                       axis=factor(ifelse(molecule=="SEMA4D","Sender: SEMA4D","Receiver: PLXNB2"),
                                   levels=c("Sender: SEMA4D","Receiver: PLXNB2")))
pD <- ggplot(gate,aes(avg,state))+
  geom_segment(aes(x=0,xend=avg,yend=state,colour=axis),linewidth=.65,alpha=.55)+
  geom_point(aes(size=pct,fill=axis),shape=21,colour="white",stroke=.5)+
  geom_text(aes(label=pct_label),hjust=-.35,size=1.9,colour=navy)+
  facet_wrap(~axis,ncol=1,scales="free_y")+
  scale_colour_manual(values=c(`Sender: SEMA4D`=magenta,`Receiver: PLXNB2`=teal),guide="none")+
  scale_fill_manual(values=c(`Sender: SEMA4D`=magenta,`Receiver: PLXNB2`=teal),guide="none")+
  scale_size(range=c(2.5,7),limits=c(0,.13),guide="none")+
  scale_x_continuous(expand=expansion(mult=c(0,.32)))+
  labs(title="Sender-receiver expression gate",
       subtitle="Point area denotes expressing-cell fraction",x="Average log expression",y=NULL)+
  theme(strip.text=element_text(size=6.2,face="bold",hjust=0),strip.background=element_rect(fill="#F0F3F4",colour=NA),
        axis.line.y=element_blank(),axis.ticks.y=element_blank())

# E. Ranked predicted target footprint (NicheNet regulatory potential).
targets <- targets |> mutate(target=factor(target,levels=rev(target)),
                             tier=case_when(rank<=3~"Top 3",rank<=7~"Ranks 4-7",TRUE~"Ranks 8-10"))
pE <- ggplot(targets,aes(weight,target))+
  geom_segment(aes(x=0,xend=weight,yend=target,colour=tier),linewidth=.9,alpha=.82)+
  geom_point(aes(fill=tier,size=weight_scaled),shape=21,colour="white",stroke=.45)+
  scale_colour_manual(values=c(`Top 3`=magenta,`Ranks 4-7`=coral,`Ranks 8-10`=gold),guide="none")+
  scale_fill_manual(values=c(`Top 3`=magenta,`Ranks 4-7`=coral,`Ranks 8-10`=gold),name=NULL)+
  scale_size(range=c(2.2,4.6),guide="none")+
  scale_x_continuous(labels=label_number(accuracy=.001),expand=expansion(mult=c(0,.06)))+
  labs(title="SEMA4D target footprint",
       subtitle="Predicted targets ranked by regulatory potential",
       x="Ligand-target regulatory potential",y=NULL)+
  theme(legend.position="bottom",axis.text.y=element_text(face="italic"),
        axis.line.y=element_blank(),axis.ticks.y=element_blank())

# F. State-aligned maps: state structure on the top row, within-gene expression
# on the bottom row. These maps are descriptive and do not imply spatial contact.
map_theme <- theme_void(base_family="Helvetica")+
  theme(plot.title=element_text(size=6.5,face="bold",hjust=0),
        plot.subtitle=element_text(size=5.3,colour="#69747D"),plot.margin=margin(2,2,1,12))
pm_state <- ggplot(myeloid,aes(map_x,map_y))+
  geom_point(aes(colour=state_group),size=.32,alpha=.72)+
  scale_colour_manual(values=c(M_CD16_IL1B=purple,M_IL1B=magenta,Other="#CBD4D9"),guide="none")+
  labs(title="Myeloid states",subtitle="SSc myeloid")+map_theme
pp_state <- ggplot(peri,aes(map_x,map_y))+
  geom_point(aes(colour=ECM_state),size=.31,alpha=.65)+
  scale_colour_manual(values=c(`ECM-low`=teal,`ECM-high`=coral),guide="none")+
  labs(title="Perivascular states",subtitle="Peri_RGS5")+map_theme
expr_cols <- c("#F2F4F5",gold,orange,magenta,"#7A1737")
pm_expr <- ggplot(myeloid,aes(map_x,map_y))+
  geom_point(colour="#DCE2E5",size=.29)+
  geom_point(data=filter(myeloid,expression>0),aes(colour=relative_expression),size=.58,alpha=.9)+
  scale_colour_gradientn(colours=expr_cols,limits=c(0,1),guide="none")+
  labs(title=expression(italic(SEMA4D)),subtitle="Within-gene expression")+map_theme
pp_expr <- ggplot(peri,aes(map_x,map_y))+
  geom_point(colour="#DCE2E5",size=.27)+
  geom_point(data=filter(peri,expression>0),aes(colour=relative_expression),size=.52,alpha=.88)+
  scale_colour_gradientn(colours=expr_cols,limits=c(0,1),name="Relative\nexpression")+
  labs(title=expression(italic(PLXNB2)),subtitle="Within-gene expression")+map_theme+
  theme(legend.position="right",legend.key.height=grid::unit(5,"mm"))
pF <- wrap_elements(full=(pm_state+pp_state)/(pm_expr+pp_expr)+plot_layout(guides="collect"))

# Reviewed B: retain the previously approved table structure. Colour is a
# secondary cue; raw evidence remains the primary readable layer.
mat_review <- mat
pB_core <- ggplot(mat_review,aes(metric,ligand))+
  geom_tile(aes(fill=score),colour="white",linewidth=.75)+
  geom_text(aes(label=label),size=1.82,colour=navy)+
  scale_fill_gradientn(colours=c("#F1F3F4","#D7E8E8","#8CC7C2",teal),
                       limits=c(0,1),name="Within-column\nrelative evidence")+
  labs(x=NULL,y=NULL)+
  theme(axis.text.x=element_text(size=5.4,face="bold"),
        axis.text.y=element_text(face="italic",size=6.3),
        axis.line=element_blank(),axis.ticks=element_blank(),legend.position="bottom",
        plot.margin=margin(2,1,2,2))
status_review <- cand |> mutate(ligand=factor(ligand,levels=levels(mat_review$ligand)),
                                status=case_when(ligand=="SEMA4D"~"Validation focus",
                                                 pathway_status=="Established fibrotic axis"~"Established",
                                                 TRUE~"Other"))
pB_status <- ggplot(status_review,aes("Axis\nstatus",ligand))+
  geom_tile(fill="#F1F3F4",colour="white",linewidth=.75)+
  geom_point(aes(fill=status),shape=21,size=3.1,colour="white",stroke=.45)+
  geom_text(aes(label=status),nudge_y=-.28,size=1.42,colour=navy)+
  scale_fill_manual(values=c(Established=purple,`Validation focus`=orange,Other=teal),guide="none")+
  coord_cartesian(ylim=c(.55,4.45),clip="off")+
  labs(x=NULL,y=NULL)+theme(axis.text.x=element_text(size=5.4,face="bold"),axis.text.y=element_blank(),
                            axis.line=element_blank(),axis.ticks=element_blank(),plot.margin=margin(2,2,2,0))
pB_reviewed <- wrap_elements(full=(pB_core+pB_status+plot_layout(widths=c(5,1.18)))+
  plot_annotation(title="Multi-evidence candidate matrix",
                  subtitle="Raw values shown; colour is normalized within each evidence column") &
  theme(plot.title=element_text(size=8.2,face="bold",family="Helvetica",colour="#17212B",margin=margin(l=14)),
        plot.subtitle=element_text(size=6.2,family="Helvetica",colour="#65717C",margin=margin(l=14))))

# Reviewed A-E assembly: preserve the locked panel identities and order.
assembly_reviewed <- ((((pA+pB_reviewed)+plot_layout(widths=c(.82,1.18)))/
  ((pD+pE)+plot_layout(widths=c(1.05,.95)))/pF)+
  plot_layout(heights=c(.91,.82,1.20))+plot_annotation(tag_levels="A"))

assembly <- (((pA+pB)+plot_layout(widths=c(.82,1.18)))/
  ((pC+pD)+plot_layout(widths=c(1.08,.92)))/
  ((pE+pF)+plot_layout(widths=c(.78,1.22))))+
  plot_layout(heights=c(.94,.68,1.18))+plot_annotation(tag_levels="A")

save_plot <- function(plot,stem,wmm,hmm,dpi=600){
  w<-wmm/25.4; h<-hmm/25.4
  ggsave(paste0(stem,".png"),plot,width=w,height=h,units="in",dpi=300,bg="white")
  ragg::agg_tiff(paste0(stem,".tiff"),width=w,height=h,units="in",res=dpi,
                 background="white",compression="lzw"); print(plot); grDevices::dev.off()
  svglite::svglite(paste0(stem,".svg"),width=w,height=h,bg="white"); print(plot); grDevices::dev.off()
  use_cairo <- FALSE # local Cairo DLL is unavailable; retain explicit preferred path
  if (use_cairo && isTRUE(capabilities("cairo"))) {
    grDevices::cairo_pdf(paste0(stem,".pdf"),width=w,height=h,family="Helvetica",bg="white")
  } else {
    grDevices::pdf(paste0(stem,".pdf"),width=w,height=h,family="Helvetica",bg="white",useDingbats=FALSE)
  }
  print(plot); grDevices::dev.off()
}

save_plot(pA,"outputs/Figure3A_upgraded_ligand_ranking",82,72)
save_plot(pB,"outputs/Figure3B_upgraded_evidence_fingerprint",101,72)
save_plot(pC,"outputs/Figure3C_upgraded_prioritisation_funnel",98,55)
save_plot(pD,"outputs/Figure3D_upgraded_expression_gate",85,60)
save_plot(pE,"outputs/Figure3E_upgraded_target_footprint",76,79)
save_plot(pF,"outputs/Figure3F_upgraded_state_aligned_maps",107,84)
save_plot(assembly,"outputs/Figure3_upgraded_assembly_v2",final_width_mm,213)
save_plot(pB_reviewed,"outputs/Figure3B_reviewed_candidate_matrix",105,72)
save_plot(pD,"outputs/Figure3C_reviewed_expression_gate",92,65)
save_plot(pE,"outputs/Figure3D_reviewed_target_footprint",91,72)
save_plot(pF,"outputs/Figure3E_reviewed_state_aligned_maps",183,91)
save_plot(assembly_reviewed,"outputs/Figure3_reviewed_assembly_v3",final_width_mm,213)

write_csv(funnel,"outputs/Figure3C_upgraded_prioritisation_funnel_source_data.csv")
write_lines(c(
  "Figure 3 upgraded QA notes",
  "Panel A uses expression-gated NicheNet corrected AUPR and does not claim that SEMA4D is the top-ranked ligand.",
  "Panel B scores are normalized within evidence columns; raw values are printed in each cell.",
  "Panel C is a transparent decision narrative, not an additional statistical analysis or formal elimination rule.",
  "Panel D is descriptive expression feasibility in prespecified sender/receiver states.",
  "Panel E contains NicheNet-predicted ligand-target regulatory potentials and does not establish receptor-mediated causality.",
  "Panel F shows state-aligned embeddings; proximity across separate embeddings does not imply physical cell-cell contact."
),"outputs/Figure3_upgraded_QA_notes.txt")
message("Figure 3 upgraded exports complete.")
