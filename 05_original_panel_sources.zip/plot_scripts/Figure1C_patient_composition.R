suppressPackageStartupMessages({
  library(ggplot2)
  library(svglite)
  library(ragg)
})

data_file <- "/Users/baoying/Desktop/巨噬细胞/Within_lineage_publication_analysis/Patient_level_within_lineage_zero_filled_FULL.csv"
stat_file <- "/Users/baoying/Desktop/巨噬细胞/Within_lineage_publication_analysis/Table_within_lineage_fraction_Wilcoxon_effect_size_min20.csv"
out_base <- "outputs/Figure1C_patient_level_key_subtype_fraction"
width_mm <- 112
height_mm <- 72

dat <- read.csv(data_file, check.names=FALSE)
st <- read.csv(stat_file, check.names=FALSE)
keep <- c("M_IL1B", "Peri_RGS5")
dat <- dat[dat$annotation %in% keep, ]
st <- st[st$annotation %in% keep, ]
stopifnot(nrow(dat) > 0, nrow(st) == 2)

dat$disease_group <- factor(dat$disease_group, levels=c("Ctrl", "SSc"))
dat$display <- factor(dat$annotation, levels=keep,
                      labels=c("Inflammatory myeloid\n(M_IL1B)", "RGS5+ pericytes\n(Peri_RGS5)"))

fmt_fdr <- function(x) {
  ifelse(x < 0.001, "FDR < 0.001", paste0("FDR = ", formatC(x, format="f", digits=3)))
}
st$display <- factor(st$annotation, levels=keep,
                     labels=c("Inflammatory myeloid\n(M_IL1B)", "RGS5+ pericytes\n(Peri_RGS5)"))
st$label <- paste0(fmt_fdr(st$FDR), "\n", st$effect_size, " effect",
                   "\n", "n = ", st$n_Ctrl, " / ", st$n_SSc)

# Facet-specific annotation height keeps the statistic clear without compressing the data.
yr <- aggregate(fraction_within_lineage ~ display, dat, max)
st <- merge(st, yr, by="display", all.x=TRUE)
st$y <- pmax(st$fraction_within_lineage * 1.10, st$median_SSc * 1.18 + 1)

cols <- c("Ctrl"="#718EA5", "SSc"="#C85E62")

p <- ggplot(dat, aes(disease_group, fraction_within_lineage, colour=disease_group)) +
  geom_boxplot(aes(fill=disease_group), width=0.52, outlier.shape=NA,
               linewidth=0.45, alpha=0.20) +
  geom_jitter(width=0.13, height=0, size=1.25, alpha=0.78, stroke=0) +
  stat_summary(fun=median, geom="crossbar", width=0.50, linewidth=0.55,
               colour="#222222") +
  geom_text(data=st, aes(x=1.5, y=y, label=label), inherit.aes=FALSE,
            family="Helvetica", size=2.4, lineheight=0.95, colour="#303030") +
  facet_wrap(~display, scales="free_y", nrow=1) +
  scale_colour_manual(values=cols) +
  scale_fill_manual(values=cols) +
  scale_y_continuous(expand=expansion(mult=c(0.03,0.18))) +
  labs(x=NULL, y="Fraction within lineage (%)") +
  theme_classic(base_size=7, base_family="Helvetica") +
  theme(
    strip.background=element_blank(),
    strip.text=element_text(size=7.6, face="bold", margin=margin(b=5)),
    axis.title.y=element_text(size=7.2, margin=margin(r=4)),
    axis.text.x=element_text(size=7, face="bold"),
    axis.text.y=element_text(size=6.4),
    axis.line=element_line(linewidth=0.35), axis.ticks=element_line(linewidth=0.35),
    legend.position="none", panel.spacing=grid::unit(8,"mm"),
    plot.margin=margin(5,5,4,5)
  )

svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                 system_fonts=list(sans="Arial"), pointsize=7)
print(p); dev.off()

pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
    family="Helvetica", pointsize=7, useDingbats=FALSE)
print(p); dev.off()

ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
               units="in", res=600, compression="lzw", background="white")
print(p); dev.off()

ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
              units="in", res=300, background="white")
print(p); dev.off()

write.csv(dat, paste0(out_base,"_source_data.csv"), row.names=FALSE)
write.csv(st, paste0(out_base,"_statistics.csv"), row.names=FALSE)
