suppressPackageStartupMessages({
  library(grid)
  library(svglite)
  library(ragg)
})

out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"
W <- 6.5
H <- 4.5
C <- list(
  ink = "#242326", grey = "#66717A", light_grey = "#F3F5F5",
  blue = "#1A8FB4", blue_light = "#E3F1F5",
  red = "#CB282A", red_light = "#F8E4E3",
  purple = "#9067AC", purple_light = "#EEE5F1",
  orange = "#F47E21", orange_light = "#FCE8D5",
  teal = "#55A99B", teal_light = "#E5F1EF",
  skin = "#F2B6AA", dermis = "#F9D5CE"
)

gp <- function(fill = NA, col = C$ink, lwd = 1, fontsize = 9, face = "plain")
  gpar(fill = fill, col = col, lwd = lwd, fontsize = fontsize,
       fontfamily = "Helvetica", fontface = face, linejoin = "round", lineend = "round")
txt <- function(s, x, y, size = 9, face = "plain", col = C$ink, just = "centre")
  grid.text(s, x, y, just = just, gp = gp(col = col, fontsize = size, face = face))
box <- function(x, y, w, h, fill, col) {
  grid.roundrect(x, y, w, h, r = unit(2.7, "mm"), gp = gp(fill, col, 1.2))
}
arrow_line <- function(x1, y1, x2, y2, col = C$grey) {
  grid.lines(c(x1, x2), c(y1, y2), gp = gp(col = col, lwd = 1.5),
             arrow = arrow(type = "closed", length = unit(2.2, "mm")))
}

skin_icon <- function(x, y, disease = FALSE) {
  grid.polygon(c(x-.035, x+.035, x+.030, x-.030), c(y+.035, y+.035, y-.040, y-.040),
               gp = gp(C$dermis, C$ink, .7))
  grid.polygon(c(x-.035, x-.012, x+.008, x+.035),
               c(y+.035, y+.050 + ifelse(disease,.008,0), y+.035, y+.035),
               gp = gp(ifelse(disease, "#E9827D", C$skin), NA, 0))
  for (k in 0:2) grid.lines(c(x-.022, x+.020), c(y-.020+k*.015, y-.027+k*.016),
                            gp = gp(col = "#DB9C91", lwd = .5))
}
cell_icon <- function(x, y, fill, label = NULL) {
  grid.circle(x, y, .032, gp = gp(fill, C$ink, .8))
  grid.circle(x, y, .011, gp = gp("#F5C4B8", NA, 0))
  if (!is.null(label)) txt(label, x, y-.052, 6.3, "plain", C$grey)
}

draw <- function() {
  grid.newpage()
  grid.rect(gp = gp("white", NA, 0))
  txt("Study workflow", .045, .955, 14, "bold", just = "left")
  txt("Discovery, patient-level confirmation and tissue validation", .045, .918, 7.8, "plain", C$grey, "left")

  xs <- c(.18, .50, .82)
  yt <- .69
  bw <- .255
  bh <- .30

  # 1: human atlas
  box(xs[1], yt, bw, bh, C$blue_light, C$blue)
  txt("1", xs[1]-.105, yt+.118, 8, "bold", C$blue)
  txt("Human skin atlas", xs[1], yt+.102, 10.2, "bold")
  skin_icon(xs[1]-.045, yt+.010, FALSE)
  skin_icon(xs[1]+.045, yt+.010, TRUE)
  txt("Ctrl", xs[1]-.045, yt-.058, 6.4, "bold", C$blue)
  txt("SSc", xs[1]+.045, yt-.058, 6.4, "bold", C$red)
  txt("single-cell RNA sequencing", xs[1], yt-.107, 6.8, "plain", C$grey)

  # 2: cell states
  box(xs[2], yt, bw, bh, C$purple_light, C$purple)
  txt("2", xs[2]-.105, yt+.118, 8, "bold", C$purple)
  txt("Cell-type and state discovery", xs[2], yt+.102, 8.5, "bold")
  cell_icon(xs[2]-.060, yt+.005, "#D96870")
  cell_icon(xs[2]+.060, yt+.005, C$teal)
  grid.lines(c(xs[2]-.025, xs[2]+.025), c(yt+.005, yt+.005), gp = gp(col=C$purple,lwd=1.5),
             arrow=arrow(type="closed",length=unit(1.8,"mm")))
  txt("inflammatory\nmyeloid", xs[2]-.060, yt-.070, 5.4, "plain", C$grey)
  txt("perivascular\nstates", xs[2]+.060, yt-.070, 5.4, "plain", C$grey)
  txt("marker and ECM programs", xs[2], yt-.108, 6.8, "plain", C$grey)

  # 3: patient confirmation
  box(xs[3], yt, bw, bh, C$red_light, C$red)
  txt("3", xs[3]-.105, yt+.118, 8, "bold", C$red)
  txt("Patient-level confirmation", xs[3], yt+.102, 9.7, "bold")
  for (i in 1:8) {
    xx <- xs[3]-.075+(i-1)*.022
    yy <- yt-.010 + c(.02,-.02,.05,-.04,.01,.06,-.015,.035)[i]
    grid.circle(xx, yy, .008, gp=gp(ifelse(i<=3,C$blue,C$red),NA,0))
  }
  grid.lines(c(xs[3]-.09,xs[3]+.09),c(yt-.055,yt-.055),gp=gp(col=C$grey,lwd=.6))
  txt("biological unit: patient", xs[3], yt-.108, 6.8, "plain", C$grey)

  arrow_line(xs[1]+bw/2+.015, yt, xs[2]-bw/2-.015, yt)
  arrow_line(xs[2]+bw/2+.015, yt, xs[3]-bw/2-.015, yt)

  # lower row, snake direction
  yb <- .265
  box(.66, yb, .31, .285, C$orange_light, C$orange)
  txt("4", .535, yb+.108, 8, "bold", C$orange)
  txt("Ligand-receptor prioritization", .66, yb+.093, 10, "bold")
  # neutral ranked bars and sender/receiver symbols
  for(i in 1:4) grid.rect(.57+i*.028, yb-.005, .016, c(.035,.055,.075,.095)[i],
                          gp=gp(c("#F6CDAA","#F3B57E","#EF9850",C$orange)[i],NA,0))
  cell_icon(.70, yb+.006, "#D96870")
  grid.lines(c(.735,.755),c(yb+.006,yb+.006),gp=gp(col=C$orange,lwd=1.6),
             arrow=arrow(type="closed",length=unit(1.8,"mm")))
  cell_icon(.78, yb+.006, C$teal)
  txt("expression-gated communication screen", .66, yb-.105, 6.8, "plain", C$grey)

  box(.25, yb, .37, .285, C$teal_light, C$teal)
  txt("5", .095, yb+.108, 8, "bold", C$teal)
  txt("Mouse time-course validation", .25, yb+.093, 10, "bold")
  days <- c("0", "2", "3", "5", "7 d")
  dx <- seq(.12,.31,length.out=5)
  grid.lines(c(dx[1],dx[5]),c(yb+.005,yb+.005),gp=gp(col=C$grey,lwd=.8))
  for(i in seq_along(dx)) {
    grid.circle(dx[i],yb+.005,.012,gp=gp(ifelse(i==1,C$blue,c("#F2B5A8","#E98F87","#D87570","#B95755")[i-1]),C$ink,.5))
    txt(days[i],dx[i],yb-.035,6.2)
  }
  grid.roundrect(.35,yb+.006,.055,.075,r=unit(1.5,"mm"),gp=gp("white",C$ink,.7))
  grid.rect(.35,yb+.006,.038,.045,gp=gp(C$dermis,"#D58C6E",.5))
  txt("H&E",.35,yb-.050,5.8,"bold")
  grid.roundrect(.405,yb+.006,.055,.075,r=unit(1.5,"mm"),gp=gp("#22313C",C$ink,.7))
  grid.circle(.395,yb+.014,.007,gp=gp("#4B73FF",NA,0)); grid.circle(.414,yb-.006,.007,gp=gp("#D94D8C",NA,0))
  txt("IF",.405,yb-.050,5.8,"bold")
  txt("mouse-level histology and imaging", .25, yb-.105, 6.8, "plain", C$grey)

  arrow_line(xs[3], yt-bh/2-.018, .78, yb+bh/2+.012)
  arrow_line(.50, yb, .455, yb)

}

svglite(file.path(out_dir, "Figure1A_neutral_study_workflow.svg"), width=W, height=H)
draw(); dev.off()
pdf(file.path(out_dir, "Figure1A_neutral_study_workflow.pdf"), width=W, height=H,
    family="Helvetica", useDingbats=FALSE)
draw(); dev.off()
agg_png(file.path(out_dir, "Figure1A_neutral_study_workflow.png"), width=W, height=H,
        units="in", res=320, background="white")
draw(); dev.off()
agg_tiff(file.path(out_dir, "Figure1A_neutral_study_workflow.tiff"), width=W, height=H,
         units="in", res=600, compression="lzw", background="white")
draw(); dev.off()
