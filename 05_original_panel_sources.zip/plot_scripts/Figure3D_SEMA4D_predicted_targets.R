suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(svglite)
})

src <- "/Users/baoying/Documents/Codex/2026-07-31/wos/work/Top20_ligand_target_links.csv"
out_dir <- "/Users/baoying/Documents/Codex/2026-07-31/wos/outputs"

dat <- read_csv(src, show_col_types = FALSE) %>%
  filter(ligand == "SEMA4D") %>%
  arrange(desc(weight)) %>%
  mutate(
    rank = row_number(),
    target = factor(target, levels = rev(target)),
    weight_scaled = weight / max(weight)
  )

write_csv(dat %>% mutate(target = as.character(target)),
          file.path(out_dir, "Figure3D_source_data.csv"))

p <- ggplot(dat, aes(x = weight, y = target)) +
  geom_segment(aes(x = 0, xend = weight, yend = target, colour = weight_scaled),
               linewidth = 1.15, lineend = "round") +
  geom_point(aes(colour = weight_scaled), size = 3.6) +
  scale_colour_gradientn(colours = c("#D9DEE0", "#F29979", "#CB282A"),
                         limits = c(0, 1), guide = "none") +
  scale_x_continuous(
    limits = c(0, 0.00835),
    breaks = c(0, 0.002, 0.004, 0.006, 0.008),
    labels = scales::label_number(accuracy = 0.001),
    expand = expansion(mult = c(0, 0.01))
  ) +
  labs(x = "Ligand-target regulatory potential", y = NULL) +
  theme_classic(base_size = 10, base_family = "sans") +
  theme(
    axis.text.x = element_text(size = 8.5, colour = "#202124"),
    axis.text.y = element_text(size = 9, face = "italic", colour = "#202124"),
    axis.title.x = element_text(size = 9.2, margin = margin(t = 7)),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    panel.grid.major.x = element_line(colour = "#E7EAEC", linewidth = 0.35),
    plot.margin = margin(7, 8, 5, 5)
  )

ggsave(file.path(out_dir, "Figure3D_SEMA4D_predicted_targets.svg"), p,
       width = 3.85, height = 3.35, units = "in", bg = "white")
ggsave(file.path(out_dir, "Figure3D_SEMA4D_predicted_targets.pdf"), p,
       width = 3.85, height = 3.35, units = "in", device = "pdf", bg = "white")
ggsave(file.path(out_dir, "Figure3D_SEMA4D_predicted_targets.png"), p,
       width = 3.85, height = 3.35, units = "in", dpi = 320, bg = "white")
ggsave(file.path(out_dir, "Figure3D_SEMA4D_predicted_targets.tiff"), p,
       width = 3.85, height = 3.35, units = "in", dpi = 600,
       compression = "lzw", bg = "white")
