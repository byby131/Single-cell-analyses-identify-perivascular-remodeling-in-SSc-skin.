suppressPackageStartupMessages({
  library(ggplot2)
  library(ggrepel)
  library(svglite)
  library(ragg)
})

input_csv <- "/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_ECM_high_vs_low_analysis/Markers_Peri_RGS5_ECM_high_vs_low_all.csv"
out_base <- "outputs/Figure2E_ECM_high_vs_low_volcano_Cell_palette_v1"
width_mm <- 92
height_mm <- 68
fc_cut <- 1
fdr_cut <- 0.05
y_cap <- 80

de <- read.csv(input_csv, check.names=FALSE)
stopifnot(all(c("gene","avg_log2FC","p_val_adj") %in% colnames(de)))
de$neglog10_fdr_raw <- -log10(pmax(de$p_val_adj, .Machine$double.xmin))
de$neglog10_fdr <- pmin(de$neglog10_fdr_raw, y_cap)
de$direction <- "Not significant"
de$direction[de$p_val_adj < fdr_cut & de$avg_log2FC >= fc_cut] <- "Higher in ECM-high"
de$direction[de$p_val_adj < fdr_cut & de$avg_log2FC <= -fc_cut] <- "Higher in ECM-low"
de$direction <- factor(de$direction,
                       levels=c("Not significant","Higher in ECM-low","Higher in ECM-high"))

label_genes <- c("MYH11","PLN","RERGL","SORBS2",
                 "COL3A1","COL1A2","COL1A1","POSTN","SPARC","THY1")
lab <- de[de$gene %in% label_genes, ]

cols <- c("Not significant"="#BEBEBE",
          "Higher in ECM-low"="#1A8FB4",
          "Higher in ECM-high"="#CB282A")

p <- ggplot(de, aes(avg_log2FC, neglog10_fdr, colour=direction)) +
  geom_hline(yintercept=-log10(fdr_cut), linetype="dashed",
             colour="#8E8E8E", linewidth=0.35) +
  geom_vline(xintercept=c(-fc_cut,fc_cut), linetype="dashed",
             colour="#8E8E8E", linewidth=0.35) +
  geom_point(size=0.75, alpha=0.78, stroke=0) +
  ggrepel::geom_text_repel(
    data=lab, aes(label=gene), family="Helvetica", size=2.25,
    colour="#222222", box.padding=0.28, point.padding=0.15,
    min.segment.length=0, segment.colour="#777777", segment.size=0.25,
    max.overlaps=Inf, seed=2026
  ) +
  scale_colour_manual(values=cols, drop=FALSE) +
  scale_y_continuous(limits=c(0,y_cap), breaks=c(0,20,40,60,80),
                     expand=expansion(mult=c(0,0.02))) +
  labs(x="Average log2 fold change", y="-log10(FDR)") +
  theme_classic(base_size=7, base_family="Helvetica") +
  theme(
    axis.title=element_text(size=7), axis.text=element_text(size=6.3),
    axis.line=element_line(linewidth=0.35), axis.ticks=element_line(linewidth=0.35),
    legend.position="bottom", legend.title=element_blank(),
    legend.text=element_text(size=5.9), legend.key.width=grid::unit(3.5,"mm"),
    legend.spacing.x=grid::unit(1.5,"mm"),
    plot.margin=margin(4,3,2,4)
  ) +
  guides(colour=guide_legend(override.aes=list(size=2.1, alpha=1), nrow=1))

svglite::svglite(paste0(out_base,".svg"), width=width_mm/25.4, height=height_mm/25.4,
                 system_fonts=list(sans="Arial"), pointsize=7)
print(p); dev.off()
pdf(paste0(out_base,".pdf"), width=width_mm/25.4, height=height_mm/25.4,
    family="Helvetica", pointsize=7, useDingbats=FALSE)
print(p); dev.off()
ragg::agg_tiff(paste0(out_base,".tiff"), width=width_mm/25.4, height=height_mm/25.4,
               units="in", res=600, compression="lzw", background="white")
print(p); dev.off()
ragg::agg_png(paste0(out_base,"_preview.png"), width=width_mm/25.4, height=height_mm/25.4,
              units="in", res=300, background="white")
print(p); dev.off()
write.csv(de, paste0(out_base,"_source_data.csv"), row.names=FALSE)
