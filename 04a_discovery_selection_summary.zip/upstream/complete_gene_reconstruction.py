"""Resolve the effect of above-threshold empty wells on the saved gene sets."""
from pathlib import Path
import pandas as pd
import numpy as np
OUT=Path(__file__).resolve().parent
RAW=Path('/Users/baoying/Desktop/GSE195452/GSE195452RAW')
x=pd.read_csv(OUT/'all_skin_cell_audit.csv',low_memory=False)
s=pd.read_csv('/Users/baoying/Desktop/巨噬细胞/GSE195452_sample_info_with_group_fixed.csv')
x=x.merge(s[['Amp_batch_ID','source_name_ch1','gsm']],on='Amp_batch_ID')
empty=x[x.Number_of_cells.eq(0)&x.raw_features.ge(200)&x.source_name_ch1.eq('Forearm skin')]
tests=[]
for group in ['Ctrl','SSc']:
    d=pd.read_csv(OUT/f'{group}_gene_detection_counts.csv',index_col=0)
    d['all_min200']=d.single_min200
    z=empty[empty.disease_group==group]
    for (gsm,amp),wells in z.groupby(['gsm','Amp_batch_ID']):
        mat=pd.read_csv(RAW/f'{gsm}_{amp}.txt.gz',sep='\t',index_col=0)
        mat.index=mat.index.str.replace('_','-',regex=False).str.replace('|','-',regex=False)
        counts=(mat[wells.raw_well]>0).sum(axis=1)
        d['all_min200']=d.all_min200.add(counts,fill_value=0)
    saved=set((OUT/f'{group}_saved_gene_names.txt').read_text().splitlines())
    for pop in ['single_min200','all_min200']:
        genes=set(d.index[d[pop]>=3])
        tests.append(dict(group=group,population=pop,min_cells=3,genes=len(genes),extra=len(genes-saved),missing=len(saved-genes)))
    d.to_csv(OUT/f'{group}_gene_detection_counts_complete.csv')
pd.DataFrame(tests).to_csv(OUT/'complete_gene_universe_agreement.csv',index=False)
empty.to_csv(OUT/'above_initial_threshold_empty_wells.csv',index=False)
print(pd.DataFrame(tests).to_string(index=False))
