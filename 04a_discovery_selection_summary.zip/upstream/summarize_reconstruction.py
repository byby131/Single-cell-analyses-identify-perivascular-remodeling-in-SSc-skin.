"""Create an auditable, explicitly retrospective selection flow from verified IDs."""
from pathlib import Path
import hashlib,json
import pandas as pd
import numpy as np
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]

def main():
    s=pd.read_csv('/Users/baoying/Desktop/巨噬细胞/GSE195452_sample_info_with_group_fixed.csv')
    m=pd.read_csv(OUT/'released_metadata_joined.csv',low_memory=False).merge(s[['Amp_batch_ID','source_name_ch1']],on='Amp_batch_ID',validate='many_to_one')
    q=pd.read_csv(OUT/'forearm_filtered_gene_QC.csv')
    a=pd.read_csv(ROOT/'outputs/R2_revision_20261029/inputs/discovery_combined_metadata.csv',low_memory=False)
    fig=pd.read_csv(ROOT/'outputs/R2_revision_20261029/inputs/discovery_figure1_metadata.csv',low_memory=False)
    rawq=pd.read_csv(OUT/'raw_skin_QC.csv')
    j=m.merge(q,on='cell_id',how='left',validate='one_to_one').merge(rawq[['cell_id','raw_counts','raw_features','raw_mt_pct']],on='cell_id',how='left',validate='one_to_one')
    j['skin_known_group']=j.tissue.str.lower().eq('skin')&j.disease_group.isin(['SSc','Ctrl'])
    j['forearm_eligible']=j.skin_known_group&j.source_name_ch1.eq('Forearm skin')
    j['single_cell_well']=j.Number_of_cells.eq(1)
    j['initial_features_ge200']=j.raw_features.ge(200)
    j['pass_features_lower']=j.filtered_features.gt(300)
    j['pass_features_upper']=j.filtered_features.lt(6000)
    j['pass_mitochondrial']=j.filtered_mt_pct.lt(20)
    j['reconstructed_atlas']=j.forearm_eligible&j.single_cell_well&j.pass_features_lower&j.pass_features_upper&j.pass_mitochondrial
    j['saved_atlas']=j.cell_id.isin(a.cell_id)
    j['saved_figure1B']=j.cell_id.isin(fig.cell_id)
    discrepancy=j[j.reconstructed_atlas!=j.saved_atlas]
    discrepancy.to_csv(OUT/'final_cell_ID_discrepancies.csv',index=False)
    assert discrepancy.empty, f'{len(discrepancy)} cell-ID mismatches; do not claim exact reconstruction'
    checks={}
    old_manifest=pd.read_csv('/Users/baoying/Desktop/GSE195452/GSE195452RAW/GSE195452_SSc_skin_raw_files.csv')
    forearm_ssc_batches=set(j.loc[j.forearm_eligible&j.disease_group.eq('SSc'),'Amp_batch_ID'])
    checks['early_SSc_manifest_exact_batch_match']=forearm_ssc_batches==set(old_manifest.Amp_batch_ID)
    checks['early_SSc_manifest_batches']=len(old_manifest)
    joined=q.merge(a[['cell_id','nCount_RNA','nFeature_RNA','percent.mt']],on='cell_id',validate='one_to_one')
    for new,old in [('filtered_counts','nCount_RNA'),('filtered_features','nFeature_RNA'),('filtered_mt_pct','percent.mt')]:
        checks[new+'_matches']=int(np.isclose(joined[new],joined[old],rtol=1e-9,atol=1e-9).sum())
        assert checks[new+'_matches']==len(a)
    stages=[('01_released_annotation_wells',pd.Series(True,index=j.index)),
            ('02_skin_SSc_or_control',j.skin_known_group),
            ('03_forearm_skin',j.forearm_eligible),
            ('04_initial_raw_genes_ge200',j.forearm_eligible&j.initial_features_ge200),
            ('05_single_cell_wells',j.forearm_eligible&j.initial_features_ge200&j.single_cell_well),
            ('06_filtered_genes_gt300',j.forearm_eligible&j.single_cell_well&j.pass_features_lower),
            ('07_filtered_genes_lt6000',j.forearm_eligible&j.single_cell_well&j.pass_features_lower&j.pass_features_upper),
            ('08_mitochondrial_lt20pct',j.reconstructed_atlas),
            ('09_Figure1B_SSc_only',j.reconstructed_atlas&j.disease_group.eq('SSc'))]
    flow=[];participant=[]
    for stage,mask in stages:
        z=j[mask]
        groups=[('ALL',z)]+list(z.groupby('disease_group',dropna=False))
        for group,sub in groups:
            pool=sub.patient_id.str.contains('pool',case=False,na=False)
            flow.append(dict(stage=stage,disease_group=group,entries=len(sub),sample_IDs=sub.patient_id.nunique(),nonpool_IDs=sub.loc[~pool,'patient_id'].nunique(),pool_IDs=sub.loc[pool,'patient_id'].nunique(),batches=sub.Amp_batch_ID.nunique()))
        zz=z.groupby(['patient_id','disease_group'],dropna=False).agg(entries=('cell_id','size'),batches=('Amp_batch_ID','nunique')).reset_index();zz.insert(0,'stage',stage);participant.append(zz)
    pd.DataFrame(flow).to_csv(OUT/'reconstructed_selection_flow.csv',index=False)
    pd.concat(participant,ignore_index=True).to_csv(OUT/'per_participant_stage_counts.csv',index=False)
    j['first_exclusion_reason']=np.select([~j.skin_known_group,~j.forearm_eligible,~j.initial_features_ge200,~j.single_cell_well,~j.pass_features_lower,~j.pass_features_upper,~j.pass_mitochondrial],['outside_skin_SSc_Ctrl','outside_forearm','initial_raw_genes_lt200','empty_well','detected_genes_le300','detected_genes_ge6000','mt_ge20pct'],default='retained')
    j.to_csv(OUT/'full_selection_audit.csv.gz',index=False,compression='gzip')
    j.groupby(['disease_group','first_exclusion_reason'],dropna=False).size().rename('entries').to_csv(OUT/'exclusion_reason_counts.csv')
    # Dedicated Peri_RGS5 branch: independent raw-data extraction, NOT a nested
    # subset of the full-skin atlas. Retain all sites, exclude pooled identifier.
    p=pd.read_csv(OUT/'Peri_raw_early_object_metadata.csv')
    peri0=j.skin_known_group&j.annotation.eq('Peri_RGS5')
    peri=peri0&~j.patient_id.str.contains('pool',case=False,na=False)
    assert set(j.loc[peri,'cell_id'])==set(p.cell_id)
    pq=p.merge(rawq[['cell_id','raw_counts','raw_features']],on='cell_id',validate='one_to_one')
    assert (pq.nCount_RNA==pq.raw_counts).all() and (pq.nFeature_RNA==pq.raw_features).all()
    strict_ids=set(a.loc[a.annotation=='Peri_RGS5','cell_id'])&set(p.cell_id)
    peristages=[('01_released_skin_Peri_RGS5',peri0),('02_exclude_pooled_identifier',peri),('03_exact_CD90_subset',peri&j.selection_marker.eq('CD90+')),('04_strict_atlas_overlap',j.cell_id.isin(strict_ids))]
    pf=[]
    for stage,mask in peristages:
        for group,z in [('ALL',j[mask])]+list(j[mask].groupby('disease_group')):
            pf.append(dict(stage=stage,disease_group=group,cells=len(z),sample_IDs=z.patient_id.nunique()))
    pd.DataFrame(pf).to_csv(OUT/'dedicated_perivascular_branch.csv',index=False)
    j[peri].groupby(['source_name_ch1','disease_group']).agg(cells=('cell_id','size'),sample_IDs=('patient_id','nunique')).to_csv(OUT/'dedicated_perivascular_anatomical_sites.csv')
    pd.DataFrame({'cell_id':sorted(strict_ids)}).to_csv(OUT/'strict_overlap_cell_IDs.csv',index=False)
    p.loc[p.selection_marker.eq('CD90+'),['cell_id']].to_csv(OUT/'CD90_cell_IDs.csv',index=False)
    checks.update(saved_atlas_cells=len(a),reconstructed_atlas_cells=int(j.reconstructed_atlas.sum()),extra_cells=0,missing_cells=0,figure1B_exact_SSc_match=set(fig.cell_id)==set(j.loc[j.reconstructed_atlas&j.disease_group.eq('SSc'),'cell_id']),dedicated_perivascular_exact_match=True,dedicated_perivascular_cells=len(p))
    gene_checks=pd.read_csv(OUT/'complete_gene_universe_agreement.csv').query('population=="all_min200"')
    assert (gene_checks.extra.eq(0)&gene_checks.missing.eq(0)).all()
    checks['both_gene_universes_reconstructed_from_raw_exactly']=True
    gene_checks.to_csv(OUT/'verified_gene_universe_reconstruction.csv',index=False)
    for name in ['Figure1E_M_IL1B_patient_fraction_source_data.csv','Figure1F_Peri_RGS5_patient_fraction_source_data.csv']:
        f=pd.read_csv(ROOT/'outputs'/name)
        checks[name+'_contains_pool']=bool(f.patient_id.astype(str).str.contains('pool',case=False).any())
    (OUT/'verification_summary.json').write_text(json.dumps(checks,indent=2))
    print(pd.DataFrame(flow).query('disease_group=="ALL"').to_string(index=False))
    print(json.dumps(checks,indent=2))

if __name__=='__main__':main()
