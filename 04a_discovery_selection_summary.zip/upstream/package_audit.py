from pathlib import Path
import hashlib,json,zipfile
import pandas as pd
OUT=Path(__file__).resolve().parent
RAW=Path('/Users/baoying/Desktop/GSE195452/GSE195452RAW')
files=[Path('/Users/baoying/Desktop/巨噬细胞/GSE195452_Cell_metadata_v26_anno.txt'),Path('/Users/baoying/Desktop/巨噬细胞/GSE195452_sample_info_with_group_fixed.csv'),RAW/'GSE195452_SSc_skin_raw_files.csv',RAW/'GSE195452_SSc_skin_sample_meta.csv',RAW/'GSE195452_SSc_skin_full_sce.rds',Path('/Users/baoying/Desktop/巨噬细胞/GSE195452_UMAP_PDF/GSE195452_Ctrl_skin_sce.rds'),Path('/Users/baoying/Desktop/巨噬细胞/GSE195452_UMAP_PDF/GSE195452_SSc_Ctrl_skin_combined_raw.rds'),Path('/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_Ctrl_SSc_ECM_figures/peri_all_Ctrl_SSc_raw.rds')]
s=pd.read_csv(files[1]);m=pd.read_csv(OUT/'released_metadata_joined.csv',low_memory=False)
s=s[s.tissue.str.lower().eq('skin')&s.disease_group.isin(['SSc','Ctrl'])&s.Amp_batch_ID.isin(m.Amp_batch_ID)]
files += [RAW/f'{r.gsm}_{r.Amp_batch_ID}.txt.gz' for r in s.itertuples()]
manifest=[]
for p in files:
    h=hashlib.sha256()
    with p.open('rb') as f:
        while chunk:=f.read(4*1024*1024):h.update(chunk)
    manifest.append(dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest()))
pd.DataFrame(manifest).to_csv(OUT/'input_provenance_sha256.csv',index=False)
selected=['恢复结果与修改建议.md','reconstructed_selection_flow.csv','per_participant_stage_counts.csv','full_selection_audit.csv.gz','verification_summary.json','verified_gene_universe_reconstruction.csv','dedicated_perivascular_branch.csv','dedicated_perivascular_anatomical_sites.csv','CD90_cell_IDs.csv','strict_overlap_cell_IDs.csv','saved_object_evidence.txt','input_provenance_sha256.csv','final_cell_ID_discrepancies.csv','exclusion_reason_counts.csv','complete_gene_universe_agreement.csv','above_initial_threshold_empty_wells.csv','SSc_saved_gene_names.txt','Ctrl_saved_gene_names.txt','SSc_gene_detection_counts_complete.csv','Ctrl_gene_detection_counts_complete.csv','reconstruct.py','inspect_objects.R','verify_gene_filter.py','complete_gene_reconstruction.py','summarize_reconstruction.py','package_audit.py']
with zipfile.ZipFile(OUT/'GSE195452_上游筛选重建与核验.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in selected:z.write(OUT/name,arcname=name)
print('Verified input files:',len(manifest))
print('Archive bytes:',(OUT/'GSE195452_上游筛选重建与核验.zip').stat().st_size)
