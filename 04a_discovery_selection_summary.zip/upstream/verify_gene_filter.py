"""Recalculate QC using saved gene universes and test global gene-detection rules."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import time
import pandas as pd
import numpy as np
OUT=Path(__file__).resolve().parent
RAW=Path('/Users/baoying/Desktop/GSE195452/GSE195452RAW')

def batch(task):
    gsm,amp,group,single_wells=task
    x=pd.read_csv(RAW/f'{gsm}_{amp}.txt.gz',sep='\t',index_col=0)
    a=x.to_numpy(dtype=np.int32)
    names=x.index.str.replace('_','-',regex=False).str.replace('|','-',regex=False)
    saved=set((OUT/f'{group}_saved_gene_names.txt').read_text().splitlines())
    mask=names.isin(saved);mt=names.str.startswith('MT-')
    ar=a[mask];n=ar.sum(axis=0)
    q=pd.DataFrame({'cell_id':amp+'_'+x.columns,'filtered_counts':n,'filtered_features':(ar>0).sum(axis=0),
                    'filtered_mt_pct':np.divide(100*a[mask&mt].sum(axis=0),n,out=np.full(n.shape,np.nan),where=n!=0)})
    single=x.columns.isin(single_wells)
    nf=(a>0).sum(axis=0)
    detect=pd.DataFrame({'gene':names,'all':(a>0).sum(axis=1),'single':(a[:,single]>0).sum(axis=1),
                        'single_min200':(a[:,single&(nf>=200)]>0).sum(axis=1)})
    return group,q,detect

def main():
    s=pd.read_csv('/Users/baoying/Desktop/巨噬细胞/GSE195452_sample_info_with_group_fixed.csv')
    m=pd.read_csv(OUT/'released_metadata_joined.csv',low_memory=False)
    s=s[(s.source_name_ch1=='Forearm skin')&s.disease_group.isin(['SSc','Ctrl'])&s.Amp_batch_ID.isin(m.Amp_batch_ID)]
    tasks=[(r.gsm,r.Amp_batch_ID,r.disease_group,m.loc[(m.Amp_batch_ID==r.Amp_batch_ID)&m.Number_of_cells.eq(1),'Well_ID'].tolist()) for r in s.itertuples()]
    sums={};frames=[];t=time.time()
    with ProcessPoolExecutor(max_workers=4) as ex:
        for i,(group,q,d) in enumerate(ex.map(batch,tasks)):
            frames.append(q);d=d.set_index('gene')
            sums[group]=d if group not in sums else sums[group].add(d,fill_value=0)
            if (i+1)%50==0:print('Verified',i+1,'/',len(tasks),'batches;',round(time.time()-t),'seconds',flush=True)
    q=pd.concat(frames,ignore_index=True)
    q.to_csv(OUT/'forearm_filtered_gene_QC.csv',index=False)
    tests=[]
    for group,d in sums.items():
        d.to_csv(OUT/f'{group}_gene_detection_counts.csv')
        saved=set((OUT/f'{group}_saved_gene_names.txt').read_text().splitlines())
        for pop in d.columns:
            for threshold in (1,2,3,5,10):
                genes=set(d.index[d[pop]>=threshold])
                tests.append(dict(group=group,population=pop,min_cells=threshold,genes=len(genes),extra=len(genes-saved),missing=len(saved-genes)))
    pd.DataFrame(tests).to_csv(OUT/'gene_universe_rule_agreement.csv',index=False)
    print(pd.DataFrame(tests).to_string(index=False),flush=True)
    a=pd.read_csv('outputs/R2_revision_20261029/inputs/discovery_combined_metadata.csv',low_memory=False)
    j=q.merge(a[['cell_id','nCount_RNA','nFeature_RNA','percent.mt']],on='cell_id')
    print('QC exact agreement:',[(new,int(np.isclose(j[new],j[old],rtol=1e-9,atol=1e-9).sum())) for new,old in [('filtered_counts','nCount_RNA'),('filtered_features','nFeature_RNA'),('filtered_mt_pct','percent.mt')]],'of',len(j),flush=True)
    rule=q[(q.filtered_features>300)&(q.filtered_features<6000)&(q.filtered_mt_pct<20)]
    print('Candidate final filter',len(rule),'extra',len(set(rule.cell_id)-set(a.cell_id)),'missing',len(set(a.cell_id)-set(rule.cell_id)),flush=True)

if __name__=='__main__':main()
