"""Forensic reconstruction; candidate QC rules are hypotheses, not historical logs."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import gzip, json, time
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
BASE=Path('/Users/baoying/Desktop/巨噬细胞')
RAW=Path('/Users/baoying/Desktop/GSE195452/GSE195452RAW')

def process_batch(task):
    gsm,batch=task
    path=RAW/f'{gsm}_{batch}.txt.gz'
    if not path.exists(): return None
    x=pd.read_csv(path,sep='\t',index_col=0)
    a=x.to_numpy(dtype=np.int32)
    mt=x.index.str.startswith('MT-')
    n=a.sum(axis=0); nf=(a>0).sum(axis=0)
    ans=pd.DataFrame({'cell_id':batch+'_'+x.columns,'raw_well':x.columns,'Amp_batch_ID':batch,
                      'raw_counts':n,'raw_features':nf,'raw_mt_pct':np.divide(100*a[mt].sum(axis=0),n,out=np.full(n.shape,np.nan),where=n!=0)})
    for k in (3,):
        gene_keep=(a>0).sum(axis=1)>=k
        ak=a[gene_keep];nk=ak.sum(axis=0)
        ans[f'batch_min{k}_counts']=nk
        ans[f'batch_min{k}_features']=(ak>0).sum(axis=0)
        ans[f'batch_min{k}_mt_pct']=np.divide(100*a[mt & gene_keep].sum(axis=0),nk,out=np.full(nk.shape,np.nan),where=nk!=0)
    return ans

def main():
    s=pd.read_csv(BASE/'GSE195452_sample_info_with_group_fixed.csv')
    m=pd.read_csv(BASE/'GSE195452_Cell_metadata_v26_anno.txt',sep='\t',index_col=0,low_memory=False)
    m=m.merge(s[['Amp_batch_ID','gsm','patient_id','tissue','disease_group','selection_marker']],on='Amp_batch_ID',how='left',validate='many_to_one')
    m['cell_id']=m.Amp_batch_ID+'_'+m.Well_ID
    m.to_csv(OUT/'released_metadata_joined.csv',index=False)
    s.groupby(['tissue','disease_group'],dropna=False).agg(batches=('Amp_batch_ID','size'),participants=('patient_id','nunique')).to_csv(OUT/'sample_metadata_inventory.csv')
    m.groupby(['tissue','disease_group'],dropna=False).agg(entries=('cell_id','size'),participants=('patient_id','nunique')).to_csv(OUT/'released_metadata_inventory.csv')
    skin=s[(s.tissue.str.lower()=='skin') & s.disease_group.isin(['SSc','Ctrl'])]
    cache=OUT/'raw_skin_QC.csv'
    if cache.exists(): q=pd.read_csv(cache)
    else:
        ans=[];t=time.time()
        with ProcessPoolExecutor(max_workers=4) as ex:
            for i,a in enumerate(ex.map(process_batch,skin[['gsm','Amp_batch_ID']].itertuples(index=False,name=None))):
                if a is not None: ans.append(a)
                if (i+1)%25==0: print('Processed',i+1,'/',len(skin),'batches; seconds',round(time.time()-t),flush=True)
        q=pd.concat(ans,ignore_index=True);q.to_csv(cache,index=False)
    q=q.merge(m.drop(columns=['gsm']),on=['cell_id','Amp_batch_ID'],how='left',validate='one_to_one')
    atlas=pd.read_csv('outputs/R2_revision_20261029/inputs/discovery_combined_metadata.csv',low_memory=False)
    q=q.merge(atlas[['cell_id','nCount_RNA','nFeature_RNA','percent.mt']],on='cell_id',how='left',validate='one_to_one')
    q['in_saved']=q.nCount_RNA.notna()
    print('Raw entries:',len(q),'saved matched:',q.in_saved.sum(),flush=True)
    results=[]
    for pref in ('raw','batch_min3'):
        keep=q.in_saved
        print(pref,'QC agreement',[(col,int(np.isclose(q.loc[keep,pref+'_'+col],q.loc[keep,stored],rtol=1e-9,atol=1e-9).sum())) for col,stored in [('counts','nCount_RNA'),('features','nFeature_RNA'),('mt_pct','percent.mt')]],flush=True)
        for annotation_filter in ('none','not_underscore','not_underscore_UN'):
            for single in (False,True):
                rule=(q[pref+'_features']>300)&(q[pref+'_mt_pct']<20)
                if single: rule &=pd.to_numeric(q.Number_of_cells,errors='coerce').eq(1)
                if annotation_filter!='none': rule &= q.annotation.notna() & q.annotation.ne('_')
                if annotation_filter=='not_underscore_UN': rule &=q.annotation.ne('UN')
                results.append(dict(metrics=pref,annotation_filter=annotation_filter,single_cell_only=single,retained=int(rule.sum()),extra=int((rule&~q.in_saved).sum()),missing=int((~rule&q.in_saved).sum())))
    pd.DataFrame(results).to_csv(OUT/'candidate_rule_cell_ID_agreement.csv',index=False)
    q.to_csv(OUT/'all_skin_cell_audit.csv',index=False)
    print(pd.DataFrame(results).to_string(index=False),flush=True)

if __name__=='__main__': main()
