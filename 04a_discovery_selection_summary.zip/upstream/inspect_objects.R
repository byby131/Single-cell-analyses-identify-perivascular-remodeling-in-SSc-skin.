suppressPackageStartupMessages(library(Seurat))
out <- 'outputs/discovery_upstream_reconstruction_20261031'
paths <- c(SSc='/Users/baoying/Desktop/GSE195452/GSE195452RAW/GSE195452_SSc_skin_full_sce.rds', Ctrl='/Users/baoying/Desktop/巨噬细胞/GSE195452_UMAP_PDF/GSE195452_Ctrl_skin_sce.rds', Peri_raw='/Users/baoying/Desktop/巨噬细胞/Peri_RGS5_Ctrl_SSc_ECM_figures/peri_all_Ctrl_SSc_raw.rds')
sink(file.path(out,'saved_object_evidence.txt'))
for(nm in names(paths)) {
 x <- readRDS(paths[[nm]])
 cat('\nOBJECT:',nm,'\nPATH:',paths[[nm]],'\nDIMENSIONS:',dim(x),'\n')
 cat('ASSAY CLASS:',class(x[['RNA']]),'\n')
 cat('LAYERS:',paste(Layers(x[['RNA']]),collapse=', '),'\n')
 for(z in x@commands) cat(as.character(z@time.stamp),z@call.string,'\n')
 print(summary(x[[]][,intersect(c('nCount_RNA','nFeature_RNA','percent.mt'),names(x[[]]))]))
 md <- x[[]];md$cell_id<-rownames(md)
 write.csv(md,file.path(out,paste0(nm,'_early_object_metadata.csv')),row.names=FALSE)
 writeLines(rownames(x),file.path(out,paste0(nm,'_saved_gene_names.txt')))
 cat('Annotation distribution:\n');print(table(md$annotation,useNA='always'))
 cat('Misc/tools:',names(x@misc),names(x@tools),'\n')
}
sink()
