suppressPackageStartupMessages({library(dplyr);library(tidyr);library(readr);library(tibble)})
root<-'.';out<-file.path(root,'results/ligands');dir.create(out,recursive=TRUE,showWarnings=FALSE)
set.seed(2026102901)
frozen<-readRDS('inputs/frozen_NicheNet_analysis_inputs.rds')
w<-frozen$weights;bg<-frozen$background;gs<-frozen$receiver_genes;ligands<-colnames(w)
saved<-list(final_ranked_ligands=frozen$ranking,top_ligand_target_links=frozen$target_links)
# ROCR precision/recall trapezoid calculation, including score ties and the
# initial precision=1 point, matching the installed NicheNet implementation.
orders <- lapply(seq_along(ligands),function(j)order(w[,j],decreasing=TRUE))
ends <- lapply(seq_along(ligands),function(j){v<-w[orders[[j]],j];c(which(diff(v)!=0),length(v))})
aupr <- function(pos){response<-as.integer(bg%in%pos);vapply(seq_along(ligands),function(j){e<-ends[[j]];tp<-cumsum(response[orders[[j]]])[e];rec<-c(0,tp/sum(response));prec<-c(1,tp/e);sum(diff(rec)*(head(prec,-1)+tail(prec,-1))/2)-mean(response)},numeric(1))}
observed <- aupr(gs)
expected <- saved$final_ranked_ligands$aupr_corrected
stopifnot(length(gs)==28,length(bg)==4576,max(abs(observed-expected))<1e-12)
write_csv(tibble(ligand=ligands,observed_aupr_corrected=observed,saved_aupr_corrected=expected,difference=observed-expected),file.path(out,'ranking_exact_reproduction.csv'))
cat('Exact ranking reproduced\n')
bins<-read_csv(file.path(root,'inputs/discovery_null_strata.csv'),show_col_types=FALSE)
write_csv(bins,file.path(out,'matched_null_gene_strata.csv'))
pools<-split(bins$gene,bins$stratum);sizes<-table(bins$stratum[bins$receiver_positive])
B<-1000L;null<-matrix(NA_real_,B,length(ligands),dimnames=list(NULL,ligands))
for(b in seq_len(B)){rand<-unlist(lapply(names(sizes),function(s)sample(pools[[s]],sizes[[s]],replace=FALSE)),use.names=FALSE);null[b,]<-aupr(rand);if(b%%200==0)cat('Null draw',b,'\n')}
saveRDS(null,file.path(out,'matched_null_all75.rds'))
emp<-vapply(seq_along(ligands),function(j)(1+sum(null[,j]>=observed[j]))/(B+1),numeric(1))
nullranks<-t(apply(null,1,function(a)rank(-a,ties.method='min')))
ans<-tibble(ligand=ligands,observed_rank=rank(-observed,ties.method='min'),corrected_AUPR=observed,null_mean=colMeans(null),null_q025=apply(null,2,quantile,.025),null_q975=apply(null,2,quantile,.975),empirical_P=emp,BH_FDR_75=p.adjust(emp,'BH'),null_rank_median=apply(nullranks,2,median),null_rank_q025=apply(nullranks,2,quantile,.025),null_rank_q975=apply(nullranks,2,quantile,.975),null_draws=B,seed=2026102901)
write_csv(ans,file.path(out,'matched_null_results_all75.csv'))
loo<-bind_rows(lapply(gs,function(g){a<-aupr(setdiff(gs,g));tibble(omitted_gene=g,ligand=ligands,corrected_AUPR=a,rank=rank(-a,ties.method='min'))}))
write_csv(loo,file.path(out,'receiver_leave_one_gene_out_all75.csv'))
write_csv(loo |>group_by(ligand)|>summarise(min_rank=min(rank),median_rank=median(rank),max_rank=max(rank),fraction_top4=mean(rank<=4),fraction_top10=mean(rank<=10),.groups='drop'),file.path(out,'receiver_leave_one_gene_out_summary.csv'))

# All four top-10 programs were stored in the original discovery analysis.
four<-c('DCN','TGFB1','TIMP2','SEMA4D')
targets<-saved$top_ligand_target_links |>filter(ligand%in%four)|>group_by(ligand)|>arrange(desc(weight),.by_group=TRUE)|>mutate(target_rank=row_number())|>ungroup()
stopifnot(all(table(targets$ligand)==10))
write_csv(targets,file.path(out,'frozen_top4_target_programs.csv'))
ext<-readRDS(file.path(root,'inputs/external_perivascular_gene_summaries.rds'))
d<-read_csv(file.path(root,'inputs/original_participant_variables.csv'),show_col_types=FALSE)
programs<-split(targets$target,targets$ligand)
overlap<-expand_grid(ligand1=four,ligand2=four)|>rowwise()|>mutate(shared=paste(intersect(programs[[ligand1]],programs[[ligand2]]),collapse=';'),n_shared=length(intersect(programs[[ligand1]],programs[[ligand2]])),jaccard=n_shared/length(union(programs[[ligand1]],programs[[ligand2]])))|>ungroup()
write_csv(overlap,file.path(out,'target_program_overlap.csv'))
zs<-ext$mean_cell_standardized
score<-function(genes)colMeans(zs[intersect(genes,rownames(zs)),,drop=FALSE])
for(lig in four)d[[paste0('program_',lig)]]<-score(programs[[lig]])[d$gsm]
stopifnot(max(abs(d$program_SEMA4D-d$score_unweighted_z))<1e-10)
collections<-read_csv(file.path(root,'inputs/global_Hallmark_Reactome.csv'),show_col_types=FALSE)
gcol<-if('gene_symbol'%in%names(collections))'gene_symbol' else 'gene'
ncolset<-if('gs_name'%in%names(collections))'gs_name' else 'pathway'
generic_names<-c('HALLMARK_INTERFERON_ALPHA_RESPONSE','HALLMARK_INTERFERON_GAMMA_RESPONSE','REACTOME_EXTRACELLULAR_MATRIX_ORGANIZATION','REACTOME_INTEGRIN_CELL_SURFACE_INTERACTIONS')
for(nm in generic_names){genes<-collections[[gcol]][collections[[ncolset]]==nm];stopifnot(length(genes)>0);d[[nm]]<-score(genes)[d$gsm]}
write_csv(d,file.path(out,'external_program_scores_and_original_covariates.csv'))
cors<-cor(d[,c(paste0('program_',four),generic_names)],method='spearman')
write_csv(as.data.frame(cors)|>rownames_to_column('program'),file.path(out,'program_spearman_correlations.csv'))
hc3<-function(m){X<-model.matrix(m);b<-solve(crossprod(X));u<-resid(m)/(1-hatvalues(m));b%*%crossprod(X*u)%*%b}
summ<-function(m,term){s<-coef(summary(m))[term,];ci<-confint(m,term);se3<-sqrt(diag(hc3(m)))[term];q<-qt(.975,df.residual(m));tibble(n=nobs(m),beta=s[1],ci_low=ci[1],ci_high=ci[2],P=s[4],HC3_P=2*pt(-abs(s[1]/se3),df.residual(m)),HC3_ci_low=s[1]-q*se3,HC3_ci_high=s[1]+q*se3)}
effects<-bind_rows(lapply(four,function(lig){f<-reformulate(c('disease_group','chemistry'),paste0('program_',lig));summ(lm(f,d),'disease_groupSSc')|>mutate(ligand=lig,.before=1)}))|>mutate(BH_FDR_4=p.adjust(P,'BH'))
write_csv(effects,file.path(out,'external_program_disease_effects.csv'))
coupling<-bind_rows(lapply(four,function(lig){f<-reformulate(c('myeloid_SEMA4D_pct','disease_group','chemistry','log_perivascular_n','log_myeloid_n'),paste0('program_',lig));summ(lm(f,d),'myeloid_SEMA4D_pct')|>mutate(ligand=lig,.before=1)}))|>mutate(BH_FDR_4=p.adjust(P,'BH'))
write_csv(coupling,file.path(out,'myeloid_SEMA4D_coupling_across4_programs.csv'))
generic_adjusted<-bind_rows(lapply(generic_names,function(nm){f<-reformulate(c('myeloid_SEMA4D_pct','disease_group','chemistry','log_perivascular_n','log_myeloid_n',nm),'program_SEMA4D');summ(lm(f,d),'myeloid_SEMA4D_pct')|>mutate(additional_program=nm,.before=1)}))
write_csv(generic_adjusted,file.path(out,'SEMA4D_model_generic_program_sensitivity.csv'))
target_de<-targets|>left_join(read_csv(file.path(root,'inputs/original_external_gene_effects.csv'),show_col_types=FALSE),by=c('target'='gene'))
write_csv(target_de,file.path(out,'all4_program_external_gene_effects.csv'))
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
print(ans|>filter(ligand%in%four));print(effects);print(coupling)
